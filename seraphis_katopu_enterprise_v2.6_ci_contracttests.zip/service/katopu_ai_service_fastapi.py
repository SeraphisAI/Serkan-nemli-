#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Katopu AI Service — Enterprise Hardening v2.6
- Adds proofBundle in GET /timeline/frames/{id}/verify
- Uses RFC 8785 JCS for all hashes and PQC signature payload bytes
- Domain separation: "KATOPU|AUDIT|v2.6|"
"""

from __future__ import annotations

import base64
import hashlib
import json
import logging
import os
import sqlite3
import time
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from decimal import Decimal
from typing import Any, Dict, Optional, Tuple, List

import yaml
from fastapi import FastAPI, HTTPException, Request, Response
from pydantic import BaseModel, Field

import torch
from transformers import AutoTokenizer, AutoModelForSeq2SeqLM

# Optional redis
try:
    import redis  # type: ignore
except Exception:
    redis = None  # type: ignore

# Optional OTel
OTEL_TRACING = False
OTEL_METRICS = False
try:
    from opentelemetry import trace, metrics
    from opentelemetry.sdk.resources import Resource
    from opentelemetry.sdk.trace import TracerProvider
    from opentelemetry.sdk.trace.export import BatchSpanProcessor
    from opentelemetry.exporter.otlp.proto.http.trace_exporter import OTLPSpanExporter
    from opentelemetry.instrumentation.fastapi import FastAPIInstrumentor
    from opentelemetry.sdk.metrics import MeterProvider
    from opentelemetry.sdk.metrics.export import PeriodicExportingMetricReader
    from opentelemetry.exporter.otlp.proto.http.metric_exporter import OTLPMetricExporter
    OTEL_TRACING = True
    OTEL_METRICS = True
except Exception:
    OTEL_TRACING = False
    OTEL_METRICS = False

# Optional PQC (liboqs)
PQC_AVAILABLE = False
try:
    import oqs  # type: ignore
    PQC_AVAILABLE = True
except Exception:
    PQC_AVAILABLE = False

DOMAIN_SEPARATOR = b"KATOPU|AUDIT|v2.6|"
CANONICALIZATION_INFO = {"scheme": "RFC8785_JCS", "rfc": 8785, "notes": "Deterministic JSON Canonicalization Scheme (JCS)."}

SERVICE_NAME = os.getenv("OTEL_SERVICE_NAME", os.getenv("SERVICE_NAME", "katopu-ai-service"))
MODEL_DIR = os.getenv("MODEL_DIR", "./katopu-quantum-core-model")
OPENAPI_PATH = os.getenv("OPENAPI_PATH", "")

AUDIT_TTL_SECONDS = int(os.getenv("AUDIT_TTL_SECONDS", "86400"))
AUDIT_CHAIN_ID = os.getenv("AUDIT_CHAIN_ID", "ai.ask")
AUDIT_CHAIN_STATE_KEY = os.getenv("AUDIT_CHAIN_STATE_KEY", "katopu:audit:chain:head")

AUDIT_STORE_ENV = os.getenv("AUDIT_STORE", "").strip().lower()
REDIS_URL = os.getenv("REDIS_URL", "").strip()
SQLITE_PATH = os.getenv("SQLITE_PATH", "./audit_frames.sqlite").strip()

PQC_SIGNING_ENABLED = os.getenv("PQC_SIGNING_ENABLED", "false").strip().lower() in {"1", "true", "yes", "on"}
PQC_SIG_ALG = os.getenv("PQC_SIG_ALG", "ML-DSA-65").strip()
PQC_PERSIST_SECRET_KEYS = os.getenv("PQC_PERSIST_SECRET_KEYS", "false").strip().lower() in {"1", "true", "yes", "on"}
PQC_MAX_ACTIVE_VERIFY_KEYS = int(os.getenv("PQC_MAX_ACTIVE_VERIFY_KEYS", "5"))
PQC_GRACE_PERIOD_SECONDS = int(os.getenv("PQC_GRACE_PERIOD_SECONDS", "604800"))
PQC_FORCED_RETIRE_AFTER_SECONDS = int(os.getenv("PQC_FORCED_RETIRE_AFTER_SECONDS", "2592000"))

# -----------------------------
# Logging
# -----------------------------
class JsonFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        obj = {
            "ts": datetime.now(timezone.utc).isoformat(),
            "level": record.levelname,
            "logger": record.name,
            "msg": record.getMessage(),
        }
        for k in ("requestId", "traceId", "spanId", "eventType"):
            if hasattr(record, k):
                obj[k] = getattr(record, k)
        return json.dumps(obj, ensure_ascii=False)

logger = logging.getLogger("katopu")
handler = logging.StreamHandler()
handler.setFormatter(JsonFormatter())
logger.setLevel(logging.INFO)
logger.handlers = [handler]
logger.propagate = False

def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()

def epoch_seconds() -> int:
    return int(time.time())

# -----------------------------
# RFC 8785 JCS (pragmatic deterministic)
# -----------------------------
def _json_escape_string(s: str) -> str:
    out = ['"']
    for ch in s:
        code = ord(ch)
        if ch == '"':
            out.append('\\"')
        elif ch == '\\':
            out.append('\\\\')
        elif code < 0x20:
            out.append("\\u%04x" % code)
        else:
            out.append(ch)
    out.append('"')
    return "".join(out)

def _jcs_number(n: Any) -> str:
    if isinstance(n, bool) or n is None:
        raise ValueError("Not a number")
    if isinstance(n, int):
        return str(n)
    if isinstance(n, Decimal):
        d = n
    elif isinstance(n, float):
        if n != n or n in (float("inf"), float("-inf")):
            raise ValueError("NaN/Infinity not allowed in JSON")
        d = Decimal(repr(n))
    else:
        d = Decimal(str(n))
    if d == 0:
        return "0"
    s = format(d.normalize(), "f")
    if "." in s:
        s = s.rstrip("0").rstrip(".")
    if s in ("-0", "+0"):
        s = "0"
    if len(s.replace("-", "")) > 21:
        s2 = format(d.normalize(), "E").replace("E", "e")
        mant, ex = s2.split("e", 1)
        ex = ex.lstrip("+")
        ex = ex.lstrip("0") or "0"
        if "." in mant:
            mant = mant.rstrip("0").rstrip(".")
        s = mant + "e" + ex
    return s

def jcs_dumps(obj: Any) -> str:
    if obj is None:
        return "null"
    if obj is True:
        return "true"
    if obj is False:
        return "false"
    if isinstance(obj, str):
        return _json_escape_string(obj)
    if isinstance(obj, (int, float, Decimal)):
        return _jcs_number(obj)
    if isinstance(obj, (list, tuple)):
        return "[" + ",".join(jcs_dumps(v) for v in obj) + "]"
    if isinstance(obj, dict):
        items = []
        for k in sorted(obj.keys()):
            if not isinstance(k, str):
                raise ValueError("JSON object keys must be strings")
            items.append(_json_escape_string(k) + ":" + jcs_dumps(obj[k]))
        return "{" + ",".join(items) + "}"
    raise ValueError(f"Unsupported type for JCS: {type(obj)}")

def jcs_bytes(obj: Any) -> bytes:
    return jcs_dumps(obj).encode("utf-8")

def sha256_hex(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()

def hash_obj(obj: Any) -> str:
    return sha256_hex(jcs_bytes(obj))

# -----------------------------
# OpenTelemetry
# -----------------------------
H_AI_ASK_LAT = None
H_MODEL_LOAD = None
H_PQC_SIGN = None

def init_otel(app: FastAPI) -> None:
    global H_AI_ASK_LAT, H_MODEL_LOAD, H_PQC_SIGN, OTEL_TRACING, OTEL_METRICS
    endpoint = os.getenv("OTEL_EXPORTER_OTLP_ENDPOINT", "").strip()
    if not endpoint:
        OTEL_TRACING = False
        OTEL_METRICS = False
        return
    resource = Resource.create({"service.name": SERVICE_NAME})
    if OTEL_TRACING:
        provider = TracerProvider(resource=resource)
        exporter = OTLPSpanExporter(endpoint=endpoint.rstrip("/") + "/v1/traces")
        provider.add_span_processor(BatchSpanProcessor(exporter))
        trace.set_tracer_provider(provider)
        FastAPIInstrumentor.instrument_app(app)
    if OTEL_METRICS:
        metric_exporter = OTLPMetricExporter(endpoint=endpoint.rstrip("/") + "/v1/metrics")
        reader = PeriodicExportingMetricReader(metric_exporter, export_interval_millis=5000)
        mp = MeterProvider(resource=resource, metric_readers=[reader])
        metrics.set_meter_provider(mp)
        meter = metrics.get_meter(SERVICE_NAME)
        H_AI_ASK_LAT = meter.create_histogram("katopu.ai_ask.latency_s", unit="s")
        H_MODEL_LOAD = meter.create_histogram("katopu.model.load_s", unit="s")
        H_PQC_SIGN = meter.create_histogram("katopu.pqc.sign_s", unit="s")

def w3c_traceparent() -> Optional[str]:
    if not OTEL_TRACING:
        return None
    span = trace.get_current_span()
    ctx = span.get_span_context()
    if not ctx or not ctx.is_valid:
        return None
    return f"00-{ctx.trace_id:032x}-{ctx.span_id:016x}-{ctx.trace_flags:02x}"

def trace_ids() -> Tuple[Optional[str], Optional[str], Optional[str]]:
    tp = w3c_traceparent()
    if not tp:
        return None, None, None
    parts = tp.split("-")
    if len(parts) != 4:
        return None, None, tp
    return parts[1], parts[2], tp

# -----------------------------
# Audit store
# -----------------------------
class AuditStore:
    store_name: str = "memory"
    def ping(self) -> bool: return True
    def put(self, frame_id: str, obj: Dict[str, Any], ttl_seconds: int) -> None: raise NotImplementedError
    def get(self, frame_id: str) -> Optional[Dict[str, Any]]: raise NotImplementedError
    def delete(self, frame_id: str) -> None: raise NotImplementedError
    def get_chain_head_hash(self, chain_id: str) -> Optional[str]: return None
    def set_chain_head_hash(self, chain_id: str, frame_hash: str) -> None: pass
    def get_chain_head_id(self, chain_id: str) -> Optional[str]: return None
    def set_chain_head_id(self, chain_id: str, frame_id: str) -> None: pass

class MemoryAuditStore(AuditStore):
    store_name = "memory"
    def __init__(self) -> None:
        self._d: Dict[str, Tuple[Dict[str, Any], int]] = {}
        self._head_hash: Dict[str, str] = {}
        self._head_id: Dict[str, str] = {}
    def put(self, frame_id: str, obj: Dict[str, Any], ttl_seconds: int) -> None:
        self._d[frame_id] = (obj, epoch_seconds() + ttl_seconds)
    def get(self, frame_id: str) -> Optional[Dict[str, Any]]:
        item = self._d.get(frame_id)
        if not item: return None
        obj, exp = item
        if epoch_seconds() >= exp:
            self._d.pop(frame_id, None)
            return None
        return obj
    def delete(self, frame_id: str) -> None:
        self._d.pop(frame_id, None)
    def get_chain_head_hash(self, chain_id: str) -> Optional[str]:
        return self._head_hash.get(chain_id)
    def set_chain_head_hash(self, chain_id: str, frame_hash: str) -> None:
        self._head_hash[chain_id] = frame_hash
    def get_chain_head_id(self, chain_id: str) -> Optional[str]:
        return self._head_id.get(chain_id)
    def set_chain_head_id(self, chain_id: str, frame_id: str) -> None:
        self._head_id[chain_id] = frame_id

class SQLiteAuditStore(AuditStore):
    store_name = "sqlite"
    def __init__(self, path: str) -> None:
        self.path = path
        self._init_db()
    def _conn(self):
        return sqlite3.connect(self.path, check_same_thread=False)
    def _init_db(self) -> None:
        con = self._conn()
        try:
            con.execute("CREATE TABLE IF NOT EXISTS audit_frames (id TEXT PRIMARY KEY, json TEXT NOT NULL, expires_at INTEGER NOT NULL)")
            con.execute("CREATE INDEX IF NOT EXISTS idx_expires_at ON audit_frames(expires_at)")
            con.execute("CREATE TABLE IF NOT EXISTS kv (k TEXT PRIMARY KEY, v TEXT NOT NULL)")
            con.execute(
                "CREATE TABLE IF NOT EXISTS pqc_keys ("
                "key_id TEXT PRIMARY KEY, alg TEXT NOT NULL, public_b64 TEXT NOT NULL, "
                "created_at TEXT NOT NULL, role TEXT NOT NULL, status TEXT NOT NULL, "
                "not_before TEXT, not_after TEXT, secret_b64 TEXT)"
            )
            con.commit()
        finally:
            con.close()
    def ping(self) -> bool:
        try:
            con = self._conn(); con.execute("SELECT 1"); con.close(); return True
        except Exception:
            return False
    def put(self, frame_id: str, obj: Dict[str, Any], ttl_seconds: int) -> None:
        exp = epoch_seconds() + ttl_seconds
        payload = json.dumps(obj, ensure_ascii=False)
        con = self._conn()
        try:
            con.execute("INSERT OR REPLACE INTO audit_frames (id, json, expires_at) VALUES (?, ?, ?)", (frame_id, payload, exp))
            con.commit()
        finally:
            con.close()
    def get(self, frame_id: str) -> Optional[Dict[str, Any]]:
        con = self._conn()
        try:
            row = con.execute("SELECT json, expires_at FROM audit_frames WHERE id = ?", (frame_id,)).fetchone()
            if not row: return None
            payload, exp = row
            if epoch_seconds() >= int(exp):
                con.execute("DELETE FROM audit_frames WHERE id = ?", (frame_id,))
                con.commit()
                return None
            return json.loads(payload)
        finally:
            con.close()
    def delete(self, frame_id: str) -> None:
        con = self._conn()
        try:
            con.execute("DELETE FROM audit_frames WHERE id = ?", (frame_id,))
            con.commit()
        finally:
            con.close()
    def _kv_get(self, k: str) -> Optional[str]:
        con = self._conn()
        try:
            row = con.execute("SELECT v FROM kv WHERE k = ?", (k,)).fetchone()
            return row[0] if row else None
        finally:
            con.close()
    def _kv_set(self, k: str, v: str) -> None:
        con = self._conn()
        try:
            con.execute("INSERT OR REPLACE INTO kv (k, v) VALUES (?, ?)", (k, v))
            con.commit()
        finally:
            con.close()
    def get_chain_head_hash(self, chain_id: str) -> Optional[str]:
        return self._kv_get(f"chain:{chain_id}:head_hash")
    def set_chain_head_hash(self, chain_id: str, frame_hash: str) -> None:
        self._kv_set(f"chain:{chain_id}:head_hash", frame_hash)
    def get_chain_head_id(self, chain_id: str) -> Optional[str]:
        return self._kv_get(f"chain:{chain_id}:head_id")
    def set_chain_head_id(self, chain_id: str, frame_id: str) -> None:
        self._kv_set(f"chain:{chain_id}:head_id", frame_id)

class RedisAuditStore(AuditStore):
    store_name = "redis"
    def __init__(self, url: str) -> None:
        if redis is None:
            raise RuntimeError("redis package not installed. `pip install redis`")
        self.client = redis.Redis.from_url(url, decode_responses=True)
        self.prefix = "katopu:audit:"
    def ping(self) -> bool:
        try:
            return bool(self.client.ping())
        except Exception:
            return False
    def put(self, frame_id: str, obj: Dict[str, Any], ttl_seconds: int) -> None:
        payload = json.dumps(obj, ensure_ascii=False)
        self.client.setex(self.prefix + frame_id, ttl_seconds, payload)
    def get(self, frame_id: str) -> Optional[Dict[str, Any]]:
        payload = self.client.get(self.prefix + frame_id)
        return json.loads(payload) if payload else None
    def delete(self, frame_id: str) -> None:
        self.client.delete(self.prefix + frame_id)
    def get_chain_head_hash(self, chain_id: str) -> Optional[str]:
        return self.client.get(f"{AUDIT_CHAIN_STATE_KEY}:{chain_id}:head_hash")
    def set_chain_head_hash(self, chain_id: str, frame_hash: str) -> None:
        self.client.set(f"{AUDIT_CHAIN_STATE_KEY}:{chain_id}:head_hash", frame_hash)
    def get_chain_head_id(self, chain_id: str) -> Optional[str]:
        return self.client.get(f"{AUDIT_CHAIN_STATE_KEY}:{chain_id}:head_id")
    def set_chain_head_id(self, chain_id: str, frame_id: str) -> None:
        self.client.set(f"{AUDIT_CHAIN_STATE_KEY}:{chain_id}:head_id", frame_id)

def select_audit_store() -> AuditStore:
    if AUDIT_STORE_ENV == "memory":
        return MemoryAuditStore()
    if AUDIT_STORE_ENV == "sqlite":
        return SQLiteAuditStore(SQLITE_PATH)
    if AUDIT_STORE_ENV == "redis":
        if not REDIS_URL:
            raise RuntimeError("AUDIT_STORE=redis but REDIS_URL is empty")
        return RedisAuditStore(REDIS_URL)
    if REDIS_URL:
        return RedisAuditStore(REDIS_URL)
    return SQLiteAuditStore(SQLITE_PATH)

AUDIT_STORE: AuditStore = select_audit_store()

# -----------------------------
# Keyring (rotation policy)
# -----------------------------
@dataclass
class KeyRecord:
    keyId: str
    alg: str
    publicKeyB64: str
    createdAt: str
    role: str
    status: str
    notBefore: Optional[str] = None
    notAfter: Optional[str] = None
    secretKeyB64: Optional[str] = None

class KeyringStore:
    def list_keys(self) -> List[KeyRecord]: raise NotImplementedError
    def upsert_key(self, rec: KeyRecord) -> None: raise NotImplementedError
    def get_signing_key_id(self) -> Optional[str]: raise NotImplementedError
    def set_signing_key_id(self, key_id: str) -> None: raise NotImplementedError
    def find(self, key_id: Optional[str]) -> Optional[KeyRecord]:
        if not key_id: return None
        for k in self.list_keys():
            if k.keyId == key_id: return k
        return None

class MemoryKeyring(KeyringStore):
    def __init__(self) -> None:
        self._keys: Dict[str, KeyRecord] = {}
        self._signing_id: Optional[str] = None
    def list_keys(self) -> List[KeyRecord]:
        return list(self._keys.values())
    def upsert_key(self, rec: KeyRecord) -> None:
        self._keys[rec.keyId] = rec
    def get_signing_key_id(self) -> Optional[str]:
        return self._signing_id
    def set_signing_key_id(self, key_id: str) -> None:
        self._signing_id = key_id

class SQLiteKeyring(KeyringStore):
    def __init__(self, path: str) -> None:
        self.path = path
    def _conn(self):
        return sqlite3.connect(self.path, check_same_thread=False)
    def list_keys(self) -> List[KeyRecord]:
        con = self._conn()
        try:
            rows = con.execute("SELECT key_id, alg, public_b64, created_at, role, status, not_before, not_after, secret_b64 FROM pqc_keys").fetchall()
            return [KeyRecord(*r) for r in rows]
        finally:
            con.close()
    def upsert_key(self, rec: KeyRecord) -> None:
        con = self._conn()
        try:
            con.execute(
                "INSERT OR REPLACE INTO pqc_keys (key_id, alg, public_b64, created_at, role, status, not_before, not_after, secret_b64) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (rec.keyId, rec.alg, rec.publicKeyB64, rec.createdAt, rec.role, rec.status, rec.notBefore, rec.notAfter, rec.secretKeyB64),
            )
            con.commit()
        finally:
            con.close()
    def get_signing_key_id(self) -> Optional[str]:
        con = self._conn()
        try:
            row = con.execute("SELECT v FROM kv WHERE k = 'pqc:signing_key_id'").fetchone()
            v = row[0] if row else None
            return v if v else None
        finally:
            con.close()
    def set_signing_key_id(self, key_id: str) -> None:
        con = self._conn()
        try:
            con.execute("INSERT OR REPLACE INTO kv (k, v) VALUES ('pqc:signing_key_id', ?)", (key_id,))
            con.commit()
        finally:
            con.close()

class RedisKeyring(KeyringStore):
    def __init__(self, url: str) -> None:
        if redis is None:
            raise RuntimeError("redis package not installed. `pip install redis`")
        self.client = redis.Redis.from_url(url, decode_responses=True)
        self.keyring_key = "katopu:pqc:keyring"
        self.signing_key_key = "katopu:pqc:signing_key_id"
    def list_keys(self) -> List[KeyRecord]:
        raw = self.client.get(self.keyring_key)
        if not raw: return []
        return [KeyRecord(**r) for r in json.loads(raw)]
    def upsert_key(self, rec: KeyRecord) -> None:
        keys = {k.keyId: k for k in self.list_keys()}
        keys[rec.keyId] = rec
        self.client.set(self.keyring_key, json.dumps([k.__dict__ for k in keys.values()], ensure_ascii=False))
    def get_signing_key_id(self) -> Optional[str]:
        return self.client.get(self.signing_key_key)
    def set_signing_key_id(self, key_id: str) -> None:
        self.client.set(self.signing_key_key, key_id)

def select_keyring_store() -> KeyringStore:
    if AUDIT_STORE.store_name == "redis" and REDIS_URL:
        return RedisKeyring(REDIS_URL)
    if AUDIT_STORE.store_name == "sqlite":
        return SQLiteKeyring(SQLITE_PATH)
    return MemoryKeyring()

KEYRING: KeyringStore = select_keyring_store()

def _parse_dt(s: Optional[str]) -> Optional[datetime]:
    if not s: return None
    try:
        return datetime.fromisoformat(s.replace("Z", "+00:00"))
    except Exception:
        return None

def _retire_and_enforce_policy() -> None:
    now = datetime.now(timezone.utc)
    keys = KEYRING.list_keys()

    for k in keys:
        ca = _parse_dt(k.createdAt)
        if ca and (now - ca).total_seconds() >= PQC_FORCED_RETIRE_AFTER_SECONDS and k.status != "retired":
            k.status = "retired"
            KEYRING.upsert_key(k)

    keys = KEYRING.list_keys()
    for k in keys:
        na = _parse_dt(k.notAfter)
        if na and now >= na and k.status != "retired":
            k.status = "retired"
            KEYRING.upsert_key(k)

    keys = [k for k in KEYRING.list_keys() if k.status != "retired"]
    verify_keys = [k for k in keys if k.role == "verify" and k.status in {"active", "retiring"}]
    verify_keys.sort(key=lambda r: r.createdAt, reverse=True)
    if len(verify_keys) > PQC_MAX_ACTIVE_VERIFY_KEYS:
        for k in verify_keys[PQC_MAX_ACTIVE_VERIFY_KEYS:]:
            k.status = "retired"
            KEYRING.upsert_key(k)

def _create_keypair() -> KeyRecord:
    signer = oqs.Signature(PQC_SIG_ALG)
    public_key = signer.generate_keypair()
    secret_b64 = None
    if PQC_PERSIST_SECRET_KEYS and hasattr(signer, "export_secret_key"):
        try:
            secret_b64 = base64.b64encode(signer.export_secret_key()).decode("ascii")
        except Exception:
            secret_b64 = None
    return KeyRecord(
        keyId=str(uuid.uuid4()),
        alg=PQC_SIG_ALG,
        publicKeyB64=base64.b64encode(public_key).decode("ascii"),
        createdAt=now_iso(),
        role="sign",
        status="active",
        notBefore=now_iso(),
        notAfter=datetime.fromtimestamp(epoch_seconds() + PQC_GRACE_PERIOD_SECONDS, tz=timezone.utc).isoformat(),
        secretKeyB64=secret_b64,
    )

def _ensure_signing_key() -> Optional[KeyRecord]:
    if not (PQC_SIGNING_ENABLED and PQC_AVAILABLE):
        return None
    _retire_and_enforce_policy()
    k = KEYRING.find(KEYRING.get_signing_key_id())
    if k and k.role == "sign" and k.status != "retired":
        return k
    rec = _create_keypair()
    KEYRING.upsert_key(rec)
    KEYRING.set_signing_key_id(rec.keyId)
    return rec

def rotate_signing_key() -> KeyRecord:
    if not PQC_AVAILABLE:
        raise HTTPException(status_code=501, detail="PQC library unavailable; rotation not supported.")
    if not PQC_SIGNING_ENABLED:
        raise HTTPException(status_code=400, detail="PQC signing is disabled.")
    _retire_and_enforce_policy()
    prev = KEYRING.find(KEYRING.get_signing_key_id())
    if prev and prev.status != "retired":
        prev.role = "verify"
        prev.status = "retiring"
        prev.notAfter = datetime.fromtimestamp(epoch_seconds() + PQC_GRACE_PERIOD_SECONDS, tz=timezone.utc).isoformat()
        KEYRING.upsert_key(prev)
    newk = _create_keypair()
    KEYRING.upsert_key(newk)
    KEYRING.set_signing_key_id(newk.keyId)
    _retire_and_enforce_policy()
    return newk

def keyring_snapshot() -> Dict[str, Any]:
    _retire_and_enforce_policy()
    keys_out = []
    for k in KEYRING.list_keys():
        if k.status == "retired":
            continue
        keys_out.append({
            "keyId": k.keyId,
            "alg": k.alg,
            "publicKeyB64": k.publicKeyB64,
            "createdAt": k.createdAt,
            "role": k.role,
            "status": k.status,
            "notBefore": k.notBefore,
            "notAfter": k.notAfter,
        })
    keys_out.sort(key=lambda r: r["keyId"])
    return {
        "signingKeyId": KEYRING.get_signing_key_id(),
        "keys": keys_out,
        "policy": {
            "maxActiveVerifyKeys": PQC_MAX_ACTIVE_VERIFY_KEYS,
            "gracePeriodSeconds": PQC_GRACE_PERIOD_SECONDS,
            "forcedRetireAfterSeconds": PQC_FORCED_RETIRE_AFTER_SECONDS,
        },
        "domainSeparator": DOMAIN_SEPARATOR.decode("utf-8"),
        "snapshotAt": now_iso(),
    }

def _key_pub_bytes(key_id: str) -> Optional[bytes]:
    k = KEYRING.find(key_id)
    if not k or k.status == "retired":
        return None
    try:
        return base64.b64decode(k.publicKeyB64)
    except Exception:
        return None

def _signer_from_key(rec: KeyRecord):
    if not rec.secretKeyB64 or not hasattr(oqs.Signature, "import_secret_key"):
        return None
    try:
        signer = oqs.Signature(rec.alg)
        signer.import_secret_key(base64.b64decode(rec.secretKeyB64))
        return signer
    except Exception:
        return None

# -----------------------------
# OpenAPI grounding (optional)
# -----------------------------
def load_openapi(path: str) -> Dict[str, Any]:
    if not path:
        return {}
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)

OPENAPI_SPEC = load_openapi(OPENAPI_PATH)
OPENAPI_LOADED = bool(OPENAPI_SPEC)

def best_context(question: str, spec: Dict[str, Any]) -> str:
    if not spec:
        return ""
    q = question.lower()
    hits = []
    for pth, methods in (spec.get("paths") or {}).items():
        if not isinstance(methods, dict):
            continue
        for m, op in methods.items():
            if m.lower() not in {"get","post","put","patch","delete"} or not isinstance(op, dict):
                continue
            score = 0
            if pth.lower() in q: score += 3
            if m.lower() in q: score += 1
            if (op.get("operationId") or "").lower() in q: score += 2
            if score:
                hits.append((score, {"method": m.upper(), "path": pth, "summary": op.get("summary",""), "description": op.get("description","")}))
    hits.sort(key=lambda x: x[0], reverse=True)
    return json.dumps(hits[0][1], ensure_ascii=False, indent=2) if hits else ""

# -----------------------------
# Model
# -----------------------------
TOKENIZER = None
MODEL = None
MODEL_LOADED = False

def load_model() -> None:
    global TOKENIZER, MODEL, MODEL_LOADED
    if MODEL_LOADED:
        return
    t0 = time.perf_counter()
    TOKENIZER = AutoTokenizer.from_pretrained(MODEL_DIR, use_fast=True)
    MODEL = AutoModelForSeq2SeqLM.from_pretrained(MODEL_DIR)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    MODEL.to(device)
    MODEL_LOADED = True
    if H_MODEL_LOAD is not None:
        H_MODEL_LOAD.record(time.perf_counter() - t0)

def generate_answer(prompt: str, max_new_tokens: int = 256, temperature: float = 0.0) -> str:
    assert TOKENIZER is not None and MODEL is not None
    device = next(MODEL.parameters()).device
    inputs = TOKENIZER(prompt, return_tensors="pt", truncation=True, max_length=1024).to(device)
    with torch.no_grad():
        out = MODEL.generate(
            **inputs,
            max_new_tokens=max_new_tokens,
            do_sample=(temperature > 0.0),
            temperature=max(temperature, 1e-6),
        )
    ans = TOKENIZER.decode(out[0], skip_special_tokens=True)
    if "Assistant:" in ans:
        ans = ans.split("Assistant:")[-1].strip()
    return ans.strip()

# -----------------------------
# Hashing + signing
# -----------------------------
def compute_frame_hash(frame: Dict[str, Any]) -> str:
    f = dict(frame)
    f.pop("frameHash", None)
    prev = (f.get("previousFrameHash") or "").encode("utf-8")
    return sha256_hex(DOMAIN_SEPARATOR + jcs_bytes(f) + prev)

def sign_evidence(payload: Dict[str, Any]) -> Dict[str, Any]:
    created_at = now_iso()
    sig_obj: Dict[str, Any] = {
        "alg": PQC_SIG_ALG,
        "keyId": None,
        "publicKeyB64": None,
        "signatureB64": None,
        "canonicalPayloadSha256": hash_obj(payload),
        "canonicalization": CANONICALIZATION_INFO,
        "createdAt": created_at,
        "status": "unsigned",
    }
    if not PQC_SIGNING_ENABLED:
        return {"payload": payload, "pqcSignature": sig_obj}
    if not PQC_AVAILABLE:
        sig_obj["status"] = "unavailable"
        return {"payload": payload, "pqcSignature": sig_obj}

    signing = _ensure_signing_key()
    if not signing:
        sig_obj["status"] = "unavailable"
        return {"payload": payload, "pqcSignature": sig_obj}

    signer = _signer_from_key(signing)
    if signer is None:
        sig_obj["status"] = "unavailable"
        sig_obj["keyId"] = signing.keyId
        sig_obj["publicKeyB64"] = signing.publicKeyB64
        return {"payload": payload, "pqcSignature": sig_obj}

    msg = jcs_bytes(payload)
    t0 = time.perf_counter()
    try:
        signature = signer.sign(msg)
        if H_PQC_SIGN is not None:
            H_PQC_SIGN.record(time.perf_counter() - t0)
        sig_obj["status"] = "signed"
        sig_obj["keyId"] = signing.keyId
        sig_obj["publicKeyB64"] = signing.publicKeyB64
        sig_obj["signatureB64"] = base64.b64encode(signature).decode("ascii")
    except Exception:
        sig_obj["status"] = "unavailable"
        sig_obj["keyId"] = signing.keyId
        sig_obj["publicKeyB64"] = signing.publicKeyB64

    return {"payload": payload, "pqcSignature": sig_obj}

def verify_evidence(signed_evidence: Dict[str, Any]) -> Dict[str, Any]:
    payload = signed_evidence.get("payload")
    sig = (signed_evidence.get("pqcSignature") or {})
    status = sig.get("status") or "invalid"
    alg = sig.get("alg")
    key_id = sig.get("keyId")
    sig_b64 = sig.get("signatureB64")
    expected_hash = sig.get("canonicalPayloadSha256")

    if status != "signed":
        return {"ok": False, "status": status, "reason": "Evidence is not marked signed."}
    if not (PQC_AVAILABLE and PQC_SIGNING_ENABLED):
        return {"ok": False, "status": "unavailable", "reason": "PQC verification unavailable."}
    if not (payload and key_id and sig_b64 and alg):
        return {"ok": False, "status": "invalid", "reason": "Missing payload/keyId/signature/alg."}
    if expected_hash and expected_hash != hash_obj(payload):
        return {"ok": False, "status": "invalid", "reason": "canonicalPayloadSha256 mismatch."}

    pub = _key_pub_bytes(key_id)
    if not pub:
        return {"ok": False, "status": "invalid", "reason": "Public key not found."}

    try:
        verifier = oqs.Signature(alg)
        ok = verifier.verify(jcs_bytes(payload), base64.b64decode(sig_b64), pub)
        return {"ok": bool(ok), "status": "signed" if ok else "invalid", "keyId": key_id, "alg": alg}
    except Exception as e:
        return {"ok": False, "status": "invalid", "reason": str(e), "keyId": key_id, "alg": alg}

# -----------------------------
# Proof bundle (verify output)
# -----------------------------
def build_keyring_proof() -> Dict[str, Any]:
    snap = keyring_snapshot()
    return {"snapshot": snap, "snapshotHashSha256": hash_obj(snap)}

def build_chain_proof(start_frame: Dict[str, Any], depth: int) -> Dict[str, Any]:
    steps = []
    cur = start_frame
    for _ in range(depth):
        if not cur:
            break
        steps.append({
            "frameId": cur.get("id"),
            "frameHash": cur.get("frameHash"),
            "previousFrameId": cur.get("previousFrameId"),
            "previousFrameHash": cur.get("previousFrameHash"),
        })
        prev_id = cur.get("previousFrameId")
        cur = AUDIT_STORE.get(prev_id) if prev_id else None
    core = {
        "chainId": start_frame.get("chainId") or AUDIT_CHAIN_ID,
        "domainSeparator": DOMAIN_SEPARATOR.decode("utf-8"),
        "depth": depth,
        "steps": steps,
    }
    core["proofHashSha256"] = hash_obj(core)
    return core

def build_signature_proof(frame: Dict[str, Any], sig_report: Dict[str, Any]) -> Dict[str, Any]:
    se = frame.get("signedEvidence") or {}
    sig = (se.get("pqcSignature") or {})
    payload = se.get("payload")
    core = {
        "status": sig_report.get("status") or "invalid",
        "alg": sig.get("alg"),
        "keyId": sig.get("keyId"),
        "publicKeyB64": sig.get("publicKeyB64"),
        "signatureB64": sig.get("signatureB64"),
        "payloadCanonicalSha256": hash_obj(payload),
        "canonicalization": CANONICALIZATION_INFO,
    }
    core["proofHashSha256"] = hash_obj(core)
    return core

def build_bundle_hash(bundle: Dict[str, Any]) -> str:
    core = {
        "canonicalization": bundle.get("canonicalization"),
        "keyring": bundle.get("keyring"),
        "chain": bundle.get("chain"),
        "signature": bundle.get("signature"),
    }
    return hash_obj(core)

# -----------------------------
# API models
# -----------------------------
class AiAskRequest(BaseModel):
    question: str = Field(..., min_length=1)
    includeOpenApiContext: bool = True
    maxNewTokens: int = Field(256, ge=16, le=1024)
    temperature: float = Field(0.0, ge=0.0, le=1.5)

class AiAskResponse(BaseModel):
    answer: str
    model: str
    timelineFrameId: str
    persistence: Dict[str, Any]
    signedEvidence: Optional[Dict[str, Any]] = None
    chain: Dict[str, Any]

class AiHealthResponse(BaseModel):
    status: str
    modelLoaded: bool
    openapiLoaded: bool
    persistenceStore: str
    persistenceOk: bool
    pqcSigningEnabled: bool
    time: str

# -----------------------------
# App
# -----------------------------
app = FastAPI(title="Katopu AI Service", version="2.6.0-enterprise-hardening")
init_otel(app)

def get_request_id(req: Request) -> str:
    return req.headers.get("X-Request-Id") or str(uuid.uuid4())

def add_trace_headers(resp: Response) -> Dict[str, Optional[str]]:
    tp = w3c_traceparent()
    if tp:
        resp.headers["traceparent"] = tp
    trace_id, span_id, tp2 = trace_ids()
    return {"traceId": trace_id, "spanId": span_id, "traceparent": tp2}

def build_persistence_info(store_name: str, ttl: int) -> Dict[str, Any]:
    exp = datetime.fromtimestamp(epoch_seconds() + ttl, tz=timezone.utc).isoformat()
    return {"persisted": store_name != "memory", "store": store_name, "ttlSeconds": ttl, "expiresAt": exp, "consistency": "read-after-write"}

@app.get("/ai/health", response_model=AiHealthResponse)
def ai_health(request: Request, response: Response):
    rid = get_request_id(request)
    response.headers["X-Request-Id"] = rid
    trace_info = add_trace_headers(response)
    ok = False
    try:
        ok = AUDIT_STORE.ping()
    except Exception:
        ok = False
    status = "ok" if ok else "degraded"
    logger.info("health", extra={"eventType":"ai.health","requestId":rid,"traceId":trace_info.get("traceId"),"spanId":trace_info.get("spanId")})
    return AiHealthResponse(
        status=status,
        modelLoaded=MODEL_LOADED,
        openapiLoaded=OPENAPI_LOADED,
        persistenceStore=AUDIT_STORE.store_name,
        persistenceOk=ok,
        pqcSigningEnabled=bool(PQC_SIGNING_ENABLED and PQC_AVAILABLE),
        time=now_iso(),
    )

@app.get("/security/pqc/keys")
def get_pqc_keys(request: Request, response: Response):
    rid = get_request_id(request)
    response.headers["X-Request-Id"] = rid
    add_trace_headers(response)
    snap = keyring_snapshot()
    if not (PQC_SIGNING_ENABLED and PQC_AVAILABLE):
        return {"signingKeyId": None, "keys": [], "policy": snap.get("policy"), "time": now_iso()}
    return {"signingKeyId": snap.get("signingKeyId"), "keys": snap.get("keys"), "policy": snap.get("policy"), "time": now_iso()}

@app.post("/security/pqc/keys/rotate")
def rotate_pqc_keys(request: Request, response: Response):
    rid = get_request_id(request)
    response.headers["X-Request-Id"] = rid
    add_trace_headers(response)
    prev_id = KEYRING.get_signing_key_id()
    newk = rotate_signing_key()
    return {"newSigningKey": newk.__dict__, "previousSigningKeyId": prev_id, "time": now_iso()}

@app.post("/ai/ask", response_model=AiAskResponse)
def ai_ask(req: AiAskRequest, request: Request, response: Response):
    rid = get_request_id(request)
    response.headers["X-Request-Id"] = rid
    trace_info = add_trace_headers(response)

    t0 = time.perf_counter()
    load_model()

    sys_preamble = "You are a precise technical assistant for the Katopu Quantum Core API."
    ctx = best_context(req.question, OPENAPI_SPEC) if (req.includeOpenApiContext and OPENAPI_SPEC) else ""
    prompt = sys_preamble + "\n\n" + (("OpenAPI context:\n" + ctx + "\n\n") if ctx else "") + f"User: {req.question.strip()}\nAssistant:"
    ans = generate_answer(prompt, max_new_tokens=req.maxNewTokens, temperature=req.temperature)

    previous_hash = AUDIT_STORE.get_chain_head_hash(AUDIT_CHAIN_ID)
    previous_id = AUDIT_STORE.get_chain_head_id(AUDIT_CHAIN_ID)

    frame_id = str(uuid.uuid4())
    persistence = build_persistence_info(AUDIT_STORE.store_name, AUDIT_TTL_SECONDS)
    frame_payload = {"question": req.question, "answer": ans, "modelDir": MODEL_DIR, "openapiPath": OPENAPI_PATH or None}
    signed = sign_evidence({"event":"ai.ask","requestId":rid,"payload":frame_payload})

    frame = {
        "id": frame_id,
        "createdAt": now_iso(),
        "source": SERVICE_NAME,
        "eventType": "ai.ask",
        "requestId": rid,
        "trace": trace_info,
        "payload": frame_payload,
        "persistence": persistence,
        "signedEvidence": signed,
        "chainId": AUDIT_CHAIN_ID,
        "previousFrameId": previous_id,
        "previousFrameHash": previous_hash,
        "frameHash": None
    }
    frame_hash = compute_frame_hash(frame)
    frame["frameHash"] = frame_hash

    try:
        AUDIT_STORE.put(frame_id, frame, AUDIT_TTL_SECONDS)
        AUDIT_STORE.set_chain_head_hash(AUDIT_CHAIN_ID, frame_hash)
        AUDIT_STORE.set_chain_head_id(AUDIT_CHAIN_ID, frame_id)
    except Exception:
        persistence = dict(persistence)
        persistence["persisted"] = False
        persistence["consistency"] = "eventual"
        frame["persistence"] = persistence

    response.headers["X-Timeline-Frame-Id"] = frame_id
    response.headers["X-Frame-Hash"] = frame_hash

    if H_AI_ASK_LAT is not None:
        H_AI_ASK_LAT.record(time.perf_counter() - t0)

    return AiAskResponse(
        answer=ans,
        model=os.path.basename(MODEL_DIR.rstrip("/")) or "katopu-model",
        timelineFrameId=frame_id,
        persistence=persistence,
        signedEvidence=signed,
        chain={"chainId": AUDIT_CHAIN_ID, "previousFrameId": previous_id, "previousFrameHash": previous_hash, "frameHash": frame_hash, "hashAlg": "sha256", "domainSeparator": DOMAIN_SEPARATOR.decode("utf-8")},
    )

@app.get("/timeline/frames/{frameId}")
def get_frame(frameId: str, request: Request, response: Response):
    rid = get_request_id(request)
    response.headers["X-Request-Id"] = rid
    add_trace_headers(response)
    obj = AUDIT_STORE.get(frameId)
    if not obj:
        raise HTTPException(status_code=404, detail="Frame not found or expired.")
    return obj

@app.get("/timeline/frames/{frameId}/verify")
def verify_frame(frameId: str, depth: int = 1, request: Request = None, response: Response = None):
    if depth < 1: depth = 1
    if depth > 100: depth = 100

    frame = AUDIT_STORE.get(frameId)
    if not frame:
        raise HTTPException(status_code=404, detail="Frame not found or expired.")

    # Verify chain by walking back (recompute hashes for frames that exist in store)
    checked = 0
    hash_ok = True
    reason = None
    cur = frame
    while cur and checked < depth:
        expected = compute_frame_hash(cur)
        if expected != cur.get("frameHash"):
            hash_ok = False
            reason = f"frameHash mismatch at frameId={cur.get('id')}"
            break
        prev_id = cur.get("previousFrameId")
        prev_hash = cur.get("previousFrameHash")
        if prev_id:
            prev_frame = AUDIT_STORE.get(prev_id)
            if not prev_frame:
                hash_ok = False
                reason = f"previousFrameId not found: {prev_id}"
                break
            if prev_hash and prev_hash != prev_frame.get("frameHash"):
                hash_ok = False
                reason = f"previousFrameHash mismatch: expected {prev_hash}, got {prev_frame.get('frameHash')}"
                break
            cur = prev_frame
        else:
            cur = None
        checked += 1

    # Signature verify (target frame)
    sig_report = {"ok": False, "status": "unsigned"}
    if frame.get("signedEvidence"):
        sig_report = verify_evidence(frame["signedEvidence"])
    verified = bool(hash_ok and sig_report.get("ok"))

    # Proof bundle
    keyring_proof = build_keyring_proof()
    chain_proof = build_chain_proof(frame, depth)
    signature_proof = build_signature_proof(frame, sig_report)
    bundle = {"canonicalization": CANONICALIZATION_INFO, "keyring": keyring_proof, "chain": chain_proof, "signature": signature_proof}
    bundle["bundleHashSha256"] = build_bundle_hash(bundle)

    return {
        "frameId": frameId,
        "verified": verified,
        "hashChain": {"ok": hash_ok, "checkedDepth": checked if checked else 1, "domainSeparator": DOMAIN_SEPARATOR.decode("utf-8"), "reason": reason},
        "signature": {"ok": bool(sig_report.get("ok")), "status": sig_report.get("status"), "keyId": sig_report.get("keyId"), "alg": sig_report.get("alg"), "reason": sig_report.get("reason")},
        "proofBundle": bundle,
        "time": now_iso(),
    }
