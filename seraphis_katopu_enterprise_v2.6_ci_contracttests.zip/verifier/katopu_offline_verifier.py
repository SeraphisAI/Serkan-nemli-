#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Katopu Offline Verifier (v2.6) — single-file CLI

Verifies a Katopu v2.6 proof bundle offline, using:
- proofBundle (from /timeline/frames/{id}/verify output OR extracted object)
- keyring snapshot (optional external snapshot to pin trust)
- a TimelineFrame JSON (as stored/fetched from /timeline/frames/{id})

Checks:
1) proofBundle.bundleHashSha256
2) keyring snapshot hash (proofBundle.keyring.snapshotHashSha256)
3) chain proof hash (proofBundle.chain.proofHashSha256)
4) signature proof hash (proofBundle.signature.proofHashSha256)
5) frameHash integrity (domain separation + RFC 8785 JCS canonicalization)
6) payloadCanonicalSha256 integrity
7) PQC signature verification (optional; requires `oqs` python bindings)

Exit codes:
- 0: all mandatory checks pass; signature verified if available or not required
- 2: one or more mandatory checks failed
- 3: mandatory checks pass but signature verification unavailable (and not strict)

Usage examples:
  python katopu_offline_verifier_v2.6.py --frame frame.json --proof verify_response.json
  python katopu_offline_verifier_v2.6.py --frame frame.json --proof proofBundle.json
  python katopu_offline_verifier_v2.6.py --frame frame.json --proof verify_response.json --keyring keyring_snapshot.json
  python katopu_offline_verifier_v2.6.py --frame frame.json --proof verify_response.json --strict-signature
"""

from __future__ import annotations

import argparse
import base64
import hashlib
import json
import sys
from dataclasses import dataclass
from decimal import Decimal
from typing import Any, Dict, Optional, Tuple

# Optional PQC verification (liboqs python bindings)
try:
    import oqs  # type: ignore
    PQC_AVAILABLE = True
except Exception:
    oqs = None  # type: ignore
    PQC_AVAILABLE = False


# -----------------------------
# RFC 8785 JCS (pragmatic, deterministic)
# -----------------------------
def _json_escape_string(s: str) -> str:
    out = ['"']
    for ch in s:
        code = ord(ch)
        if ch == '"':
            out.append('\\"')
        elif ch == '\\':
            out.append('\\\\')
        elif code < 0x20:
            out.append("\\u%04x" % code)
        else:
            out.append(ch)
    out.append('"')
    return "".join(out)


def _jcs_number(n: Any) -> str:
    # Pragmatic RFC8785-like formatting.
    # Use Decimal for stability; JSON input is parsed with parse_float=Decimal.
    if isinstance(n, bool) or n is None:
        raise ValueError("Not a number")
    if isinstance(n, int):
        return str(n)

    if isinstance(n, Decimal):
        d = n
    elif isinstance(n, float):
        if n != n or n in (float("inf"), float("-inf")):
            raise ValueError("NaN/Infinity not allowed in JSON")
        d = Decimal(repr(n))
    else:
        d = Decimal(str(n))

    if d == 0:
        return "0"

    s = format(d.normalize(), "f")
    if "." in s:
        s = s.rstrip("0").rstrip(".")
    if s in ("-0", "+0"):
        s = "0"

    # switch to scientific if too long
    if len(s.replace("-", "")) > 21:
        s2 = format(d.normalize(), "E").replace("E", "e")
        mant, ex = s2.split("e", 1)
        ex = ex.lstrip("+")
        ex = ex.lstrip("0") or "0"
        if "." in mant:
            mant = mant.rstrip("0").rstrip(".")
        s = mant + "e" + ex
    return s


def jcs_dumps(obj: Any) -> str:
    if obj is None:
        return "null"
    if obj is True:
        return "true"
    if obj is False:
        return "false"
    if isinstance(obj, str):
        return _json_escape_string(obj)
    if isinstance(obj, (int, float, Decimal)):
        return _jcs_number(obj)
    if isinstance(obj, (list, tuple)):
        return "[" + ",".join(jcs_dumps(v) for v in obj) + "]"
    if isinstance(obj, dict):
        items = []
        for k in sorted(obj.keys()):
            if not isinstance(k, str):
                raise ValueError("JSON object keys must be strings")
            items.append(_json_escape_string(k) + ":" + jcs_dumps(obj[k]))
        return "{" + ",".join(items) + "}"
    raise ValueError(f"Unsupported type for JCS: {type(obj)}")


def jcs_bytes(obj: Any) -> bytes:
    return jcs_dumps(obj).encode("utf-8")


def sha256_hex(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def hash_obj(obj: Any) -> str:
    return sha256_hex(jcs_bytes(obj))


# -----------------------------
# Loading helpers
# -----------------------------
def load_json(path: str) -> Any:
    with open(path, "r", encoding="utf-8") as f:
        # parse_float=Decimal reduces float ambiguity for JCS.
        return json.load(f, parse_float=Decimal)


def extract_proof_bundle(obj: Any) -> Dict[str, Any]:
    if isinstance(obj, dict) and "proofBundle" in obj and isinstance(obj["proofBundle"], dict):
        return obj["proofBundle"]
    if isinstance(obj, dict) and "bundleHashSha256" in obj:
        return obj
    raise ValueError("Could not find proofBundle (expected key 'proofBundle' or an object with 'bundleHashSha256').")


# -----------------------------
# Core checks
# -----------------------------
@dataclass
class CheckResult:
    ok: bool
    name: str
    details: Dict[str, Any]


def compute_frame_hash(frame: Dict[str, Any], domain_separator: str) -> str:
    f = dict(frame)
    f.pop("frameHash", None)
    prev = (f.get("previousFrameHash") or "").encode("utf-8")
    dom = domain_separator.encode("utf-8")
    return sha256_hex(dom + jcs_bytes(f) + prev)


def verify_bundle_hash(bundle: Dict[str, Any]) -> CheckResult:
    expected = bundle.get("bundleHashSha256")
    core = {
        "canonicalization": bundle.get("canonicalization"),
        "keyring": bundle.get("keyring"),
        "chain": bundle.get("chain"),
        "signature": bundle.get("signature"),
    }
    computed = hash_obj(core)
    ok = isinstance(expected, str) and expected == computed
    return CheckResult(ok, "bundleHash", {"expected": expected, "computed": computed})


def verify_keyring_snapshot(bundle: Dict[str, Any], pinned_snapshot: Optional[Dict[str, Any]]) -> Tuple[CheckResult, Dict[str, Any]]:
    keyring = bundle.get("keyring") or {}
    expected = keyring.get("snapshotHashSha256")
    snapshot_in_bundle = keyring.get("snapshot")
    snapshot = pinned_snapshot if pinned_snapshot is not None else snapshot_in_bundle
    if not isinstance(snapshot, dict):
        return CheckResult(False, "keyringSnapshotHash", {"error": "No keyring snapshot available."}), {}

    computed = hash_obj(snapshot)
    ok = isinstance(expected, str) and expected == computed

    # If both present, also ensure pinned snapshot hash == bundle snapshot hash (pinning check)
    pin_ok = True
    if pinned_snapshot is not None and isinstance(snapshot_in_bundle, dict):
        pin_ok = (hash_obj(pinned_snapshot) == hash_obj(snapshot_in_bundle))

    details = {"expected": expected, "computed": computed, "pinnedUsed": pinned_snapshot is not None, "pinMatchesBundleSnapshot": pin_ok}
    return CheckResult(ok and pin_ok, "keyringSnapshotHash", details), snapshot


def verify_chain_proof_hash(bundle: Dict[str, Any]) -> CheckResult:
    chain = bundle.get("chain") or {}
    expected = chain.get("proofHashSha256")
    core = dict(chain)
    core.pop("proofHashSha256", None)
    computed = hash_obj(core)
    ok = isinstance(expected, str) and expected == computed
    return CheckResult(ok, "chainProofHash", {"expected": expected, "computed": computed})


def verify_signature_proof_hash(bundle: Dict[str, Any]) -> CheckResult:
    sig = bundle.get("signature") or {}
    expected = sig.get("proofHashSha256")
    core = dict(sig)
    core.pop("proofHashSha256", None)
    computed = hash_obj(core)
    ok = isinstance(expected, str) and expected == computed
    return CheckResult(ok, "signatureProofHash", {"expected": expected, "computed": computed})


def verify_chain_internal_linkage(bundle: Dict[str, Any]) -> CheckResult:
    """
    Verifies that for steps[i], steps[i].previousFrameHash == steps[i+1].frameHash (when both present).
    This doesn't recompute hashes of previous frames (offline), but checks the proof is self-consistent.
    """
    chain = bundle.get("chain") or {}
    steps = chain.get("steps") or []
    if not isinstance(steps, list) or len(steps) < 2:
        return CheckResult(True, "chainInternalLinkage", {"note": "Not enough steps to check linkage."})

    mismatches = []
    for i in range(len(steps) - 1):
        a = steps[i] or {}
        b = steps[i + 1] or {}
        prev_hash = a.get("previousFrameHash")
        next_hash = b.get("frameHash")
        if prev_hash is not None and next_hash is not None and prev_hash != next_hash:
            mismatches.append({"index": i, "previousFrameHash": prev_hash, "nextFrameHash": next_hash})

    ok = len(mismatches) == 0
    return CheckResult(ok, "chainInternalLinkage", {"mismatches": mismatches, "checkedPairs": len(steps) - 1})


def verify_frame_hash(frame: Dict[str, Any], bundle: Dict[str, Any]) -> CheckResult:
    chain = bundle.get("chain") or {}
    domain = chain.get("domainSeparator") or "KATOPU|AUDIT|v2.6|"
    computed = compute_frame_hash(frame, str(domain))
    expected = frame.get("frameHash")
    ok = isinstance(expected, str) and expected == computed

    # Optional: if chain steps present, cross-check head step hash
    head_step_hash = None
    try:
        steps = chain.get("steps") or []
        if isinstance(steps, list) and steps:
            head_step_hash = steps[0].get("frameHash")
            if isinstance(head_step_hash, str):
                ok = ok and (head_step_hash == expected)
    except Exception:
        pass

    return CheckResult(ok, "frameHash", {"expected": expected, "computed": computed, "domainSeparator": domain, "headStepFrameHash": head_step_hash})


def verify_payload_hash(frame: Dict[str, Any], bundle: Dict[str, Any]) -> CheckResult:
    """
    Verifies signature proof payloadCanonicalSha256 matches JCS(payload) hash,
    where payload is frame.signedEvidence.payload.
    """
    sigp = bundle.get("signature") or {}
    expected = sigp.get("payloadCanonicalSha256")

    se = frame.get("signedEvidence") or {}
    payload = se.get("payload")

    computed = hash_obj(payload)
    ok = isinstance(expected, str) and expected == computed
    return CheckResult(ok, "payloadCanonicalSha256", {"expected": expected, "computed": computed})


def _keyring_pubkey_by_id(snapshot: Dict[str, Any], key_id: str) -> Optional[str]:
    keys = snapshot.get("keys") or []
    if not isinstance(keys, list):
        return None
    for k in keys:
        if isinstance(k, dict) and k.get("keyId") == key_id:
            return k.get("publicKeyB64")
    return None


def verify_pqc_signature(frame: Dict[str, Any], keyring_snapshot: Dict[str, Any]) -> CheckResult:
    se = frame.get("signedEvidence") or {}
    sig = (se.get("pqcSignature") or {})
    status = sig.get("status")
    alg = sig.get("alg")
    key_id = sig.get("keyId")
    sig_b64 = sig.get("signatureB64")
    payload = se.get("payload")

    if status != "signed":
        return CheckResult(False, "pqcSignatureVerify", {"ok": False, "status": status, "reason": "Evidence is not marked 'signed'."})

    if not (isinstance(alg, str) and isinstance(key_id, str) and isinstance(sig_b64, str)):
        return CheckResult(False, "pqcSignatureVerify", {"ok": False, "reason": "Missing alg/keyId/signatureB64 in signed evidence."})

    pub_b64 = _keyring_pubkey_by_id(keyring_snapshot, key_id)
    if not isinstance(pub_b64, str):
        return CheckResult(False, "pqcSignatureVerify", {"ok": False, "reason": "keyId not found in keyring snapshot.", "keyId": key_id})

    if not PQC_AVAILABLE:
        return CheckResult(False, "pqcSignatureVerify", {"ok": False, "status": "unavailable", "reason": "oqs library not installed.", "alg": alg, "keyId": key_id})

    try:
        pub = base64.b64decode(pub_b64)
        signature = base64.b64decode(sig_b64)
        msg = jcs_bytes(payload)
        verifier = oqs.Signature(alg)
        ok = bool(verifier.verify(msg, signature, pub))
        return CheckResult(ok, "pqcSignatureVerify", {"ok": ok, "alg": alg, "keyId": key_id})
    except Exception as e:
        return CheckResult(False, "pqcSignatureVerify", {"ok": False, "alg": alg, "keyId": key_id, "error": str(e)})


def main() -> int:
    ap = argparse.ArgumentParser(description="Katopu Offline Verifier v2.6 (proof bundle + RFC8785 JCS)")
    ap.add_argument("--frame", required=True, help="Path to TimelineFrame JSON")
    ap.add_argument("--proof", required=True, help="Path to verify response JSON or proofBundle JSON")
    ap.add_argument("--keyring", default="", help="Optional path to a keyring snapshot JSON (pin trust)")
    ap.add_argument("--strict-signature", action="store_true", help="Fail if PQC signature cannot be verified")
    ap.add_argument("--json", action="store_true", help="Output machine-readable JSON report only")
    args = ap.parse_args()

    frame = load_json(args.frame)
    proof_src = load_json(args.proof)
    bundle = extract_proof_bundle(proof_src)

    pinned_snapshot = load_json(args.keyring) if args.keyring else None
    if pinned_snapshot is not None and isinstance(pinned_snapshot, dict) and "snapshotAt" not in pinned_snapshot and "keys" not in pinned_snapshot:
        # tolerate files that wrap snapshot inside {snapshot: ...}
        if "snapshot" in pinned_snapshot and isinstance(pinned_snapshot["snapshot"], dict):
            pinned_snapshot = pinned_snapshot["snapshot"]

    if not isinstance(frame, dict):
        raise SystemExit("Frame JSON must be an object.")
    if not isinstance(bundle, dict):
        raise SystemExit("proofBundle must be an object.")

    results = []
    results.append(verify_bundle_hash(bundle))

    kr_res, kr_snapshot = verify_keyring_snapshot(bundle, pinned_snapshot)
    results.append(kr_res)

    results.append(verify_chain_proof_hash(bundle))
    results.append(verify_signature_proof_hash(bundle))
    results.append(verify_chain_internal_linkage(bundle))
    results.append(verify_frame_hash(frame, bundle))
    results.append(verify_payload_hash(frame, bundle))

    sig_res = verify_pqc_signature(frame, kr_snapshot) if isinstance(kr_snapshot, dict) else CheckResult(False, "pqcSignatureVerify", {"ok": False, "reason": "No keyring snapshot."})
    results.append(sig_res)

    mandatory = [r for r in results if r.name != "pqcSignatureVerify"]
    mandatory_ok = all(r.ok for r in mandatory)

    sig_ok = sig_res.ok
    sig_unavailable = (sig_res.details.get("status") == "unavailable")

    overall_ok = mandatory_ok and (sig_ok or (not args.strict_signature and sig_unavailable))
    exit_code = 0 if overall_ok else (3 if (mandatory_ok and not args.strict_signature and sig_unavailable) else 2)

    report = {
        "tool": "katopu-offline-verifier",
        "version": "2.6.0",
        "overallOk": overall_ok,
        "exitCode": exit_code,
        "pqcAvailable": PQC_AVAILABLE,
        "strictSignature": bool(args.strict_signature),
        "checks": [{ "name": r.name, "ok": r.ok, **r.details } for r in results],
    }

    if args.json:
        print(json.dumps(report, ensure_ascii=False, indent=2))
        return exit_code

    print("Katopu Offline Verifier v2.6")
    print(f"overallOk={overall_ok} exitCode={exit_code} pqcAvailable={PQC_AVAILABLE} strictSignature={args.strict_signature}")
    for r in results:
        mark = "✅" if r.ok else "❌"
        print(f"{mark} {r.name}")
        if r.name in {"bundleHash", "keyringSnapshotHash", "chainProofHash", "signatureProofHash", "frameHash", "payloadCanonicalSha256"}:
            exp = r.details.get("expected")
            comp = r.details.get("computed")
            if exp is not None or comp is not None:
                print(f"   expected={exp}")
                print(f"   computed={comp}")
        if r.name == "pqcSignatureVerify":
            print(f"   details={r.details}")

    return exit_code


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        raise SystemExit(130)
