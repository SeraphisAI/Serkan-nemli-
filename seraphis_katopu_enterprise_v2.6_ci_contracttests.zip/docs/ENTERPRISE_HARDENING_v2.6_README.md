# Katopu Enterprise Hardening v2.6 (FINAL)

## What you get
- OpenAPI: `katopu-quantum-core-openapi.en.ai.v2.6.enterprise_hardening.yaml`
- Service: `katopu_ai_service_fastapi.v2.6.enterprise_hardening.py`
- Offline verifier: `katopu_offline_verifier_v2.6.py`

## v2.6 changes
### Proof bundle (portable verification attestation)
`GET /timeline/frames/{frameId}/verify?depth=K` returns `proofBundle`:
- `keyring.snapshotHashSha256`
- `chain.proofHashSha256`
- `signature.proofHashSha256`
- `bundleHashSha256`

### RFC 8785 JCS deterministic canonicalization
All hashing + PQC signature payload bytes use RFC 8785 JCS.

### Domain separation
`frameHash = sha256("KATOPU|AUDIT|v2.6|" || JCS(frame_wo_frameHash) || prevHashUtf8)`

## Run (Redis recommended)
```bash
pip install fastapi uvicorn pyyaml torch transformers redis
export MODEL_DIR=./katopu-quantum-core-model
export OPENAPI_PATH=./katopu-quantum-core-openapi.en.ai.v2.6.enterprise_hardening.yaml
export REDIS_URL=redis://localhost:6379/0
export AUDIT_STORE=redis
uvicorn katopu_ai_service_fastapi.v2.6.enterprise_hardening:app --host 0.0.0.0 --port 8080
```

## Offline verify
```bash
python katopu_offline_verifier_v2.6.py --frame frame.json --proof verify_response.json
```

## PQC optional
```bash
pip install oqs
export PQC_SIGNING_ENABLED=true
export PQC_SIG_ALG=ML-DSA-65
export PQC_PERSIST_SECRET_KEYS=false
```
