# Katopu Enterprise v2.6 — CI + Contract Tests Pack (Seraphis)

Bu paket, **OpenAPI (v2.6)** üzerine:
- GitHub Actions **CI**
- **Schemathesis + Prism** contract tests
- PR’da **breaking change** kilidi (oasdiff)
ekler.

## Klasörler
- `openapi/openapi.yaml` — kaynak OpenAPI
- `tests/contract/` — preset generator + hooks + local run script
- `.github/workflows/` — PR gate (breaking) + contract-tests
- `scripts/` — local yardımcı komutlar

## Local hızlı test
```bash
bash scripts/run_contract_tests_local.sh
```

## PR Breaking Changes
PR açıldığında, base branch OpenAPI ile karşılaştırılır ve **ERR seviyesinde breaking change** varsa workflow fail eder.
