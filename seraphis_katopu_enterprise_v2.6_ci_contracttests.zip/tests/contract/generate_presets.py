#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Generate Schemathesis presets from OpenAPI.

Outputs: tests/contract/presets.json

Heuristics:
- base_url from servers[0].url if present, else http://127.0.0.1:8080
- security header templates extracted from components.securitySchemes (best-effort)
"""

from __future__ import annotations
import json
import re
from pathlib import Path

def _extract_servers(openapi_text: str) -> list[str]:
    # Best-effort YAML parse via regex (keeps dependencies minimal).
    # Looks for:
    # servers:
    #   - url: https://...
    urls = []
    in_servers = False
    for line in openapi_text.splitlines():
        if re.match(r"^\s*servers\s*:\s*$", line):
            in_servers = True
            continue
        if in_servers:
            m = re.match(r"^\s*-\s*url\s*:\s*(.+)\s*$", line)
            if m:
                url = m.group(1).strip().strip('"').strip("'")
                urls.append(url)
            # stop when leaving indentation block (very rough)
            if re.match(r"^[^\s]", line) and not line.strip().startswith("-"):
                break
    return urls

def _guess_security_headers(openapi_text: str) -> dict[str, str]:
    headers = {}
    # Very rough: detect bearer
    if re.search(r"type\s*:\s*http\s*\n\s*scheme\s*:\s*bearer", openapi_text, re.I):
        headers["Authorization"] = "Bearer ${API_TOKEN}"
    # detect apiKey in header with name
    for m in re.finditer(r"type\s*:\s*apiKey\s*\n(?:.|\n)*?in\s*:\s*header\s*\n(?:.|\n)*?name\s*:\s*([^\n]+)", openapi_text, re.I):
        name = m.group(1).strip().strip('"').strip("'")
        headers[name] = f"${{{name.replace('-', '_').upper()}}}"
    return headers

def main():
    root = Path(__file__).resolve().parents[2]
    schema_path = root / "openapi" / "openapi.yaml"
    text = schema_path.read_text(encoding="utf-8", errors="replace")
    servers = _extract_servers(text)
    headers = _guess_security_headers(text)

    presets = {
        "schema": str(schema_path.as_posix()),
        "presets": {
            "local": {
                "base_url": servers[0] if servers else "http://127.0.0.1:8080",
                "checks": "all",
                "max_examples": 50,
                "headers_template": headers
            },
            "prism": {
                "base_url": "http://127.0.0.1:4010",
                "checks": "all",
                "max_examples": 50,
                "headers_template": headers
            }
        }
    }

    out_path = root / "tests" / "contract" / "presets.json"
    out_path.write_text(json.dumps(presets, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print("wrote", out_path)

if __name__ == "__main__":
    main()
