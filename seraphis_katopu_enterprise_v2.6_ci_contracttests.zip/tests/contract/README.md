# Contract Tests — Schemathesis + Prism

## Amaç
- OpenAPI şemasından **otomatik** test case üret (Schemathesis)
- Şemayı **anında** mock’la (Prism) ve PR’da en azından:
  - şema parse edilebiliyor mu?
  - request/response şekilleri tutarlı mı?
  - Schemathesis generator şemayı dolaşabiliyor mu?
kontrolünü kilitle.

> Not: Bu repo’daki FastAPI servis dosyası `torch/transformers` gibi ağır bağımlılıklar içerdiği için,
CI’da gerçek servis ayağa kaldırmak hedeflenmedi. İstersen ayrıca “lightweight stub server” ekleyip
Schemathesis’i doğrudan ona koşturacak şekilde genişletiriz.

## Local çalıştır
```bash
npm i -g @stoplight/prism-cli
bash scripts/run_contract_tests_local.sh
```

## Preset üretimi
```bash
python tests/contract/generate_presets.py
cat tests/contract/presets.json
```

## GitHub Actions
- `.github/workflows/contract-tests.yml` → Prism mock + Schemathesis
- `.github/workflows/openapi-breaking.yml` → PR breaking changes gate (oasdiff)
