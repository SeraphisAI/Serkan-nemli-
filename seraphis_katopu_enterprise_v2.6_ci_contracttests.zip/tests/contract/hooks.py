import os
import schemathesis

@schemathesis.hook
def before_call(ctx, case, **kwargs):
    # Inject auth headers if provided; Prism mock usually doesn't require them,
    # but real environments do.
    if case.headers is None:
        case.headers = {}
    token = os.getenv("API_TOKEN")
    if token:
        case.headers["Authorization"] = f"Bearer {token}"
    pqc = os.getenv("PQC_SESSION")
    if pqc:
        case.headers["X-PQC-Session"] = pqc
