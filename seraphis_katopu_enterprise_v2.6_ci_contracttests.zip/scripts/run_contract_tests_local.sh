#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

SCHEMA="openapi/openapi.yaml"
PORT="${PRISM_PORT:-4010}"
BASE_URL="http://127.0.0.1:${PORT}"

mkdir -p artifacts

# 1) generate presets (spec-aware)
python3 tests/contract/generate_presets.py

# 2) start prism mock
if ! command -v prism >/dev/null 2>&1; then
  echo "prism not found. Install: npm i -g @stoplight/prism-cli"
  exit 2
fi

echo "[+] Starting Prism mock on ${BASE_URL}"
prism mock "$SCHEMA" --port "${PORT}" --errors --dynamic > artifacts/prism.log 2>&1 &
PRISM_PID=$!

cleanup () {
  echo "[+] Stopping Prism (pid=${PRISM_PID})"
  kill "${PRISM_PID}" >/dev/null 2>&1 || true
}
trap cleanup EXIT

# wait for prism
for i in {1..30}; do
  if curl -sSf "${BASE_URL}/" >/dev/null 2>&1; then
    break
  fi
  sleep 1
done

# 3) run schemathesis
python3 -m pip install -q -r tests/contract/requirements.txt

echo "[+] Running Schemathesis against Prism"
schemathesis run "$SCHEMA"   --base-url "$BASE_URL"   --checks all   --max-examples 50   --report-junit-path artifacts/schemathesis-junit.xml   --show-errors-tracebacks   --verbosity 1   -H "Authorization: Bearer ${API_TOKEN:-test}"   -H "X-PQC-Session: ${PQC_SESSION:-test}"   --hooks tests.contract.hooks

echo "[+] Done. JUnit: artifacts/schemathesis-junit.xml"
