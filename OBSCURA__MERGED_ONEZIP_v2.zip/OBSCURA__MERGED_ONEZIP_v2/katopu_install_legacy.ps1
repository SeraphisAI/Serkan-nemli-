# Katopu GenLab Ultra - One-Click Install (Windows)
# - Stops old stack (default path: C:\katopu_ultra_max\katopu)
# - Brings up new stack (this folder)
# - Runs smoke tests

[CmdletBinding()]
param(
  [string]$OldRepoRoot = "C:\\katopu_ultra_max\\katopu",
  [switch]$NukeDockerData,          # removes compose volumes for OLD + NEW
  [switch]$FullPrune,              # WARNING: docker system prune -af + builder/volume prune
  [switch]$BackupOldRepo           # renames old repo to *_backup_TIMESTAMP instead of leaving it
)

$ErrorActionPreference = 'Stop'

function Section([string]$t) { Write-Host "`n=== $t ===" -ForegroundColor Cyan }
function Ok([string]$t) { Write-Host "OK  : $t" -ForegroundColor Green }
function Warn([string]$t) { Write-Host "WARN: $t" -ForegroundColor Yellow }
function Fail([string]$t) { Write-Host "FAIL: $t" -ForegroundColor Red }

function Ensure-Utf8 {
  try { chcp 65001 | Out-Null } catch {}
  try { $global:OutputEncoding = [Console]::OutputEncoding = [Text.UTF8Encoding]::new() } catch {}
}

function Is-Admin {
  return ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()
    ).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Relaunch-AsAdmin {
  if (Is-Admin) { return }
  Warn "Admin değilim -> UAC ile Admin PowerShell açıyorum..."
  $argList = @('-NoProfile','-ExecutionPolicy','Bypass','-File', $MyInvocation.MyCommand.Path)
  if ($OldRepoRoot) { $argList += @('-OldRepoRoot', $OldRepoRoot) }
  if ($NukeDockerData) { $argList += '-NukeDockerData' }
  if ($FullPrune) { $argList += '-FullPrune' }
  if ($BackupOldRepo) { $argList += '-BackupOldRepo' }
  Start-Process powershell -Verb RunAs -ArgumentList $argList | Out-Null
  exit 0
}

function Test-RebootPending {
  $keys = @(
    'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending',
    'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired'
  )
  foreach ($k in $keys) { if (Test-Path $k) { return $true } }
  try {
    $p = Get-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager' -Name PendingFileRenameOperations -ErrorAction SilentlyContinue
    if ($p) { return $true }
  } catch {}
  return $false
}

function Try-Run([string]$cmd) {
  try { iex $cmd | Out-Host }
  catch { Warn "Komut hata verdi ama devam: $cmd`n$($_.Exception.Message)" }
}

function Stop-Compose([string]$repoRoot, [string]$label) {
  $infra = Join-Path $repoRoot 'infra'
  $compose = Join-Path $infra 'docker-compose.yml'
  if (-not (Test-Path $compose)) {
    Warn "$label infra bulunamadı: $compose"
    return
  }
  Section "$label stack durduruluyor"
  Push-Location $infra
  Try-Run 'docker compose down --remove-orphans'
  if ($NukeDockerData) {
    Try-Run 'docker compose down --remove-orphans --volumes'
  }
  Pop-Location
}

function Backup-Repo([string]$repoRoot) {
  if (-not (Test-Path $repoRoot)) { return }
  $stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
  $dst = "${repoRoot}_backup_$stamp"
  Section "Eski repo yedekleniyor"
  Move-Item -Path $repoRoot -Destination $dst -Force
  Ok "Eski repo -> $dst"
}

function Ensure-Docker {
  Section 'Docker kontrol'
  Try-Run 'docker version'
  Try-Run 'docker compose version'
  # engine kontrol
  try { docker info | Out-Null; Ok 'Docker engine hazır.' }
  catch {
    throw "Docker engine çalışmıyor. Docker Desktop'ı aç ve Linux (WSL2) engine aktif olsun."
  }
}

function Bringup-New([string]$newRoot) {
  $infra = Join-Path $newRoot 'infra'
  $compose = Join-Path $infra 'docker-compose.yml'
  if (-not (Test-Path $compose)) { throw "Yeni proje infra/docker-compose.yml yok: $compose" }

  Section 'Yeni stack ayağa kaldırılıyor'
  Push-Location $infra
  Try-Run 'docker compose pull'
  Try-Run 'docker compose up -d --build'
  Try-Run 'docker compose ps'
  Pop-Location
}

function Smoke-Test([string]$newRoot) {
  $self = Join-Path $newRoot 'infra\self_test.ps1'
  Section 'Self-test'
  if (Test-Path $self) {
    & $self
    Ok 'Self-test geçti.'
  } else {
    Warn "self_test.ps1 yok: $self (health yine de kontrol edilecek)"
    $r = Invoke-RestMethod -Uri 'http://localhost:8000/health' -TimeoutSec 5
    if ($r.ok -ne $true) { throw 'Health başarısız.' }
  }
}

# ----------------- MAIN -----------------
if (-not $MyInvocation.MyCommand.Path) { throw 'Bu script dosya olarak çalıştırılmalı: .\\katopu_install.ps1' }
Ensure-Utf8
Relaunch-AsAdmin

Section 'Başlangıç'
$Here = Split-Path -Parent $MyInvocation.MyCommand.Path
Ok "Yeni proje: $Here"
Ok "Eski repo (varsa): $OldRepoRoot"
Ok "NukeDockerData: $([bool]$NukeDockerData)"
Ok "FullPrune: $([bool]$FullPrune)"
Ok "BackupOldRepo: $([bool]$BackupOldRepo)"

if (Test-RebootPending) {
  Warn 'Windows restart bekliyor görünüyor. Tavsiye: bir kez yeniden başlat, sonra tekrar çalıştır.'
}

Ensure-Docker

# Old stack stop (+ optional backup)
if ($BackupOldRepo -and (Test-Path $OldRepoRoot)) {
  Stop-Compose $OldRepoRoot 'ESKİ'
  Backup-Repo $OldRepoRoot
} else {
  Stop-Compose $OldRepoRoot 'ESKİ'
}

# New stack stop (idempotent)
Stop-Compose $Here 'YENİ'

if ($FullPrune) {
  Section 'Docker tam temizlik (DİKKAT: her şeyi silebilir)'
  Try-Run 'docker system prune -af'
  Try-Run 'docker builder prune -af'
  Try-Run 'docker volume prune -f'
}

Bringup-New $Here
Smoke-Test $Here

Section 'BİTTİ ✅'
Ok 'UI   : http://localhost:8501'
Ok 'API  : http://localhost:8000'
Ok 'DOCS : http://localhost:8000/docs'
