# CHANGELOG

## v0.3.0 — UI/UX Productization + Parity Restore
- Pro UI layout: sticky top bar + fixed sidebar nav + stabilized cards (no overflow/wrap regressions)
- Parity restored:
  - Multi‑Gene Editor (import/export FASTA, multi‑paste, chunk view, meta)
  - Workspace DNA/RNA Sequence input (IUPAC validation, normalize, position-based errors)
  - Last 20 Reports list (open/pin/compare/export)
  - Compare Runs (A/B before-after + inline diff + side-by-side diff)
- Reliability:
  - Engine Auto (API if healthy else Local fallback) + clear diagnostics
  - `/run?sequence=` API contract aligned
- Export:
  - JSON / XLSX / PDF / Bundle ZIP exports
- Tests:
  - Added unit tests for seq validation, gene store, UI contract CSS
- Docs:
  - UI design system, improvements map, parity checklist, smoke test checklist
