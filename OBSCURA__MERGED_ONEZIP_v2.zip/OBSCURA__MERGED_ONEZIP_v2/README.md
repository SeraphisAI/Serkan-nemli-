# Katopu GenLab — ULTRA Product UI + Parity (v0.3.0)

Bu proje **in-silico** (metin tabanlı) DNA edit simülasyonu yapar.
- Wet-lab / patojen tasarımı gibi yüksek riskli içerikler hedeflenmez.
- **Policy pack** belirli niyet desenlerini bloklar ve (opsiyonel) loglarda sequence maskeler.

## Neler var?

- **API** (FastAPI): `/health`, `/run`, `/nl/spec`, `/edit/apply` ve `/policy`...
- **UI** (Streamlit, ürünleştirilmiş):
  - **Workspace (Lab)**: DNA/RNA input + Run pipeline (Parse→Spec→Apply→Validate→Report)
  - **Always Diff**: Before/After + INLINE renkli diff + Side-by-side diff
  - **Last 20 Reports**: Aç / Pin / Compare / Export
  - **Multi‑Gene Editor**: FASTA import/export, multi‑paste, duplike, chunk view + meta
  - **Compare Runs**: 2 rapor seç → karşılaştır + diff
  - **Policy Studio**: base/override edit + simulate (explain)
  - **Diagnostics**: Test Connection (/health)
  - **Telemetry**: varsayılan OFF (güvenli)


## Hızlı Başlat (Docker)

```bash
cd infra
docker compose up -d --build
```

- UI: http://localhost:8501
- API Docs: http://localhost:8000/docs
- Health: http://localhost:8000/health

Kapatmak için:
```bash
cd infra
docker compose down
```

## Windows (PowerShell)

- `windows_shortcuts/start_katopu.ps1` çalıştırın.
- `windows_shortcuts/api_examples.ps1` örnek çağrılar içerir.

> PowerShell'de `curl` alias çakışmaları yüzünden `curl.exe` veya `Invoke-RestMethod` kullanın.

## Policy Override (UI Policy Panel)

- Base policy dosyası: `policy/policies/default.policy.json`
- Override dosyası (UI üzerinden yazılır): `data/policy_override.json`
  - Override var ise API/UI otomatik bunu yükler.
  - Override’ı silmek için Policy tabında "Override sıfırla".

> Güvenlik için: `KATOPU_POLICY_MUTABLE=false` iken API tarafındaki `POST /policy/*` endpoint'leri kapalıdır.

## Telemetry

Telemetry varsayılan kapalı.

`.env` (infra dizininde) içine:
- `KATOPU_TELEMETRY_ENABLED=true`
- `KATOPU_TELEMETRY_SAMPLE_RATE=0.1`

Dosyalar `/data/` altında tutulur (docker volume ile kalıcı):
- `/data/telemetry.jsonl`
- `/data/policy_audit.log`

## Test

Yerelde:
```bash
pip install -r requirements-dev.txt
pytest -q
```

## Migration

Örnek:
```bash
python -m migrations.migrate --in export.json --out export_v0_2_0.json --to 0.2.0
```
