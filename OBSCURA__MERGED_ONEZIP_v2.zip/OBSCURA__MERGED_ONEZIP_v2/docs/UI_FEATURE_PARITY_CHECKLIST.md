# UI Feature Parity Checklist (v0.3.0)

| Özellik | Durum | Not |
|---|---:|---|
| Multi‑Gene Editor | VAR | Import/Export FASTA, duplike, multi‑paste, chunk view, meta |
| Workspace DNA/RNA input alanı | VAR | IUPAC doğrulama + otomatik normalize + hata pozisyonu |
| Son 20 rapor listesi | VAR | Aç / Pin / Compare / Export akışları |
| Compare Runs | VAR | A/B before-after + inline diff + side-by-side diff |
| Before/After + Inline renkli diff | VAR | Her run’da gösterim |
| Side-by-side diff | VAR | Opsiyonel tab olarak eklendi |
| Rapor Export JSON/XLSX/PDF | VAR | Tek ekranda download buttons |
| Bundle ZIP export | VAR | JSON+XLSX+PDF |
| Policy Studio | VAR | Base policy read-only + override edit + simulate |
| Diagnostics | VAR | /health Test Connection |
| Telemetry panel | VAR (baseline) | Varsayılan OFF (güvenli) |
| API Healthy / Policy Active / Telemetry Off rozetleri | VAR | Sidebar + topbar ipuçları |
