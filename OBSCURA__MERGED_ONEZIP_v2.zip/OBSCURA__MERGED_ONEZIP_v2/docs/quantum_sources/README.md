# Quantum / Kuantum kaynak notları

Bu klasör, projede daha önce geliştirilmiş kuantum/kuantum-bilinç temalı araştırma notlarını içerir.
Üretim kodu için zorunlu değildir; *dokümantasyon ve tasarım referansı* olarak tutulur.

## İçerik
- Akdemik makle ve Kuantum.txt
- İleri kuantum.txt
- kantum.txt
- KUANTUM KOD.txt
- Kuantum programlamada dolaşıklık (entanglement).txt
- Kuantum kary-topu.txt
