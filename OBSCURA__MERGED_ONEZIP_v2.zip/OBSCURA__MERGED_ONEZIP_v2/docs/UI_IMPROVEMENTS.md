# UI Improvements — Bulgu → Çözüm → Dosya/Komponent Haritası (v0.3.0)

## 1) Bulgu: UI davranışı “ölü” gibi (butonlar çalışmıyor / analiz çalışmıyor)
**Kök nedenler (projede gözlenen):**
- `ui/app.py` ile `README.md` arasında **parite bozulmuştu** (README “fallback + policy panel” derken UI dosyası fallback içermiyordu).
- API contract mismatch: `/run` endpoint’i sequence’i query param bekliyor; bazı UI akışları body üzerinden deniyordu.
- UI stabilitesi için gerekli görünür durum mesajları (API down → local fallback) açık ve tutarlı değildi.

**Çözüm:**
- UI yeniden ürünleştirildi: **API sağlıklıysa API**, değilse **local fallback** çalışır.
- `/run?sequence=` contract’ı düzeltildi.
- Her aksiyon için net progress + hata mesajı + log.

**Dosyalar:**
- `ui/app.py` (tam yeniden düzenlendi)
- `src/katopu_ui/*` (Streamlit bağımsız util’ler)

## 2) Bulgu: Kaymalar/taşmalar/wrap sorunları
**Çözüm:**
- Global CSS ile overflow yönetimi + nowrap/ellipsis + monospace alan kuralları.
- “Tek ana scroll” yaklaşımı; yatay taşmalar bastırıldı.

**Dosyalar:**
- `src/katopu_ui/ui_contract.py` (GLOBAL_CSS, test edilebilir sınıf isimleri)

## 3) Bulgu: Kaybolan kritik UI özellikleri (Parity)
- Multi‑Gene Editor yoktu
- Workspace’te net DNA/RNA input alanı yoktu (veya belirsizdi)
- Son 20 rapor listesi yoktu
- Compare runs yoktu / diff deneyimi zayıftı

**Çözüm:**
- Multi‑Gene Editor eklendi (import/export FASTA, duplike, multi‑paste, chunk view, meta)
- Workspace DNA/RNA input: IUPAC doğrulama + “pozisyon X’te geçersiz karakter”
- Son 20 rapor listesi (Aç/Pin/Compare/Export akışlarına bağlı)
- Compare Runs: A & B before/after + inline diff + side-by-side diff

**Dosyalar:**
- `ui/app.py` (sayfa router + sayfalar)
- `src/katopu_ui/seq.py`, `store.py`, `diffview.py`

## 4) Bulgu: Export ve rapor tekrarlanabilirliği
**Çözüm:**
- Tek tık export: JSON / XLSX / PDF / Bundle ZIP.
- “Raporlarda tam DNA sakla” ayarı: storage’da tam diziyi saklama opsiyonu.

**Dosyalar:**
- `ui/app.py` (export fonksiyonları)

## 5) Bulgu: UI test edilebilirliği
**Çözüm:**
- Streamlit’e bağımlı olmayan UI kontrat modülü + unit testler eklendi.
- Seq doğrulama ve gene store için unit testler eklendi.

**Dosyalar:**
- `tests/test_ui_seq.py`
- `tests/test_ui_store.py`
- `tests/test_ui_contract.py`
