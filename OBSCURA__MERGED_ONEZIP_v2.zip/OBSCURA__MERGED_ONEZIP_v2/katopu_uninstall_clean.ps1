# Katopu GenLab Ultra - Clean Uninstall (this project)
[CmdletBinding()]
param(
  [switch]$FullPrune  # WARNING: docker system prune -af + builder/volume prune
)

$ErrorActionPreference = 'Stop'

function Section([string]$t) { Write-Host "`n=== $t ===" -ForegroundColor Cyan }
function Ok([string]$t) { Write-Host "OK  : $t" -ForegroundColor Green }
function Warn([string]$t) { Write-Host "WARN: $t" -ForegroundColor Yellow }

function Ensure-Utf8 {
  try { chcp 65001 | Out-Null } catch {}
  try { $global:OutputEncoding = [Console]::OutputEncoding = [Text.UTF8Encoding]::new() } catch {}
}

function Is-Admin {
  return ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()
    ).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

if (-not (Is-Admin)) {
  Warn "Admin değilim -> UAC ile Admin PowerShell açıyorum..."
  # $MyInvocation.MyCommand.Path bazı host'larda boş gelebiliyor -> $PSCommandPath ile sağlamlaştır
  $self = $PSCommandPath
  if (-not $self) { $self = $MyInvocation.MyCommand.Path }
  if (-not $self) { $self = $MyInvocation.MyCommand.Definition }

  $argList = @('-NoProfile','-ExecutionPolicy','Bypass','-File', $self) | Where-Object { $_ -ne $null -and $_ -ne '' }
  if ($FullPrune) { $argList += '-FullPrune' }
  Start-Process -FilePath "powershell.exe" -Verb RunAs -ArgumentList $argList | Out-Null
  exit 0
}

Ensure-Utf8

$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$infra = Join-Path $root 'infra'
if (-not (Test-Path (Join-Path $infra 'docker-compose.yml'))) { throw "infra/docker-compose.yml yok: $infra" }

Section 'Compose down + volumes'
Push-Location $infra
try { docker compose down --remove-orphans --volumes | Out-Host } catch { Warn $_.Exception.Message }
Pop-Location

if ($FullPrune) {
  Section 'Docker tam temizlik (DİKKAT)'
  try { docker system prune -af | Out-Host } catch { Warn $_.Exception.Message }
  try { docker builder prune -af | Out-Host } catch { Warn $_.Exception.Message }
  try { docker volume prune -f | Out-Host } catch { Warn $_.Exception.Message }
}

Ok 'Bitti.'
