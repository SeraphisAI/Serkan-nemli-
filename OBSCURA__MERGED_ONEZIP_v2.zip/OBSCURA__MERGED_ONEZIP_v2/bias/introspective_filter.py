
class IntrospectiveBiasFilter:
    def __init__(self):
        self.bias_log = []

    def evaluate_decision(self, decision_data):
        print(f"[BIAS] Evaluating decision for bias indicators.")
        bias_detected = "source" in decision_data and decision_data["source"] == "pretrained"
        self.bias_log.append({"decision": decision_data, "biased": bias_detected})
        return {
            "decision": decision_data,
            "biased": bias_detected,
            "action": "adjust" if bias_detected else "retain"
        }
