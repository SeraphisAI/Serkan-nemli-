\
<# 21_run_ui_local.ps1 - Streamlit UI'yi lokal başlatır #>
$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
Set-Location $root

. "$root\.venv\Scripts\Activate.ps1"

# API ayrı terminalde çalışıyor varsayımı
if (-not $env:KATOPU_API_BASE) { $env:KATOPU_API_BASE = "http://localhost:8000" }
Write-Host "==> UI başlatılıyor (API: $env:KATOPU_API_BASE)"
streamlit run ui/app.py --server.port 8501 --server.address 0.0.0.0
