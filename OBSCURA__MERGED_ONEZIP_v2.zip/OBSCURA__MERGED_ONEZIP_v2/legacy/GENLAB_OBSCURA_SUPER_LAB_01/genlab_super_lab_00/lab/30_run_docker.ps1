\
<# 30_run_docker.ps1 - docker compose ile ayağa kaldırır #>
$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
Set-Location $root

if (-not (Get-Command docker -ErrorAction SilentlyContinue)) {
  Write-Host "Docker bulunamadı. Docker Desktop kurulu olmalı." -ForegroundColor Yellow
  exit 1
}

# env dosyası yoksa example'dan üret
if (-not (Test-Path "infra/.env")) {
  Copy-Item "infra/.env.example" "infra/.env"
  Write-Host "infra/.env oluşturuldu (infra/.env.example kopyası)."
}

Push-Location infra
docker compose up -d --build
Pop-Location

Write-Host "==> UI:  http://localhost:8501"
Write-Host "==> API: http://localhost:8000/health"
