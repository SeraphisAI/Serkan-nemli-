# Telemetry signal generation and sampling
