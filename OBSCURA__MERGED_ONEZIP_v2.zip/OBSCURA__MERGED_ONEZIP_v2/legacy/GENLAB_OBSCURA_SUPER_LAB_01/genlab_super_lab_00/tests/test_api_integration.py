from fastapi.testclient import TestClient

from api.app.main import app

client = TestClient(app)


def test_health_smoke():
    r = client.get("/health")
    assert r.status_code == 200
    j = r.json()
    assert j.get("ok") is True
    assert j.get("_meta", {}).get("contract")
    assert j.get("_meta", {}).get("engine")


def test_run_endpoint_smoke():
    # Minimal smoke: run should return a result schema even if policy blocks content.
    r = client.post("/run", params={"sequence": "ATGC"}, json={"intent": "ilk 2 baz sil", "mode": "strict"})
    assert r.status_code == 200
    j = r.json()
    assert j.get("schema") == "katopu.result.v1"
    assert j.get("_meta", {}).get("request_id")
