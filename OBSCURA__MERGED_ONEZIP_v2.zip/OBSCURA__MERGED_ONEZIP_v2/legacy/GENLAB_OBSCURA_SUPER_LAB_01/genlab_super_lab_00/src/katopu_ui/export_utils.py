from __future__ import annotations

import io
import json
import zipfile
from typing import Any, Dict, List

from openpyxl import Workbook
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas

from katopu_ui.history import sanitize_filename


EXCEL_CELL_CHUNK = 16000  # safe chunk < 32767 (Excel per-cell limit)


def _write_chunked_sheet(ws, header: str, text: str) -> None:
    ws.append([header])
    s = text or ""
    if len(s) <= EXCEL_CELL_CHUNK:
        ws.append([s])
        return
    for i in range(0, len(s), EXCEL_CELL_CHUNK):
        ws.append([s[i : i + EXCEL_CELL_CHUNK]])


def make_xlsx_bytes(run: Dict[str, Any]) -> bytes:
    wb = Workbook()
    ws = wb.active
    ws.title = "Run"
    ws.append(["key", "value"])

    meta_keys = [
        "run_id",
        "ts_iso",
        "gene_name",
        "intent",
        "mode",
        "status",
        "latency_ms",
        "policy_allowed",
        "policy_reason",
        "pinned",
        "deleted",
        "archived",
    ]
    for k in meta_keys:
        ws.append([k, str(run.get(k, ""))])

    ws_before = wb.create_sheet("Before")
    _write_chunked_sheet(ws_before, "before", run.get("before", "") or "")

    ws_after = wb.create_sheet("After")
    _write_chunked_sheet(ws_after, "after", run.get("after", "") or "")

    ws_spec = wb.create_sheet("Spec")
    spec_json = json.dumps(run.get("spec") or {}, ensure_ascii=False, indent=2)
    _write_chunked_sheet(ws_spec, "spec_json", spec_json)

    bio = io.BytesIO()
    wb.save(bio)
    return bio.getvalue()


def make_pdf_bytes(run: Dict[str, Any]) -> bytes:
    bio = io.BytesIO()
    c = canvas.Canvas(bio, pagesize=A4)
    w, h = A4
    y = h - 50

    c.setFont("Helvetica-Bold", 14)
    c.drawString(50, y, "Katopu GenLab — Run Report")
    y -= 24
    c.setFont("Helvetica", 10)

    for k in [
        "run_id",
        "ts_iso",
        "gene_name",
        "intent",
        "mode",
        "status",
        "latency_ms",
        "policy_allowed",
        "policy_reason",
        "pinned",
        "deleted",
        "archived",
    ]:
        v = str(run.get(k, ""))
        c.drawString(50, y, f"{k}: {v}"[:120])
        y -= 14
        if y < 80:
            c.showPage()
            y = h - 50
            c.setFont("Helvetica", 10)

    def preview(s: str) -> str:
        s = s or ""
        if len(s) <= 600:
            return s
        return s[:300] + "\n...\n" + s[-300:]

    y -= 6
    for title, seq in [
        ("Before (preview)", run.get("before", "") or ""),
        ("After (preview)", run.get("after", "") or ""),
    ]:
        if y < 120:
            c.showPage()
            y = h - 50
        c.setFont("Helvetica-Bold", 11)
        c.drawString(50, y, title)
        y -= 14
        c.setFont("Courier", 8)
        for ln in preview(seq).splitlines()[:120]:
            c.drawString(50, y, ln[:120])
            y -= 10
            if y < 80:
                c.showPage()
                y = h - 50
                c.setFont("Courier", 8)

    c.save()
    return bio.getvalue()


def make_bundle_zip(run: Dict[str, Any]) -> bytes:
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", compression=zipfile.ZIP_DEFLATED) as z:
        z.writestr("run.json", json.dumps(run, ensure_ascii=False, indent=2))
        z.writestr("run.xlsx", make_xlsx_bytes(run))
        z.writestr("run.pdf", make_pdf_bytes(run))
    return buf.getvalue()


def make_bundle_zip_many(runs: List[Dict[str, Any]]) -> bytes:
    """
    Combined Bundle ZIP:
      run_id/run.json
      run_id/run.xlsx
      run_id/run.pdf
    """
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", compression=zipfile.ZIP_DEFLATED) as z:
        for r in runs:
            rid = sanitize_filename(str(r.get("run_id", "run")))
            base = f"{rid}/"
            z.writestr(base + "run.json", json.dumps(r, ensure_ascii=False, indent=2))
            z.writestr(base + "run.xlsx", make_xlsx_bytes(r))
            z.writestr(base + "run.pdf", make_pdf_bytes(r))
    return buf.getvalue()


def make_jsonl_bytes(runs: List[Dict[str, Any]]) -> bytes:
    lines = [json.dumps(r, ensure_ascii=False) for r in runs]
    return ("\n".join(lines) + ("\n" if lines else "")).encode("utf-8")
