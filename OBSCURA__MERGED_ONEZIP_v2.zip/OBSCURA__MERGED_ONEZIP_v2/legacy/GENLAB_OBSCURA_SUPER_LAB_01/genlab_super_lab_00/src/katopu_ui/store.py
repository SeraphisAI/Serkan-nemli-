from __future__ import annotations

import json
import os
import time
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional

def _atomic_write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(text, encoding="utf-8")
    os.replace(tmp, path)

def _now_iso() -> str:
    # UTC ISO seconds
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())

@dataclass
class Gene:
    gene_id: str
    name: str
    sequence: str
    created_at: str
    updated_at: str
    notes: str = ""
    tags: List[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "gene_id": self.gene_id,
            "name": self.name,
            "sequence": self.sequence,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "notes": self.notes,
            "tags": self.tags or [],
        }

    @staticmethod
    def from_dict(d: Dict[str, Any]) -> "Gene":
        return Gene(
            gene_id=str(d.get("gene_id") or d.get("id") or uuid.uuid4().hex),
            name=str(d.get("name") or "Untitled"),
            sequence=str(d.get("sequence") or ""),
            created_at=str(d.get("created_at") or _now_iso()),
            updated_at=str(d.get("updated_at") or _now_iso()),
            notes=str(d.get("notes") or ""),
            tags=list(d.get("tags") or []),
        )

class GeneStore:
    """
    File-backed store for genes. JSON format:
    { "schema_version": 1, "genes": [ ... ] }
    """
    def __init__(self, path: Path):
        self.path = path

    def load(self) -> List[Gene]:
        if not self.path.exists():
            return []
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
            genes = data.get("genes") if isinstance(data, dict) else data
            out = [Gene.from_dict(x) for x in (genes or [])]
            return out
        except Exception:
            # Fail closed -> empty (UI can show recovery guidance)
            return []

    def save(self, genes: Iterable[Gene]) -> None:
        payload = {"schema_version": 1, "genes": [g.to_dict() for g in genes]}
        _atomic_write_text(self.path, json.dumps(payload, ensure_ascii=False, indent=2))

    def upsert(self, genes: List[Gene], g: Gene) -> List[Gene]:
        found = False
        out: List[Gene] = []
        for it in genes:
            if it.gene_id == g.gene_id:
                found = True
                out.append(g)
            else:
                out.append(it)
        if not found:
            out.append(g)
        return out

    def new_gene(self, name: str, sequence: str) -> Gene:
        now = _now_iso()
        return Gene(gene_id=uuid.uuid4().hex, name=name or "New Gene", sequence=sequence or "", created_at=now, updated_at=now, notes="", tags=[])

def _append_jsonl(path: Path, obj: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    line = json.dumps(obj, ensure_ascii=False) + "\n"
    with path.open("a", encoding="utf-8") as f:
        f.write(line)

def load_jsonl(path: Path, *, limit: Optional[int] = None) -> List[Dict[str, Any]]:
    if not path.exists():
        return []
    rows = []
    with path.open("r", encoding="utf-8") as f:
        for ln in f:
            ln = ln.strip()
            if not ln:
                continue
            try:
                rows.append(json.loads(ln))
            except Exception:
                continue
    # newest first
    rows.sort(key=lambda x: x.get("ts_iso",""), reverse=True)
    if limit is not None:
        rows = rows[: int(limit)]
    return rows

def append_run(path: Path, record: Dict[str, Any]) -> None:
    # Ensure minimal required fields
    record = dict(record)
    record.setdefault("run_id", uuid.uuid4().hex)
    record.setdefault("ts_iso", _now_iso())
    _append_jsonl(path, record)
