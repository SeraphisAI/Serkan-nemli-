from __future__ import annotations

import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List

from katopu_ui.store import load_jsonl


META_KEYS = ("pinned", "deleted", "archived")


def now_iso_utc() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def parse_ts_iso(ts_iso: str) -> float:
    """
    ISO8601 -> epoch seconds.
    Supports 'Z' suffix. If timezone missing, assumes UTC.
    """
    if not ts_iso:
        return 0.0
    s = str(ts_iso).strip()
    try:
        if s.endswith("Z"):
            s = s[:-1] + "+00:00"
        dt = datetime.fromisoformat(s)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt.timestamp()
    except Exception:
        # fallback: YYYYMMDDHHMMSS
        m = re.match(r"^(\d{4})(\d{2})(\d{2})(\d{2})(\d{2})(\d{2})$", s)
        if m:
            dt = datetime(
                int(m.group(1)),
                int(m.group(2)),
                int(m.group(3)),
                int(m.group(4)),
                int(m.group(5)),
                int(m.group(6)),
                tzinfo=timezone.utc,
            )
            return dt.timestamp()
        return 0.0


def load_runs_with_meta(path: Path, limit: int = 5000) -> List[Dict[str, Any]]:
    """
    Load jsonl runs and merge latest meta per run_id (last meta wins).
    Base runs keep their own fields; meta only overrides known flags and a few optional fields.
    """
    rows = load_jsonl(path, limit=limit) or []

    base_by_id: Dict[str, Dict[str, Any]] = {}
    meta_by_id: Dict[str, Dict[str, Any]] = {}

    # order matters: file is append-only; last meta wins
    for r in rows:
        if not isinstance(r, dict):
            continue
        rid = r.get("run_id")
        if not rid:
            continue
        if r.get("_type") == "meta":
            meta_by_id[rid] = r
        else:
            base_by_id[rid] = r

    merged: List[Dict[str, Any]] = []
    for rid, base in base_by_id.items():
        m = meta_by_id.get(rid) or {}
        out = dict(base)
        for k in META_KEYS:
            if k in m:
                out[k] = m.get(k)
        for k in ("tags", "label", "note", "report_name"):
            if k in m:
                out[k] = m.get(k)
        merged.append(out)

    return merged


def sort_runs_pinned_newest(runs: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """
    Pinned first; within pinned/unpinned newest-first.
    """
    return sorted(
        runs,
        key=lambda r: (
            0 if bool(r.get("pinned")) else 1,
            -parse_ts_iso(str(r.get("ts_iso", ""))),
        ),
    )


def filter_runs(
    runs: List[Dict[str, Any]],
    *,
    q: str = "",
    status: str = "all",
    pinned_only: bool = False,
    include_deleted: bool = False,
    include_archived: bool = True,
) -> List[Dict[str, Any]]:
    ql = (q or "").strip().lower()

    def ok(r: Dict[str, Any]) -> bool:
        if not include_archived and bool(r.get("archived")):
            return False
        if not include_deleted and bool(r.get("deleted")):
            return False
        if pinned_only and not bool(r.get("pinned")):
            return False
        if status != "all" and (r.get("status") != status):
            return False
        if ql:
            hay = f"{r.get('gene_name','')} {r.get('intent','')} {r.get('run_id','')}".lower()
            if ql not in hay:
                return False
        return True

    return [r for r in runs if ok(r)]


def sanitize_filename(name: str, max_len: int = 80) -> str:
    s = (name or "").strip()
    s = re.sub(r"[^\w\-. ]+", "_", s, flags=re.UNICODE)
    s = re.sub(r"\s+", "_", s)
    if not s:
        s = "item"
    return s[:max_len]
