#!/usr/bin/env python3
"""Katopu Doctor (cross-platform preflight)

Purpose: catch installation/runtime issues *before* a user hits them.
This helps achieve "kurulumda hiç hata istemiyoruz" goal.

Checks:
- Python version
- Project structure critical files
- Docker + docker compose availability
- Port collisions (best effort)
- Optional HTTP reachability for UI/API if already running
"""

from __future__ import annotations
import sys, socket, subprocess, pathlib
from urllib.request import urlopen
from urllib.error import URLError

ROOT = pathlib.Path(__file__).resolve().parents[1]
INFRA = ROOT / "infra"
COMPOSE = INFRA / "docker-compose.yml"
PORTS = [8000, 8501]

def head(msg: str) -> None:
    print(f"\n=== {msg} ===")

def ok(msg: str) -> None:
    print(f"[OK] {msg}")

def warn(msg: str) -> None:
    print(f"[WARN] {msg}")

def fail(msg: str) -> None:
    print(f"[FAIL] {msg}")

def run(cmd: list[str]) -> tuple[bool, str]:
    try:
        out = subprocess.check_output(cmd, stderr=subprocess.STDOUT, text=True).strip()
        return True, out
    except Exception as e:
        return False, str(e)

def port_in_use(port: int) -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(0.3)
        return s.connect_ex(("127.0.0.1", port)) == 0

def http_ok(url: str, timeout_s: float = 1.5) -> bool:
    try:
        with urlopen(url, timeout=timeout_s) as r:
            return 200 <= r.status < 300
    except URLError:
        return False
    except Exception:
        return False

def main() -> int:
    head("Environment")
    if sys.version_info < (3, 11):
        fail("Python >= 3.11 required")
        return 1
    ok(f"Python {sys.version.split()[0]}")

    head("Project structure")
    if not COMPOSE.exists():
        fail("infra/docker-compose.yml missing")
        return 1
    ok("infra/docker-compose.yml present")
    for p in ["README.md", "pyproject.toml", "requirements-dev.txt", "ui/app.py", "api/main.py"]:
        if (ROOT / p).exists():
            ok(f"{p} present")
        else:
            warn(f"{p} missing (may still be OK depending on stack)")

    head("Docker")
    d_ok, d_out = run(["docker", "--version"])
    c_ok, c_out = run(["docker", "compose", "version"])
    if not d_ok:
        fail("Docker not available")
        print("      ", d_out)
        return 1
    ok(d_out)
    if not c_ok:
        fail("Docker Compose not available (docker compose)")
        print("      ", c_out)
        return 1
    ok(c_out)

    head("Port checks (localhost)")
    collisions = [p for p in PORTS if port_in_use(p)]
    for p in PORTS:
        if p in collisions:
            warn(f"Port {p} appears IN USE (OK if Katopu already running)")
        else:
            ok(f"Port {p} free/closed")

    head("Optional health checks (if already running)")
    api = "http://127.0.0.1:8000/health"
    ui = "http://127.0.0.1:8501"
    if http_ok(api):
        ok(f"API healthy: {api}")
    else:
        warn(f"API not reachable yet: {api}")
    if http_ok(ui):
        ok(f"UI reachable: {ui}")
    else:
        warn(f"UI not reachable yet: {ui}")

    head("Result")
    ok("Doctor completed. Fix WARNs before delivery.")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
