"""Katopu GenLab — Ultra (Product UI)

Goals:
- Pro layout: sticky top bar + fixed nav + stabilized cards (no overflow/wrap regressions).
- Parity restored: Multi‑Gene Editor, DNA/RNA Sequence input, Last 20 Reports, Compare Runs (inline + SBS diff).
- Reliability: API down -> local fallback with clear messaging (no "dead buttons").
- Export: JSON/XLSX/PDF + Bundle ZIP.

Non-UI utilities live in src/katopu_ui/* and are unit-testable without Streamlit.
"""

from __future__ import annotations

import io
import json
import os
import time
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import requests
import streamlit as st
import streamlit.components.v1 as components
from openpyxl import Workbook
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas

from katopu_core.omega_engine import apply_editspec, intent_to_editspec, run_intent
from katopu_policy.evaluator import PolicyEvaluator
from katopu_shared.ids import CONTRACT_VERSION

from katopu_ui.diffview import diff_stats, inline_diff_html, side_by_side_diff_html
from katopu_ui.seq import format_chunked, parse_fasta, to_fasta, validate_iupac
from katopu_ui.store import Gene, GeneStore, append_run, load_jsonl
from katopu_ui.ui_contract import APP_VERSION, GLOBAL_CSS, topbar_html

# -----------------------------
# Paths / Defaults
# -----------------------------
DEFAULT_API_BASE = os.environ.get("KATOPU_API_BASE", "http://localhost:8000").rstrip("/")
DEFAULT_TIMEOUT_S = float(os.environ.get("KATOPU_HTTP_TIMEOUT_S", "8"))
RUNS_PATH = Path(os.environ.get("KATOPU_UI_RUNS_PATH", "/data/ui_runs.jsonl"))
GENES_PATH = Path(os.environ.get("KATOPU_UI_GENES_PATH", "/data/ui_genes.json"))
POLICY_BASE_PATH = Path(os.environ.get("KATOPU_POLICY_PATH", "/policies/default.policy.json"))
POLICY_OVERRIDE_PATH = Path(os.environ.get("KATOPU_POLICY_OVERRIDE_PATH", "/data/policy_override.json"))

# -----------------------------
# HTTP helpers (API mode)
# -----------------------------
def _make_headers(api_key: str) -> Dict[str, str]:
    h = {"Content-Type": "application/json"}
    if api_key:
        h["X-API-Key"] = api_key
        h["Authorization"] = f"Bearer {api_key}"
    return h

def api_get(api_base: str, path: str, *, timeout_s: float, api_key: str) -> Tuple[Optional[Dict[str, Any]], Optional[str]]:
    try:
        r = requests.get(api_base + path, headers=_make_headers(api_key), timeout=timeout_s)
        if r.status_code >= 400:
            return None, f"{r.status_code}: {r.text[:300]}"
        return r.json(), None
    except Exception as e:
        return None, f"{type(e).__name__}: {e}"

def api_post(api_base: str, path: str, *, timeout_s: float, api_key: str, body: Dict[str, Any]) -> Tuple[Optional[Dict[str, Any]], Optional[str]]:
    try:
        r = requests.post(api_base + path, headers=_make_headers(api_key), timeout=timeout_s, json=body)
        if r.status_code >= 400:
            return None, f"{r.status_code}: {r.text[:300]}"
        return r.json(), None
    except Exception as e:
        return None, f"{type(e).__name__}: {e}"

# -----------------------------
# Query-param based shortcuts (best-effort)
# -----------------------------
def _get_query_params() -> Dict[str, Any]:
    try:
        return dict(st.query_params)
    except Exception:
        try:
            return st.experimental_get_query_params()  # type: ignore
        except Exception:
            return {}

def _clear_query_params() -> None:
    try:
        st.query_params.clear()
    except Exception:
        try:
            st.experimental_set_query_params()  # type: ignore
        except Exception:
            pass

def inject_shortcuts_js() -> None:
    """
    Best-effort keyboard shortcuts for Streamlit using query param triggers.
    - Ctrl/Cmd+K: open command palette
    - Ctrl/Cmd+Enter: Run
    - Ctrl/Cmd+S: Save Run
    - Ctrl/Cmd+P: Export bundle
    """
    js = r"""
    <script>
    (function(){
      const send = (action) => {
        try{
          const url = new URL(window.parent.location.href);
          url.searchParams.set('kat_action', action);
          window.parent.history.replaceState({}, '', url.toString());
          window.parent.dispatchEvent(new PopStateEvent('popstate'));
        }catch(e){}
      };
      window.addEventListener('keydown', function(e){
        const meta = e.metaKey || e.ctrlKey;
        if(!meta) return;
        const k = (e.key || '').toLowerCase();
        if(k === 'k'){ e.preventDefault(); send('palette'); }
        if(k === 'enter'){ e.preventDefault(); send('run'); }
        if(k === 's'){ e.preventDefault(); send('save'); }
        if(k === 'p'){ e.preventDefault(); send('export'); }
      }, true);
    })();
    </script>
    """
    components.html(js, height=0)

def handle_shortcut_actions() -> Dict[str, bool]:
    qp = _get_query_params()
    action = None
    v = qp.get("kat_action") if isinstance(qp, dict) else None
    if isinstance(v, list):
        action = v[0] if v else None
    else:
        action = v
    if not action:
        return {"palette": False, "run": False, "save": False, "export": False}
    _clear_query_params()
    return {
        "palette": action == "palette",
        "run": action == "run",
        "save": action == "save",
        "export": action == "export",
    }

# -----------------------------
# UI state
# -----------------------------
def ss_init() -> None:
    st.session_state.setdefault("page", "Workspace (Lab)")
    st.session_state.setdefault("view_mode", "Run Mode")  # Editor Mode | Run Mode | Review Mode
    st.session_state.setdefault("api_base", DEFAULT_API_BASE)
    st.session_state.setdefault("api_key", "")
    st.session_state.setdefault("timeout_s", DEFAULT_TIMEOUT_S)
    st.session_state.setdefault("engine_mode", "Auto")  # Auto | API | Local
    st.session_state.setdefault("enable_local_fallback", True)
    st.session_state.setdefault("save_history", True)
    st.session_state.setdefault("store_full_sequence", True)
    st.session_state.setdefault("selected_gene_id", "")
    st.session_state.setdefault("selected_run_id", "")
    st.session_state.setdefault("current_sequence", "")
    st.session_state.setdefault("current_intent", "")
    st.session_state.setdefault("current_report_name", "")
    st.session_state.setdefault("current_spec", None)
    st.session_state.setdefault("current_result", None)
    st.session_state.setdefault("pipeline_step", "Idle")
    st.session_state.setdefault("pipeline_log", [])
    st.session_state.setdefault("show_palette", False)
    st.session_state.setdefault("global_search", "")
    st.session_state.setdefault("trigger_run", False)
    st.session_state.setdefault("trigger_save", False)
    st.session_state.setdefault("trigger_export", False)
    st.session_state.setdefault("compare_a", "")
    st.session_state.setdefault("compare_b", "")


# -----------------------------
# Navigation helper
# -----------------------------
def nav_to(page: str) -> None:
    """Request navigation to another page.

    Streamlit widget keys own their session_state entries. We keep the canonical
    navigation state in st.session_state['page'] and stage programmatic nav via
    st.session_state['_nav_to'] to apply it at the top of main() before the
    sidebar is rendered.
    """
    st.session_state["_nav_to"] = page
    st.rerun()

def log(msg: str) -> None:
    st.session_state["pipeline_log"] = (st.session_state.get("pipeline_log") or []) + [msg]

def set_step(step: str) -> None:
    st.session_state["pipeline_step"] = step

# -----------------------------
# Policy (local)
# -----------------------------
def load_policy_evaluator() -> PolicyEvaluator:
    return PolicyEvaluator(str(POLICY_BASE_PATH), override_path=str(POLICY_OVERRIDE_PATH))

# -----------------------------
# Gene store helpers
# -----------------------------
def ensure_default_gene(genes: List[Gene]) -> List[Gene]:
    if genes:
        return genes
    gs = GeneStore(GENES_PATH)
    g = gs.new_gene("Gene-1", "ATGACCTTGGCTAACCTGTTACGATGGCCTTAA")
    gs.save([g])
    return [g]

def get_active_gene(genes: List[Gene]) -> Optional[Gene]:
    gid = st.session_state.get("selected_gene_id") or ""
    if not genes:
        return None
    if gid:
        for g in genes:
            if g.gene_id == gid:
                return g
    st.session_state["selected_gene_id"] = genes[0].gene_id
    return genes[0]

# -----------------------------
# Export
# -----------------------------
def make_xlsx_bytes(run: Dict[str, Any]) -> bytes:
    wb = Workbook()
    ws = wb.active
    ws.title = "Run"
    meta = [
        ("run_id", run.get("run_id", "")),
        ("ts_iso", run.get("ts_iso", "")),
        ("gene_name", run.get("gene_name", "")),
        ("intent", run.get("intent", "")),
        ("mode", run.get("mode", "")),
        ("status", run.get("status", "")),
        ("latency_ms", run.get("latency_ms", "")),
        ("policy_allowed", run.get("policy_allowed", "")),
        ("policy_reason", run.get("policy_reason", "")),
    ]
    ws.append(["key", "value"])
    for k, v in meta:
        ws.append([k, v])
    ws2 = wb.create_sheet("Before")
    ws2.append(["before"])
    ws2.append([run.get("before", "")])
    ws3 = wb.create_sheet("After")
    ws3.append(["after"])
    ws3.append([run.get("after", "")])
    ws4 = wb.create_sheet("Spec")
    ws4.append(["spec_json"])
    ws4.append([json.dumps(run.get("spec") or {}, ensure_ascii=False)])
    bio = io.BytesIO()
    wb.save(bio)
    return bio.getvalue()

def make_pdf_bytes(run: Dict[str, Any]) -> bytes:
    bio = io.BytesIO()
    c = canvas.Canvas(bio, pagesize=A4)
    w, h = A4
    y = h - 50
    c.setFont("Helvetica-Bold", 14)
    c.drawString(50, y, "Katopu GenLab — Run Report")
    y -= 24
    c.setFont("Helvetica", 10)
    for k in ["run_id", "ts_iso", "gene_name", "intent", "mode", "status", "latency_ms", "policy_allowed", "policy_reason"]:
        v = str(run.get(k, ""))
        c.drawString(50, y, f"{k}: {v}"[:120])
        y -= 14
        if y < 80:
            c.showPage()
            y = h - 50
            c.setFont("Helvetica", 10)

    def preview(s: str) -> str:
        if len(s) <= 600:
            return s
        return s[:300] + "\n...\n" + s[-300:]

    y -= 6
    for title, seq in [("Before (preview)", run.get("before", "") or ""), ("After (preview)", run.get("after", "") or "")]:
        if y < 120:
            c.showPage()
            y = h - 50
        c.setFont("Helvetica-Bold", 11)
        c.drawString(50, y, title)
        y -= 14
        c.setFont("Courier", 8)
        for ln in preview(seq).splitlines()[:120]:
            c.drawString(50, y, ln[:120])
            y -= 10
            if y < 80:
                c.showPage()
                y = h - 50
                c.setFont("Courier", 8)

    c.save()
    return bio.getvalue()

def make_bundle_zip(run: Dict[str, Any]) -> bytes:
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", compression=zipfile.ZIP_DEFLATED) as z:
        z.writestr("run.json", json.dumps(run, ensure_ascii=False, indent=2))
        z.writestr("run.xlsx", make_xlsx_bytes(run))
        z.writestr("run.pdf", make_pdf_bytes(run))
    return buf.getvalue()

# -----------------------------
# Rendering helpers
# -----------------------------
def render_stepper(active: str) -> None:
    steps = ["Parse", "Spec", "Apply", "Validate", "Report"]
    out = []
    for s in steps:
        cls = "k-badge good" if s == active else "k-badge"
        out.append(f"<span class='{cls}'>{s}</span>")
    st.markdown(
        "<div class='k-card-tight' data-testid='katopu-stepper'><b>Pipeline</b>"
        "<div style='margin-top:6px; display:flex; gap:8px; flex-wrap:wrap;'>"
        + "".join(out)
        + "</div></div>",
        unsafe_allow_html=True,
    )

def render_inspector_html(active_gene: Optional[Gene], active_run: Optional[Dict[str, Any]]) -> str:
    gene_name = active_gene.name if active_gene else "—"
    gene_seq = active_gene.sequence if active_gene else ""
    val = validate_iupac(gene_seq, strict=False) if active_gene else None
    gene_len = val.length if val else 0
    gene_gc = f"{val.gc_percent:.1f}%" if val else "—"
    gene_warn = ", ".join(val.warnings) if (val and val.warnings) else "—"

    run_id = (active_run or {}).get("run_id", "—")
    ts = (active_run or {}).get("ts_iso", "—")
    latency = (active_run or {}).get("latency_ms", "—")
    status = (active_run or {}).get("status", "—")
    pol = (active_run or {}).get("policy_allowed")
    pol_txt = "ALLOW" if pol is True else ("DENY" if pol is False else "—")
    pol_reason = (active_run or {}).get("policy_reason", "—")

    return f"""
<div class="k-card" data-testid="katopu-inspector">
  <div class="k-title">Inspector</div>
  <div class="k-muted">Seçili gen + seçili rapor meta</div>
  <hr style="border:none; border-top:1px solid var(--k-border); margin:10px 0;" />
  <div class="k-title">Gen</div>
  <div class="k-nowrap" title="{gene_name}"><b>ACTIVE:</b> {gene_name}</div>
  <div class="k-muted k-nowrap" title="{gene_warn}">Uyarılar: {gene_warn}</div>
  <div class="k-muted">Len: <b>{gene_len}</b> | GC%: <b>{gene_gc}</b></div>
  <hr style="border:none; border-top:1px solid var(--k-border); margin:10px 0;" />
  <div class="k-title">Run / Rapor</div>
  <div class="k-muted k-nowrap" title="{run_id}">run_id: {run_id}</div>
  <div class="k-muted">ts: {ts}</div>
  <div class="k-muted">status: <b>{status}</b> | latency_ms: <b>{latency}</b></div>
  <div class="k-muted">policy: <b>{pol_txt}</b></div>
  <div class="k-muted k-nowrap" title="{pol_reason}">reason: {pol_reason}</div>
</div>
"""

def render_last20(runs: List[Dict[str, Any]]) -> None:
    st.markdown("<div class='k-card'><div class='k-title'>Son 20 Rapor</div><div class='k-muted'>Aç / Pin / Compare / Export</div>", unsafe_allow_html=True)
    if not runs:
        st.info("Henüz rapor yok. İlk run'ı çalıştır.")
        st.markdown("</div>", unsafe_allow_html=True)
        return

    for i, r in enumerate([x for x in runs if x.get("_type") != "meta"][:20]):
        rid = r.get("run_id", "")
        ts = r.get("ts_iso", "")
        gene = r.get("gene_name", "")
        intent = r.get("intent", "")
        status = r.get("status", "")
        latency = r.get("latency_ms", "")
        pinned = "⭐" if r.get("pinned") else ""

        cols = st.columns([2.0, 1.2, 3.0, 1.0, 1.0, 2.4], gap="small")
        with cols[0]:
            if st.button(f"Aç {pinned}", key=f"open_{rid}_{i}", use_container_width=True):
                st.session_state["selected_run_id"] = rid
                nav_to("Workspace (Lab)")
        cols[1].markdown(f"<div class='k-muted k-nowrap' title='{ts}'>{ts}</div>", unsafe_allow_html=True)
        cols[2].markdown(f"<div class='k-nowrap' title='{gene}'><b>{gene}</b></div><div class='k-muted k-nowrap' title='{intent}'>{intent}</div>", unsafe_allow_html=True)
        cols[3].markdown(f"<div class='k-muted k-nowrap'>{status}</div>", unsafe_allow_html=True)
        cols[4].markdown(f"<div class='k-muted k-nowrap'>{latency}</div>", unsafe_allow_html=True)
        with cols[5]:
            b1, b2, b3 = st.columns(3, gap="small")
            if b1.button("Pin", key=f"pin_{rid}_{i}", use_container_width=True):
                r["pinned"] = not bool(r.get("pinned"))
                append_run(RUNS_PATH, {"run_id": rid, "ts_iso": r.get("ts_iso"), "pinned": r.get("pinned"), "_type": "meta"})
                st.success("Pin güncellendi.")
            if b2.button("Cmp", key=f"cmp_{rid}_{i}", use_container_width=True):
                st.session_state["compare_a"] = rid
                nav_to("Compare")
            if b3.button("ZIP", key=f"zip_{rid}_{i}", use_container_width=True):
                st.session_state["selected_run_id"] = rid
                nav_to("Reports (History)")
    st.markdown("</div>", unsafe_allow_html=True)

def render_quickbar(genes: List[Gene]) -> None:
    cols = st.columns([3.2, 1.6, 1.6], gap="small")
    with cols[0]:
        st.text_input("Ara (gen/rapor)", key="global_search", placeholder="Gene adı / run_id / intent…")
    with cols[1]:
        if st.button("Komut Paleti (⌘/Ctrl+K)", use_container_width=True):
            st.session_state["show_palette"] = not bool(st.session_state.get("show_palette"))
    with cols[2]:
        st.markdown("<div class='k-card-tight k-muted'>Kısayollar: ⌘/Ctrl+Enter Run • ⌘/Ctrl+S Save • ⌘/Ctrl+P Export</div>", unsafe_allow_html=True)

    # Apply search (simple router)
    q = (st.session_state.get("global_search") or "").strip()
    if q:
        ql = q.lower()
        for g in genes:
            if ql in g.name.lower():
                st.session_state["selected_gene_id"] = g.gene_id
                st.session_state["_nav_to"] = "Workspace (Lab)"
                st.rerun()
        for r in load_jsonl(RUNS_PATH, limit=500):
            if r.get("_type") == "meta":
                continue
            if ql in (r.get("run_id", "").lower() + " " + r.get("intent", "").lower() + " " + r.get("gene_name", "").lower()):
                st.session_state["selected_run_id"] = r.get("run_id", "")
                st.session_state["_nav_to"] = "Workspace (Lab)"
                st.rerun()

    # Command palette
    if st.session_state.get("show_palette"):
        with st.expander("Komut Paleti", expanded=True):
            commands = [
                ("Workspace (Lab)", "Sayfaya git: Workspace"),
                ("Multi-Gene Editor", "Sayfaya git: Multi‑Gene Editor"),
                ("Reports (History)", "Sayfaya git: Reports"),
                ("Compare", "Sayfaya git: Compare"),
                ("Policy Studio", "Sayfaya git: Policy Studio"),
                ("Diagnostics", "Sayfaya git: Diagnostics"),
                ("Settings", "Sayfaya git: Settings"),
                ("ACTION:Run", "Çalıştır (Run)"),
                ("ACTION:Save", "Save Run"),
                ("ACTION:Export", "Export (Bundle)"),
                ("ACTION:Clear", "Workspace Clear"),
            ]
            labels = [c[1] for c in commands]
            idx = st.selectbox("Komut", options=list(range(len(commands))), format_func=lambda i: labels[i])
            if st.button("Uygula", type="primary"):
                cmd = commands[int(idx)][0]
                if cmd.startswith("ACTION:"):
                    act = cmd.split(":", 1)[1].lower()
                    if act == "run":
                        st.session_state["trigger_run"] = True
                    if act == "save":
                        st.session_state["trigger_save"] = True
                    if act == "export":
                        st.session_state["trigger_export"] = True
                    if act == "clear":
                        st.session_state["pipeline_log"] = []
                        st.session_state["current_spec"] = None
                        st.session_state["current_result"] = None
                        st.session_state["pipeline_step"] = "Idle"
                    st.session_state["show_palette"] = False
                    st.rerun()
                else:
                    st.session_state["_nav_to"] = cmd
                    st.session_state["show_palette"] = False
                    st.rerun()

# -----------------------------
# Pages
# -----------------------------
def page_workspace(genes: List[Gene], policy: PolicyEvaluator) -> None:
    active_gene = get_active_gene(genes)
    if active_gene and not st.session_state.get("current_sequence"):
        st.session_state["current_sequence"] = active_gene.sequence

    api_base = st.session_state["api_base"]
    api_key = st.session_state["api_key"]
    timeout_s = float(st.session_state["timeout_s"])
    engine_mode = st.session_state["engine_mode"]
    enable_local_fallback = bool(st.session_state["enable_local_fallback"])
    view_mode = st.session_state["view_mode"]

    st.markdown("<div class='k-card'><div class='k-title'>Workspace</div><div class='k-muted'>Girdi → Çalıştır → Sonuç → Kaydet → Export</div></div>", unsafe_allow_html=True)

    # Editor / inputs (P0 DNA/RNA input)
    if view_mode in ("Editor Mode", "Run Mode"):
        st.markdown("<div class='k-card'>", unsafe_allow_html=True)
        c1, c2, c3 = st.columns([2.2, 2.2, 1.6], gap="medium")
        with c1:
            gene_names = [f"{g.name} ({g.gene_id[:6]})" for g in genes] if genes else ["—"]
            gene_ids = [g.gene_id for g in genes]
            idx = gene_ids.index(active_gene.gene_id) if (active_gene and active_gene.gene_id in gene_ids) else 0
            sel = st.selectbox("Aktif gen", options=list(range(len(gene_names))), index=idx, format_func=lambda i: gene_names[i])
            if genes:
                st.session_state["selected_gene_id"] = gene_ids[int(sel)]
                active_gene = get_active_gene(genes)
            seq_kind = st.selectbox("Sequence türü", ["dna", "rna"], index=0)
            strict = st.toggle("Strict mode", value=True, help="Strict: sadece A,C,G,T (DNA) veya A,C,G,U (RNA).")
            st.session_state["mode_strict"] = bool(strict)
            st.session_state["seq_kind"] = seq_kind

        with c2:
            st.text_input("Intent (TR serbest metin)", key="current_intent", placeholder="örn: ilk 5 baz sil")
            st.text_input("Rapor adı (opsiyonel)", key="current_report_name", placeholder="örn: Deneme-1")
            st.radio("View Mode", ["Editor Mode", "Run Mode", "Review Mode"], horizontal=True, key="view_mode")

        with c3:
            st.selectbox("Engine", ["Auto", "API", "Local"], key="engine_mode", help="Auto: API sağlıklıysa API, değilse local fallback.")
            st.toggle("API yoksa Local Fallback", key="enable_local_fallback")
            st.toggle("Raporları kaydet (tarihçe)", key="save_history")
            st.toggle("Raporlarda tam DNA sakla", key="store_full_sequence")

        st.markdown("<div class='k-title' style='margin-top:10px;'>DNA/RNA Sequence</div><div class='k-muted'>IUPAC doğrulama + normalize</div>", unsafe_allow_html=True)
        st.text_area("DNA/RNA Sequence", key="current_sequence", height=200, label_visibility="collapsed", placeholder="DNA/RNA dizisini buraya yapıştır...")

        val = validate_iupac(st.session_state["current_sequence"], kind=st.session_state.get("seq_kind"), strict=bool(st.session_state.get("mode_strict")))
        if not val.seq:
            st.warning("Sequence boş.")
        elif not val.ok:
            bad = val.invalid_positions[0]
            st.error(f"Geçersiz karakter: pozisyon {bad[0]} -> '{bad[1]}'")
        else:
            info_cols = st.columns([1.2, 1.2, 2.6], gap="small")
            info_cols[0].markdown(f"<div class='k-card-tight'><b>Len</b><div class='k-mono'>{val.length}</div></div>", unsafe_allow_html=True)
            info_cols[1].markdown(f"<div class='k-card-tight'><b>GC%</b><div class='k-mono'>{val.gc_percent:.1f}%</div></div>", unsafe_allow_html=True)
            if val.warnings:
                info_cols[2].markdown(f"<div class='k-card-tight'><b>Uyarılar</b><div class='k-muted'>{' | '.join(val.warnings)}</div></div>", unsafe_allow_html=True)
            else:
                info_cols[2].markdown("<div class='k-card-tight'><b>Uyarılar</b><div class='k-muted'>—</div></div>", unsafe_allow_html=True)

        with st.expander("Chunk görünümü (60 karakter satır + pozisyon)", expanded=False):
            st.code(format_chunked(val.seq, width=60, with_pos=True), language="text")

        st.markdown("</div>", unsafe_allow_html=True)
    else:
        # still validate current_sequence for actions
        val = validate_iupac(st.session_state["current_sequence"], kind=st.session_state.get("seq_kind"), strict=bool(st.session_state.get("mode_strict")))

    # Toolbar / actions
    st.markdown("<div class='k-card'>", unsafe_allow_html=True)
    st.markdown("<div class='k-title'>Kontrol Paneli</div><div class='k-muted'>Run / Spec / Apply / Validate / Compare / Export / Save / Clear</div>", unsafe_allow_html=True)
    tcols = st.columns([1, 1, 1, 1, 1, 1, 1, 1, 1, 1], gap="small")
    run_btn = tcols[0].button("Run", type="primary", use_container_width=True)
    spec_btn = tcols[1].button("Generate Spec", use_container_width=True)
    apply_btn = tcols[2].button("Apply Spec", use_container_width=True)
    validate_btn = tcols[3].button("Validate", use_container_width=True)
    compare_btn = tcols[4].button("Compare", use_container_width=True)
    export_btn = tcols[5].button("Export", use_container_width=True)
    save_btn = tcols[6].button("Save Run", use_container_width=True)
    clear_btn = tcols[7].button("Clear", use_container_width=True)
    settings_btn = tcols[8].button("Settings", use_container_width=True)
    diag_btn = tcols[9].button("Diagnostics", use_container_width=True)

    # Keyboard triggers
    if st.session_state.get("trigger_run"):
        run_btn = True
        st.session_state["trigger_run"] = False
    if st.session_state.get("trigger_save"):
        save_btn = True
        st.session_state["trigger_save"] = False
    if st.session_state.get("trigger_export"):
        export_btn = True
        st.session_state["trigger_export"] = False

    if settings_btn:
        nav_to("Settings")
    if diag_btn:
        nav_to("Diagnostics")
    if clear_btn:
        st.session_state["current_spec"] = None
        st.session_state["current_result"] = None
        st.session_state["pipeline_log"] = []
        set_step("Idle")
        st.success("Workspace temizlendi.")
    st.markdown("</div>", unsafe_allow_html=True)

    render_stepper("Report" if st.session_state.get("current_result") else ("Spec" if st.session_state.get("current_spec") else "Parse"))

    # Action pre-check
    if (run_btn or spec_btn or apply_btn or validate_btn) and (not val.seq):
        st.error("Sequence boş. Önce DNA/RNA Sequence gir.")
        return
    if (run_btn or spec_btn or apply_btn or validate_btn) and (not val.ok):
        bad = val.invalid_positions[0]
        st.error(f"Sequence invalid: pozisyon {bad[0]} -> '{bad[1]}'")
        return

    # Engine selection
    api_health, api_err = api_get(api_base, "/health", timeout_s=timeout_s, api_key=api_key)
    api_ok = bool(api_health and api_health.get("ok") is True)
    engine = engine_mode if engine_mode != "Auto" else ("API" if api_ok else "Local")
    if engine == "API" and not api_ok and not enable_local_fallback:
        st.error(f"API yok/sağlıksız ve Local Fallback kapalı. Detay: {api_err}")
        return

    def spec_via_api() -> Tuple[Optional[Dict[str, Any]], Optional[str]]:
        return api_post(api_base, "/nl/spec", timeout_s=timeout_s, api_key=api_key, body={"intent": st.session_state["current_intent"], "mode": "strict" if bool(st.session_state.get("mode_strict")) else "lenient"})

    def apply_via_api(spec: Dict[str, Any]) -> Tuple[Optional[Dict[str, Any]], Optional[str]]:
        return api_post(api_base, "/edit/apply", timeout_s=timeout_s, api_key=api_key, body={"sequence": val.seq, "spec": spec, "mode": "strict" if bool(st.session_state.get("mode_strict")) else "lenient"})

    def run_via_api() -> Tuple[Optional[Dict[str, Any]], Optional[str]]:
        path = "/run?sequence=" + requests.utils.quote(val.seq, safe="")
        return api_post(api_base, path, timeout_s=timeout_s, api_key=api_key, body={"intent": st.session_state["current_intent"], "mode": "strict" if bool(st.session_state.get("mode_strict")) else "lenient"})

    def spec_local() -> Dict[str, Any]:
        return intent_to_editspec(st.session_state["current_intent"], strict_mode=bool(st.session_state.get("mode_strict")))

    def apply_local(spec: Dict[str, Any]) -> Dict[str, Any]:
        return apply_editspec(val.seq, spec, strict_mode=bool(st.session_state.get("mode_strict")), policy=policy)

    def run_local() -> Dict[str, Any]:
        return run_intent(val.seq, st.session_state["current_intent"], strict_mode=bool(st.session_state.get("mode_strict")), policy=policy)

    # Spec
    if spec_btn:
        set_step("Spec")
        with st.spinner("Spec üretiliyor..."):
            obj, err = (spec_via_api() if engine == "API" and api_ok else (None, None))
            if obj is None and enable_local_fallback:
                obj, err = spec_local(), None
            if err:
                st.error(f"Spec üretilemedi: {err}")
            else:
                st.session_state["current_spec"] = obj
                st.success("Spec hazır.")

    # Apply
    if apply_btn:
        set_step("Apply")
        spec = st.session_state.get("current_spec")
        if not spec:
            st.error("Spec yok. Önce Generate Spec.")
        else:
            with st.spinner("Spec uygulanıyor..."):
                obj, err = (apply_via_api(spec) if engine == "API" and api_ok else (None, None))
                if obj is None and enable_local_fallback:
                    obj, err = apply_local(spec), None
                if err:
                    st.error(f"Apply başarısız: {err}")
                else:
                    st.session_state["current_result"] = obj
                    st.success("Uygulandı.")

    # Validate
    if validate_btn:
        set_step("Validate")
        spec = st.session_state.get("current_spec")
        if not spec:
            st.error("Spec yok. Önce Generate Spec.")
        else:
            with st.spinner("Validasyon..."):
                obj = apply_local(spec)
                errs = obj.get("errors") or []
                if errs:
                    st.warning("Validasyon uyarıları/hataları var.")
                    st.json(errs)
                else:
                    st.success("Validasyon OK.")

    # Run
    if run_btn:
        set_step("Report")
        with st.spinner("Çalıştırılıyor..."):
            t0 = time.time()
            obj, err = (run_via_api() if engine == "API" and api_ok else (None, None))
            if obj is None and enable_local_fallback:
                obj, err = run_local(), None
            latency_ms = (time.time() - t0) * 1000.0
            if err:
                st.error(f"Run başarısız: {err}")
            else:
                before = obj.get("before") or val.seq
                after = obj.get("after") or before
                added, removed, changed = diff_stats(before, after)
                pol = obj.get("policy") or {}
                policy_allowed = pol.get("allowed") if isinstance(pol, dict) else obj.get("policy_allowed")
                policy_reason = pol.get("reason") if isinstance(pol, dict) else obj.get("policy_reason")
                run_rec = {
                    "run_id": obj.get("run_id") or obj.get("request_id") or datetime.now(timezone.utc).strftime("%Y%m%d%H%M%S"),
                    "ts_iso": datetime.now(timezone.utc).isoformat(timespec="seconds"),
                    "gene_id": active_gene.gene_id if active_gene else "",
                    "gene_name": active_gene.name if active_gene else "",
                    "intent": st.session_state.get("current_intent") or "",
                    "mode": "strict" if bool(st.session_state.get("mode_strict")) else "lenient",
                    "report_name": st.session_state.get("current_report_name") or "",
                    "before": before if bool(st.session_state.get("store_full_sequence")) else "",
                    "after": after if bool(st.session_state.get("store_full_sequence")) else "",
                    "before_len": len(before),
                    "after_len": len(after),
                    "added": added,
                    "removed": removed,
                    "changed": changed,
                    "latency_ms": round(latency_ms, 2),
                    "status": "success" if (not obj.get("errors")) else "warning",
                    "errors": obj.get("errors") or [],
                    "spec": obj.get("spec") or st.session_state.get("current_spec") or {},
                    "policy_allowed": policy_allowed,
                    "policy_reason": policy_reason,
                    "raw": obj,
                }
                st.session_state["current_result"] = obj
                st.session_state["selected_run_id"] = run_rec["run_id"]
                st.session_state["last_run_full"] = run_rec
                st.success("Run tamamlandı.")
                if st.session_state.get("save_history"):
                    append_run(RUNS_PATH, run_rec)

    # Save/export
    if save_btn:
        last = st.session_state.get("last_run_full")
        if not last:
            st.error("Kaydedilecek run yok.")
        else:
            append_run(RUNS_PATH, last)
            st.success("Run kaydedildi.")

    if export_btn:
        last = st.session_state.get("last_run_full")
        if not last:
            st.error("Export edilecek run yok.")
        else:
            st.markdown("<div class='k-card'><div class='k-title'>Export</div></div>", unsafe_allow_html=True)
            st.download_button("JSON indir", data=json.dumps(last, ensure_ascii=False, indent=2).encode("utf-8"), file_name="run.json", mime="application/json")
            st.download_button("Excel indir (.xlsx)", data=make_xlsx_bytes(last), file_name="run.xlsx", mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
            st.download_button("PDF indir", data=make_pdf_bytes(last), file_name="run.pdf", mime="application/pdf")
            st.download_button("Bundle ZIP indir", data=make_bundle_zip(last), file_name="export_bundle.zip", mime="application/zip")

    if compare_btn:
        st.session_state["compare_a"] = st.session_state.get("selected_run_id") or ""
        nav_to("Compare")

    # Results
    if view_mode in ("Run Mode", "Review Mode"):
        st.markdown("<div class='k-card'><div class='k-title'>Sonuç</div><div class='k-muted'>Before / After + diff</div></div>", unsafe_allow_html=True)
        last = st.session_state.get("last_run_full")
        if not last:
            st.info("Henüz bir run yok.")
        else:
            before = last.get("before") or (last.get("raw") or {}).get("before") or val.seq
            after = last.get("after") or (last.get("raw") or {}).get("after") or before
            st.markdown("<div class='k-card'>", unsafe_allow_html=True)
            ca, cb = st.columns(2, gap="medium")
            ca.text_area("Before", value=before, height=170)
            cb.text_area("After", value=after, height=170)

            if before == after:
                st.success("Değişiklik yok.")
            added, removed, changed = diff_stats(before, after)
            st.markdown(f"<div class='k-card-tight'>Δ Added: <b>{added}</b> | Removed: <b>{removed}</b> | Changed: <b>{changed}</b></div>", unsafe_allow_html=True)

            html1, reason = inline_diff_html(before, after)
            html2, reason2 = side_by_side_diff_html(before, after)
            tab1, tab2 = st.tabs(["INLINE Diff", "Side-by-side"])
            with tab1:
                if html1:
                    st.markdown(html1, unsafe_allow_html=True)
                else:
                    st.warning(f"Inline diff üretilemedi: {reason}")
            with tab2:
                if html2:
                    st.markdown(html2, unsafe_allow_html=True)
                else:
                    st.warning(f"Side-by-side diff üretilemedi: {reason2}")
            st.markdown("</div>", unsafe_allow_html=True)

    # History + inspector
    runs = load_jsonl(RUNS_PATH, limit=2000)
    meta = {}
    records = []
    for r in runs:
        if r.get("_type") == "meta" and r.get("run_id"):
            meta[r["run_id"]] = r
        elif r.get("_type") != "meta":
            records.append(r)
    for r in records:
        if r.get("run_id") in meta:
            r.update({k: v for k, v in meta[r["run_id"]].items() if k in ("pinned",)})
    # pinned first then newest
    records.sort(key=lambda x: (not bool(x.get("pinned")), x.get("ts_iso", "")), reverse=False)

    render_last20(records[:20])

    sel_run = None
    srid = st.session_state.get("selected_run_id") or ""
    for r in records:
        if r.get("run_id") == srid:
            sel_run = r
            break
    st.markdown(render_inspector_html(active_gene, sel_run), unsafe_allow_html=True)

def page_multigene(genes: List[Gene], store: GeneStore) -> List[Gene]:
    st.markdown("<div class='k-card'><div class='k-title'>Multi‑Gene Editor</div><div class='k-muted'>Gene listesi + editör + meta</div></div>", unsafe_allow_html=True)
    left, mid, right = st.columns([1.6, 3.2, 1.6], gap="medium")

    with left:
        st.text_input("Ara", key="gene_search", placeholder="Gen adı ara...")
        q = (st.session_state.get("gene_search") or "").strip().lower()
        filtered = [g for g in genes if (q in g.name.lower())] if q else genes
        if not filtered:
            st.info("Eşleşme yok.")
            filtered = genes
        labels = [f"{g.name}{' (ACTIVE)' if g.gene_id==st.session_state.get('selected_gene_id') else ''}" for g in filtered]
        sel = st.selectbox("Genler", options=list(range(len(filtered))), index=0, format_func=lambda i: labels[i])
        gsel = filtered[int(sel)]
        st.session_state["selected_gene_id"] = gsel.gene_id

        b1, b2 = st.columns(2, gap="small")
        if b1.button("➕ Ekle", use_container_width=True):
            ng = store.new_gene(f"Gene-{len(genes)+1}", "")
            genes = genes + [ng]
            store.save(genes)
            st.session_state["selected_gene_id"] = ng.gene_id
            st.rerun()
        if b2.button("🧬 Duplike", use_container_width=True):
            base = gsel
            ng = store.new_gene(base.name + " Copy", base.sequence)
            genes = genes + [ng]
            store.save(genes)
            st.session_state["selected_gene_id"] = ng.gene_id
            st.rerun()

        b3, b4 = st.columns(2, gap="small")
        if b3.button("🗑 Sil", use_container_width=True):
            genes = [g for g in genes if g.gene_id != gsel.gene_id]
            store.save(genes)
            st.session_state["selected_gene_id"] = genes[0].gene_id if genes else ""
            st.rerun()
        if b4.button("📋 Kopyala", use_container_width=True):
            st.session_state["clipboard_sequence"] = gsel.sequence
            st.info("Sekans panoya hazır (UI içi).")

        st.markdown("**Import**")
        up = st.file_uploader("FASTA / txt", type=["fasta", "fa", "txt"], label_visibility="collapsed")
        if up is not None:
            txt = up.read().decode("utf-8", errors="ignore")
            recs = parse_fasta(txt)
            if recs:
                for r in recs:
                    genes.append(store.new_gene(r["name"], r["sequence"]))
                store.save(genes)
                st.rerun()

        st.markdown("**Multi‑Paste**")
        mp = st.text_area("Birden fazla FASTA veya düz metin yapıştır", height=120, key="multi_paste")
        if st.button("Multi‑Paste Import", use_container_width=True):
            recs = parse_fasta(mp)
            if not recs:
                st.error("İçerik boş/parse edilemedi.")
            else:
                for r in recs:
                    genes.append(store.new_gene(r["name"], r["sequence"]))
                store.save(genes)
                st.session_state["multi_paste"] = ""
                st.rerun()

    active_gene = get_active_gene(genes)

    with mid:
        if not active_gene:
            st.info("Gen yok.")
        else:
            st.text_input("Gen adı", value=active_gene.name, key="mg_name")
            seq = st.text_area("Sekans", value=active_gene.sequence, height=260, key="mg_seq")
            notes = st.text_area("Notlar", value=getattr(active_gene, "notes", ""), height=120, key="mg_notes")
            if st.button("Kaydet", type="primary"):
                active_gene.name = (st.session_state["mg_name"].strip() or active_gene.name)
                active_gene.sequence = st.session_state["mg_seq"]
                active_gene.notes = st.session_state["mg_notes"]
                active_gene.updated_at = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
                out = [active_gene if g.gene_id == active_gene.gene_id else g for g in genes]
                genes = out
                store.save(genes)
                st.success("Kaydedildi.")
            with st.expander("Chunk görünümü (80)", expanded=False):
                v = validate_iupac(active_gene.sequence, strict=False)
                st.code(format_chunked(v.seq, width=80, with_pos=True), language="text")

    with right:
        if active_gene:
            v = validate_iupac(active_gene.sequence, strict=False)
            st.markdown("<div class='k-card-tight'><b>Meta</b></div>", unsafe_allow_html=True)
            st.markdown(f"<div class='k-card-tight k-muted'>Len: <b>{v.length}</b><br/>GC%: <b>{v.gc_percent:.1f}%</b><br/>Kind: <b>{v.kind}</b></div>", unsafe_allow_html=True)
            if v.invalid_positions:
                st.error(f"Geçersiz: {v.invalid_positions[0][0]} '{v.invalid_positions[0][1]}'")
            if v.warnings:
                st.warning(" | ".join(v.warnings))

            st.markdown("**Export**")
            st.download_button("Seçili gen FASTA", data=to_fasta([(active_gene.name, active_gene.sequence)]).encode("utf-8"), file_name=f"{active_gene.name}.fasta", mime="text/plain")
            st.download_button("Tüm genler FASTA", data=to_fasta([(g.name, g.sequence) for g in genes]).encode("utf-8"), file_name="genes.fasta", mime="text/plain")
    return genes

def page_reports() -> None:
    st.markdown("<div class='k-card'><div class='k-title'>Reports (History)</div><div class='k-muted'>Arama / filtre / export</div></div>", unsafe_allow_html=True)
    runs = [r for r in load_jsonl(RUNS_PATH, limit=4000) if r.get("_type") != "meta"]
    if not runs:
        st.info("Henüz rapor yok.")
        return
    q = st.text_input("Ara (gen/intent/run_id)", value="")
    status = st.selectbox("Durum", ["all", "success", "warning", "error"], index=0)
    pinned_only = st.toggle("Sadece pinned", value=False)

    def match(r: Dict[str, Any]) -> bool:
        if pinned_only and not r.get("pinned"):
            return False
        if status != "all" and r.get("status") != status:
            return False
        if q:
            s = (r.get("gene_name", "") + " " + r.get("intent", "") + " " + r.get("run_id", "")).lower()
            if q.lower() not in s:
                return False
        return True

    filtered = [r for r in runs if match(r)]
    filtered.sort(key=lambda x: x.get("ts_iso", ""), reverse=True)
    st.markdown(f"<div class='k-card-tight k-muted'>Gösterilen: <b>{len(filtered)}</b> / {len(runs)}</div>", unsafe_allow_html=True)

    options = filtered[:250]
    labels = [f"{r.get('ts_iso','')} | {r.get('gene_name','')} | {r.get('intent','')[:40]} | {r.get('run_id','')[:8]}" for r in options]
    sel = st.selectbox("Rapor seç", options=list(range(len(options))), index=0, format_func=lambda i: labels[i])
    r = options[int(sel)]
    st.session_state["selected_run_id"] = r.get("run_id", "")

    st.markdown("<div class='k-card'><div class='k-title'>Export</div></div>", unsafe_allow_html=True)
    st.download_button("JSON indir", data=json.dumps(r, ensure_ascii=False, indent=2).encode("utf-8"), file_name=f"{r.get('run_id','run')}.json", mime="application/json")
    st.download_button("Excel indir (.xlsx)", data=make_xlsx_bytes(r), file_name=f"{r.get('run_id','run')}.xlsx", mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
    st.download_button("PDF indir", data=make_pdf_bytes(r), file_name=f"{r.get('run_id','run')}.pdf", mime="application/pdf")
    st.download_button("Bundle ZIP indir", data=make_bundle_zip(r), file_name=f"{r.get('run_id','run')}_bundle.zip", mime="application/zip")

    before = (r.get("before") or (r.get("raw") or {}).get("before") or "")
    after = (r.get("after") or (r.get("raw") or {}).get("after") or "")
    tab1, tab2 = st.tabs(["INLINE", "SBS"])
    with tab1:
        html1, reason = inline_diff_html(before, after)
        st.markdown(html1, unsafe_allow_html=True) if html1 else st.warning(reason)
    with tab2:
        html2, reason2 = side_by_side_diff_html(before, after)
        st.markdown(html2, unsafe_allow_html=True) if html2 else st.warning(reason2)

def page_compare() -> None:
    st.markdown("<div class='k-card'><div class='k-title'>Compare Runs</div><div class='k-muted'>İki raporu seç → diff</div></div>", unsafe_allow_html=True)
    runs = [r for r in load_jsonl(RUNS_PATH, limit=3000) if r.get("_type") != "meta"]
    if len(runs) < 2:
        st.info("Compare için en az 2 rapor gerekli.")
        return
    runs.sort(key=lambda x: x.get("ts_iso", ""), reverse=True)
    pick = runs[:250]
    labels = [f"{r.get('ts_iso','')} | {r.get('gene_name','')} | {r.get('intent','')[:40]} | {r.get('run_id','')[:8]}" for r in pick]
    ids = [r.get("run_id", "") for r in pick]

    a_id = st.session_state.get("compare_a") or ids[0]
    b_id = st.session_state.get("compare_b") or (ids[1] if len(ids) > 1 else ids[0])
    a_idx = ids.index(a_id) if a_id in ids else 0
    b_idx = ids.index(b_id) if b_id in ids else 1

    c1, c2 = st.columns(2, gap="medium")
    with c1:
        a_sel = st.selectbox("Run A", options=list(range(len(labels))), index=a_idx, format_func=lambda i: labels[i])
    with c2:
        b_sel = st.selectbox("Run B", options=list(range(len(labels))), index=b_idx, format_func=lambda i: labels[i])

    a = pick[int(a_sel)]
    b = pick[int(b_sel)]
    st.session_state["compare_a"] = a.get("run_id", "")
    st.session_state["compare_b"] = b.get("run_id", "")

    a_before = (a.get("before") or (a.get("raw") or {}).get("before") or "")
    a_after = (a.get("after") or (a.get("raw") or {}).get("after") or "")
    b_before = (b.get("before") or (b.get("raw") or {}).get("before") or "")
    b_after = (b.get("after") or (b.get("raw") or {}).get("after") or "")

    st.markdown("<div class='k-card'><div class='k-title'>A Before/After</div></div>", unsafe_allow_html=True)
    ca, cb = st.columns(2, gap="medium")
    ca.text_area("A Before", value=a_before, height=140)
    cb.text_area("A After", value=a_after, height=140)

    st.markdown("<div class='k-card'><div class='k-title'>B Before/After</div></div>", unsafe_allow_html=True)
    cc, cd = st.columns(2, gap="medium")
    cc.text_area("B Before", value=b_before, height=140)
    cd.text_area("B After", value=b_after, height=140)

    st.markdown("<div class='k-card'><div class='k-title'>Diff: A.after vs B.after</div></div>", unsafe_allow_html=True)
    if a_after == b_after:
        st.success("Değişiklik yok (A.after == B.after).")

    html1, reason = inline_diff_html(a_after, b_after)
    html2, reason2 = side_by_side_diff_html(a_after, b_after)
    t1, t2 = st.tabs(["INLINE", "SBS"])
    with t1:
        st.markdown(html1, unsafe_allow_html=True) if html1 else st.warning(f"Diff üretilemedi: {reason}")
    with t2:
        st.markdown(html2, unsafe_allow_html=True) if html2 else st.warning(f"SBS diff üretilemedi: {reason2}")

def page_policy(policy: PolicyEvaluator) -> None:
    st.markdown("<div class='k-card'><div class='k-title'>Policy Studio</div><div class='k-muted'>Base/Override edit + simulate</div></div>", unsafe_allow_html=True)
    base_text = POLICY_BASE_PATH.read_text(encoding="utf-8") if POLICY_BASE_PATH.exists() else "{}"
    override_text = POLICY_OVERRIDE_PATH.read_text(encoding="utf-8") if POLICY_OVERRIDE_PATH.exists() else ""

    col1, col2 = st.columns(2, gap="medium")
    with col1:
        st.markdown("**Base Policy (read-only)**")
        st.code(base_text, language="json")
    with col2:
        st.markdown("**Override Policy (editable)**")
        txt = st.text_area("Override", value=override_text, height=240, key="policy_override_edit")
        bsave, bclear = st.columns(2)
        if bsave.button("Kaydet", type="primary"):
            try:
                json.loads(txt or "{}")
                POLICY_OVERRIDE_PATH.parent.mkdir(parents=True, exist_ok=True)
                POLICY_OVERRIDE_PATH.write_text(txt or "{}", encoding="utf-8")
                st.success("Override kaydedildi.")
            except Exception as e:
                st.error(f"JSON geçersiz: {e}")
        if bclear.button("Sıfırla"):
            if POLICY_OVERRIDE_PATH.exists():
                POLICY_OVERRIDE_PATH.unlink()
            st.success("Override silindi.")

    st.markdown("**Policy Explain (simulate)**")
    test_intent = st.text_input("Intent", value="ilk 5 baz sil", key="policy_test_intent")
    test_seq = st.text_area("Sequence (kısa)", value="ATGACCTTGGCTAACCTGTTACGATGGCCTTAA", height=120, key="policy_test_seq")
    if st.button("Test-Run"):
        s = validate_iupac(test_seq, strict=True).seq
        res = run_intent(s, test_intent, strict_mode=True, policy=policy)
        pol = res.get("policy") or {}
        st.json({"allowed": pol.get("allowed"), "reason": pol.get("reason"), "classification": pol.get("classification")})

def page_telemetry() -> None:
    st.markdown("<div class='k-card'><div class='k-title'>Telemetry</div><div class='k-muted'>Varsayılan OFF</div></div>", unsafe_allow_html=True)
    st.info("Telemetry bu build'de varsayılan kapalıdır. (Infra env ile açılır.)")

def page_diagnostics() -> None:
    st.markdown("<div class='k-card'><div class='k-title'>Diagnostics</div><div class='k-muted'>Health check + bağlantı testi</div></div>", unsafe_allow_html=True)
    api_base = st.session_state["api_base"]
    api_key = st.session_state["api_key"]
    timeout_s = float(st.session_state["timeout_s"])
    if st.button("Test Connection (/health)", type="primary"):
        obj, err = api_get(api_base, "/health", timeout_s=timeout_s, api_key=api_key)
        if err:
            st.error(err)
        else:
            st.success("OK")
            st.json(obj)

def page_settings() -> None:
    st.markdown("<div class='k-card'><div class='k-title'>Settings</div><div class='k-muted'>API + timeout + storage</div></div>", unsafe_allow_html=True)
    st.text_input("API Base", key="api_base")
    st.text_input("API Key (opsiyonel)", key="api_key", type="password")
    st.number_input("HTTP Timeout (sn)", min_value=1.0, max_value=60.0, key="timeout_s", step=1.0)
    st.markdown(f"<div class='k-card-tight k-muted'>UI Runs Path: <b>{RUNS_PATH}</b><br/>Genes Path: <b>{GENES_PATH}</b></div>", unsafe_allow_html=True)

# -----------------------------
# App entry
# -----------------------------
def main() -> None:
    st.set_page_config(page_title="Katopu GenLab (Ultra)", layout="wide")
    ss_init()

    # Apply deferred navigation (must happen before the sidebar radio with key='page_ui' is instantiated)
    if st.session_state.get("_nav_to"):
        st.session_state["page"] = st.session_state.pop("_nav_to")


    st.markdown(GLOBAL_CSS, unsafe_allow_html=True)

    gene_store = GeneStore(GENES_PATH)
    genes = ensure_default_gene(gene_store.load())
    policy = load_policy_evaluator()

    # Sidebar nav (fixed)
    with st.sidebar:
        st.markdown("### Katopu GenLab")
        st.markdown(f"<div class='k-muted'>v{APP_VERSION} • contract {CONTRACT_VERSION}</div>", unsafe_allow_html=True)
        pages = [
            "Workspace (Lab)",
            "Multi-Gene Editor",
            "Reports (History)",
            "Compare",
            "Policy Studio",
            "Telemetry",
            "Diagnostics",
            "Settings",
        ]
        # --- navigation UI/state sync (avoid Streamlit widget-state collision)
        # canonical navigation state: st.session_state["page"] (safe for programmatic changes)
        if "page" not in st.session_state:
            st.session_state["page"] = pages[0]
        # keep UI key in sync BEFORE widget is created
        st.session_state["page_ui"] = st.session_state.get("page_ui", st.session_state["page"])
        if st.session_state["page_ui"] != st.session_state["page"]:
            st.session_state["page_ui"] = st.session_state["page"]
        st.radio("Menu", pages, key="page_ui", label_visibility="collapsed")
        # after widget: sync back to canonical state
        if st.session_state.get("page") != st.session_state.get("page_ui"):
            st.session_state["page"] = st.session_state["page_ui"]
        st.divider()
        obj, err = api_get(st.session_state["api_base"], "/health", timeout_s=float(st.session_state["timeout_s"]), api_key=st.session_state["api_key"])
        api_ok = bool(obj and obj.get("ok") is True)
        st.markdown(f"**API Healthy:** {'✅' if api_ok else '❌'}")
        st.markdown("**Policy:** ✅")
        st.markdown("**Telemetry:** OFF")

    # Shortcuts
    inject_shortcuts_js()
    actions = handle_shortcut_actions()
    if actions.get("palette"):
        st.session_state["show_palette"] = True
    if actions.get("run"):
        st.session_state["trigger_run"] = True
    if actions.get("save"):
        st.session_state["trigger_save"] = True
    if actions.get("export"):
        st.session_state["trigger_export"] = True

    active_gene = get_active_gene(genes)
    env_label = os.environ.get("KATOPU_ENV", "local/dev").strip()
    active_gene_label = active_gene.name if active_gene else "—"

    st.markdown(topbar_html("Katopu GenLab — Ultra", env_label, active_gene_label), unsafe_allow_html=True)
    render_quickbar(genes)

    page = st.session_state.get("page")
    if page == "Workspace (Lab)":
        page_workspace(genes, policy)
    elif page == "Multi-Gene Editor":
        genes = page_multigene(genes, gene_store)
    elif page == "Reports (History)":
        page_reports()
    elif page == "Compare":
        page_compare()
    elif page == "Policy Studio":
        page_policy(policy)
    elif page == "Telemetry":
        page_telemetry()
    elif page == "Diagnostics":
        page_diagnostics()
    elif page == "Settings":
        page_settings()
    else:
        st.info("Sayfa yok.")

if __name__ == "__main__":
    main()
