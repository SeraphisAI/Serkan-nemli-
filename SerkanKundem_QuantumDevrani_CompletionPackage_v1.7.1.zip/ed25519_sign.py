#!/usr/bin/env python3
from __future__ import annotations
import argparse, base64, copy, hashlib, json, math
from typing import Any, Dict
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

def sha256_hex(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()

def b64url_decode(s: str) -> bytes:
    pad = "=" * (-len(s) % 4)
    return base64.urlsafe_b64decode(s + pad)

def b64url_encode(b: bytes) -> str:
    return base64.urlsafe_b64encode(b).decode("ascii").rstrip("=")

def _num_to_jcs(n: float) -> str:
    if not math.isfinite(n): raise ValueError("Non-finite number")
    if n == 0.0: return "0"
    if float(n).is_integer(): return str(int(n))
    s = repr(float(n))
    if "e" in s or "E" in s:
        s = s.replace("E","e")
        mant, exp = s.split("e",1)
        sign=""
        if exp.startswith(("+","-")):
            sign=exp[0]; exp=exp[1:]
        exp = exp.lstrip("0") or "0"
        if sign=="+": sign=""
        s=f"{mant}e{sign}{exp}"
    return s

def jcs_canonicalize(obj: Any) -> bytes:
    def canon(x: Any) -> str:
        if x is None: return "null"
        if x is True: return "true"
        if x is False: return "false"
        if isinstance(x, int) and not isinstance(x, bool): return str(x)
        if isinstance(x, float): return _num_to_jcs(x)
        if isinstance(x, str): return json.dumps(x, ensure_ascii=False, separators=(",",":"))
        if isinstance(x, list): return "[" + ",".join(canon(i) for i in x) + "]"
        if isinstance(x, dict):
            for k in x.keys():
                if not isinstance(k, str): raise TypeError("keys must be strings")
            items=[]
            for k in sorted(x.keys()):
                items.append(json.dumps(k, ensure_ascii=False, separators=(",",":")) + ":" + canon(x[k]))
            return "{" + ",".join(items) + "}"
        raise TypeError(type(x))
    return canon(obj).encode("utf-8")

def make_signable_object(manifest: Dict[str, Any], signing_scope: str) -> Dict[str, Any]:
    o = copy.deepcopy(manifest)
    if signing_scope == "manifest_without_hashes":
        o.pop("hashes", None); return o
    if signing_scope == "manifest_without_hashes.signatures":
        h=o.get("hashes")
        if isinstance(h, dict):
            h.pop("signatures", None)
        return o
    raise ValueError(signing_scope)

def main() -> int:
    ap=argparse.ArgumentParser()
    ap.add_argument("--manifest", required=True)
    ap.add_argument("--scope", default="manifest_without_hashes.signatures")
    ap.add_argument("--sk", required=True, help="Ed25519 private key raw 32 bytes base64url")
    args=ap.parse_args()

    manifest=json.load(open(args.manifest,"r",encoding="utf-8"))
    signable=jcs_canonicalize(make_signable_object(manifest,args.scope))
    expected=sha256_hex(signable)

    sk_raw=b64url_decode(args.sk)
    if len(sk_raw)!=32:
        raise SystemExit("sk must be 32 raw bytes")
    sk=Ed25519PrivateKey.from_private_bytes(sk_raw)
    sig=sk.sign(signable)
    print("expected_signable_bytes_sha256:", expected)
    print("sig_b64u:", b64url_encode(sig))
    return 0

if __name__=="__main__":
    raise SystemExit(main())
