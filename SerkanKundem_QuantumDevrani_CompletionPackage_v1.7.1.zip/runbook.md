# Serkan Kündem — Quantum Devranı Completion Package (v1.7.1)

## Ana dosya
- OpenAPI: `SerkanKundem_quantum-devrani-openapi-bundle.v1.7.1.yaml` (sha256: `b4e76bbef94643dee4164e192396f5e7e123a3e7890d9fdcd11101eb0e878bda`)

## 0) Tek dosya paket (ZIP)
- `SerkanKundem_QuantumDevrani_CompletionPackage_v1.7.1.zip` (sha256 aşağıda)

## 1) Offline kripto doğrulama (JCS + Ed25519)
1) `keys.json` hazırla (kid -> pubkey_b64u):
```json
{
  "did:key:example#ed25519-1": "<base64url(pubkey_raw_32bytes)>"
}
```
2) Çalıştır:
```bash
pip install cryptography
./offline_verify.py --manifest manifest.example.json --keys keys.json --out verify_response.json
jq . verify_response.json
```

## 2) İmza üretme (ed25519_sign.py)
```bash
pip install cryptography
./ed25519_sign.py --manifest manifest.example.json --scope manifest_without_hashes.signatures --sk "<base64url(sk_raw_32bytes)>"
```
Çıktıdaki `sig_b64u`’yu `manifest.example.json` içindeki `hashes.signatures[0].sig_b64u` alanına koy.

## 3) Determinizm checklist
- `sceneIdByFrame` uzunluğu = `total_frames` mı?
- `hashes.manifest_body_sha256` gerçekten `manifest_without_hashes.signatures` scope’u mu?
- Mixed-scope:
  - `unique_expected_signable_hashes_count > 1` ise `policy.mixed_scope_detected = true` olmalı.

## 4) Anti-hallucination referans
Paketteki `karanlık madde.txt`, kanıtsız “hiper süper ultra gelişmişim” türü driftin nasıl oluştuğuna örnek ham log içerir.
