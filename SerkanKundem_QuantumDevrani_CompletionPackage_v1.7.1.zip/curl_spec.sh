#!/usr/bin/env bash
set -euo pipefail
BASE_URL="${BASE_URL:-https://api.obscura-quantum.example/v1}"
API_KEY="${API_KEY:-}"
H=(-H "Content-Type: application/json")
if [[ -n "${API_KEY}" ]]; then H+=(-H "X-API-Key: ${API_KEY}"); fi

echo "POST /storyboards"
curl -sS "${H[@]}" -X POST "${BASE_URL}/storyboards" --data-binary @manifest.example.json | tee storyboard_create.json | jq . >/dev/null
STORYBOARD_ID="$(jq -r '.storyboardId // "sb_example"' storyboard_create.json)"

echo "POST /storyboards/${STORYBOARD_ID}/verify-signatures"
curl -sS "${H[@]}" -X POST "${BASE_URL}/storyboards/${STORYBOARD_ID}/verify-signatures" --data-binary @verify_request.json | tee verify_response.json | jq . >/dev/null

echo "POST /system/status"
curl -sS "${H[@]}" -X POST "${BASE_URL}/system/status" --data-binary '{"context":"training"}' | jq . >/dev/null
echo "OK"
