#!/usr/bin/env python3
from __future__ import annotations
import argparse, glob, json, os, re
from typing import Dict, List, Tuple

try:
    import yaml  # type: ignore
except Exception:
    yaml = None

ENV_RE = re.compile(r"os\.getenv\(\s*[\"']([^\"']+)[\"']")
ROUTE_RE = re.compile(r"@app\.(get|post|put|delete|patch)\(\s*[\"']([^\"']+)[\"']")

def load_openapi_paths(spec_path: str) -> set[tuple[str,str]]:
    if yaml is None:
        raise SystemExit("pyyaml required: pip install pyyaml")
    spec = yaml.safe_load(open(spec_path, "r", encoding="utf-8"))
    out=set()
    for p, methods in (spec.get("paths") or {}).items():
        if isinstance(methods, dict):
            for m in methods.keys():
                if m.lower() in {"get","post","put","delete","patch"}:
                    out.add((m.lower(), p))
    return out

def scan_code(root: str):
    py_files = sorted(glob.glob(os.path.join(root, "**/*.py"), recursive=True))
    routes=set()
    env: Dict[str, List[str]] = {}
    for fp in py_files:
        txt=open(fp,"r",encoding="utf-8",errors="ignore").read()
        for m in ROUTE_RE.finditer(txt):
            routes.add((m.group(1).lower(), m.group(2)))
        for m in ENV_RE.finditer(txt):
            env.setdefault(m.group(1), []).append(fp)
    return routes, env

def main()->int:
    ap=argparse.ArgumentParser()
    ap.add_argument("--spec", required=True)
    ap.add_argument("--code", required=True)
    ap.add_argument("--out", default="compat_report.json")
    args=ap.parse_args()

    spec_paths = load_openapi_paths(args.spec)
    code_routes, env = scan_code(args.code)

    report = {
        "spec_routes": sorted([{"method":m,"path":p} for (m,p) in spec_paths]),
        "code_routes": sorted([{"method":m,"path":p} for (m,p) in code_routes]),
        "missing_in_code": sorted([{"method":m,"path":p} for (m,p) in (spec_paths - code_routes)]),
        "extra_in_code": sorted([{"method":m,"path":p} for (m,p) in (code_routes - spec_paths)]),
        "env_vars": env
    }
    json.dump(report, open(args.out,"w",encoding="utf-8"), ensure_ascii=False, indent=2)
    print(args.out)
    return 0

if __name__=="__main__":
    raise SystemExit(main())
