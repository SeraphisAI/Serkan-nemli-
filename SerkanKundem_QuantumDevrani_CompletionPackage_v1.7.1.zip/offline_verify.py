#!/usr/bin/env python3
from __future__ import annotations
import argparse, base64, copy, hashlib, json, math
from typing import Any, Dict, List, Optional
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

def sha256_hex(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def b64url_decode(s: str) -> bytes:
    pad = "=" * (-len(s) % 4)
    return base64.urlsafe_b64decode(s + pad)

def _num_to_jcs(n: float) -> str:
    if not math.isfinite(n):
        raise ValueError("Non-finite number not allowed in JSON/JCS")
    if n == 0.0:
        return "0"
    if float(n).is_integer():
        return str(int(n))
    s = repr(float(n))
    if "e" in s or "E" in s:
        s = s.replace("E", "e")
        mant, exp = s.split("e", 1)
        sign = ""
        if exp.startswith(("+", "-")):
            sign = exp[0]; exp = exp[1:]
        exp = exp.lstrip("0") or "0"
        if sign == "+": sign = ""
        s = f"{mant}e{sign}{exp}"
    return s

def jcs_canonicalize(obj: Any) -> bytes:
    def canon(x: Any) -> str:
        if x is None: return "null"
        if x is True: return "true"
        if x is False: return "false"
        if isinstance(x, int) and not isinstance(x, bool): return str(x)
        if isinstance(x, float): return _num_to_jcs(x)
        if isinstance(x, str): return json.dumps(x, ensure_ascii=False, separators=(",", ":"))
        if isinstance(x, list): return "[" + ",".join(canon(i) for i in x) + "]"
        if isinstance(x, dict):
            for k in x.keys():
                if not isinstance(k, str):
                    raise TypeError("JCS requires object keys to be strings")
            items=[]
            for k in sorted(x.keys()):
                items.append(json.dumps(k, ensure_ascii=False, separators=(",", ":")) + ":" + canon(x[k]))
            return "{" + ",".join(items) + "}"
        raise TypeError(f"Unsupported JSON type: {type(x)}")
    return canon(obj).encode("utf-8")

def make_signable_object(manifest: Dict[str, Any], signing_scope: str) -> Dict[str, Any]:
    o = copy.deepcopy(manifest)
    if signing_scope == "manifest_without_hashes":
        o.pop("hashes", None); return o
    if signing_scope == "manifest_without_hashes.signatures":
        h = o.get("hashes")
        if isinstance(h, dict):
            h.pop("signatures", None)
        return o
    raise ValueError(f"Unsupported signing_scope: {signing_scope}")

def is_pqc_alg(alg: str) -> bool:
    return alg.startswith("ML-DSA") or alg.startswith("SLH-DSA")

def verify_ed25519(pubkey_raw: bytes, message: bytes, sig: bytes) -> bool:
    try:
        Ed25519PublicKey.from_public_bytes(pubkey_raw).verify(sig, message)
        return True
    except Exception:
        return False

def load_kid_map(path: str) -> Dict[str, bytes]:
    d = json.load(open(path, "r", encoding="utf-8"))
    return {kid: b64url_decode(b64u) for kid, b64u in d.items()}

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--manifest", required=True)
    ap.add_argument("--keys", required=True, help="keys.json (kid->pubkey_b64u)")
    ap.add_argument("--out", default="verify_response.json")
    args = ap.parse_args()

    manifest = json.load(open(args.manifest, "r", encoding="utf-8"))
    kid_map = load_kid_map(args.keys)

    hashes = manifest.get("hashes") or {}
    canon_name = ((hashes.get("canonicalization") or {}).get("name")) or "JCS-RFC8785"
    sigs = hashes.get("signatures") or []
    policy = hashes.get("signature_policy") or {}

    require = policy.get("require", "ALL")
    accepted_algs = policy.get("accepted_algs") or []
    min_pqc = int(policy.get("min_pqc_signatures", 0))

    results: List[Dict[str, Any]] = []
    expected_hashes: List[str] = []
    errors: List[str] = []

    for s in sigs:
        sid = s.get("id", "")
        alg = s.get("alg", "")
        kid = s.get("kid", "")
        scope = s.get("signing_scope", "manifest_without_hashes.signatures")
        sig_b64u = s.get("sig_b64u", "")

        signable_obj = make_signable_object(manifest, scope)
        signable_bytes = jcs_canonicalize(signable_obj)
        expected = sha256_hex(signable_bytes)
        expected_hashes.append(expected)

        ok = False
        reason: Optional[str] = None
        try:
            pub = kid_map[kid]
            sig = b64url_decode(sig_b64u)
            if alg == "Ed25519":
                ok = verify_ed25519(pub, signable_bytes, sig)
                if not ok: reason = "bad_signature"
            elif is_pqc_alg(alg):
                reason = "pqc_verifier_not_installed"
            else:
                reason = "unsupported_alg"
        except KeyError:
            reason = "unknown_kid"
        except Exception as e:
            reason = "exception"
            errors.append(f"signature_error:{sid}:{type(e).__name__}")

        results.append({
            "id": sid,
            "alg": alg,
            "kid": kid,
            "valid": bool(ok),
            "pqc": bool(is_pqc_alg(alg)),
            "expected_signable_bytes_sha256": expected,
            **({"reason": reason} if (not ok and reason) else {}),
        })

    uniq = sorted(set(expected_hashes))
    uniq_count = len(uniq)
    uniq_list = uniq[:8]
    global_hash = uniq[0] if uniq_count == 1 else None

    considered = [r for r in results if (not accepted_algs) or (r["alg"] in accepted_algs)]
    valid_count = sum(1 for r in considered if r["valid"])
    pqc_valid_count = sum(1 for r in considered if r["valid"] and r["pqc"])

    if require == "ALL":
        satisfied = (len(considered) > 0) and all(r["valid"] for r in considered) and (pqc_valid_count >= min_pqc)
    else:
        satisfied = any(r["valid"] for r in considered) and (pqc_valid_count >= min_pqc)

    report: Dict[str, Any] = {
        "storyboardId": manifest.get("storyboardId", "sb_local"),
        "manifest_body_sha256": hashes.get("manifest_body_sha256", ""),
        "signable_scope": "manifest_without_hashes.signatures",
        "canonicalization_used": canon_name,
        "unique_expected_signable_hashes_count": uniq_count,
        "unique_expected_signable_hashes": uniq_list,
        "signatures": results,
        "policy": {
            "require": require,
            "accepted_algs": accepted_algs,
            "min_pqc_signatures": min_pqc,
            "satisfied": bool(satisfied),
            "observed_pqc_valid_count": int(pqc_valid_count),
            "observed_valid_count": int(valid_count),
            "mixed_scope_detected": bool(uniq_count > 1),
        },
        "overall_valid": bool(satisfied and not errors),
        "errors": errors,
    }
    if global_hash:
        report["signable_bytes_sha256"] = global_hash

    json.dump(report, open(args.out, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
