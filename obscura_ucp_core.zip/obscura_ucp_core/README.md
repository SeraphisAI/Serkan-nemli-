# Obscura UCP Core (0.1.0)

Modüler, policy-driven, **PQC-ready** (arayüz) ve **quantum-hybrid** (simülasyon + eklenti arayüzü) bir referans iskelet.

> Not: “Bilinç” iddiaları bilimsel olarak doğrulanmış bir mühendislik gereksinimi değildir. Bu repo, **dogma/ideoloji gömmeden**
> (yani *gizli prompt / gömülü normatif kurallar* yerine) **açıkça sürümlü politika dosyaları** + **şeffaf telemetri** + **geri-alınabilir güncelleme**
> yaklaşımı uygular. Güvenlik sınırları yine de açık politika ile korunur.

## Quickstart (local)

```bash
cp .env.example .env
make migrate
make dev
```

Health:
- `GET http://localhost:8000/health`

Docs:
- `http://localhost:8000/docs`

## Core Modules

- `core/` domain mantığı (guidance, chat, quantum, updates)
- `transport/` HTTP + WS; gRPC stubları için altyapı
- `security/` API key + JWT + basit rate-limit
- `privacy/` veri sınıflandırma + maskeleme + retention
- `policy/` YAML policy + evaluator + audit
- `telemetry/` event üretimi (default off) + middleware
- `migrations/` sqlite migration runner

## Migrations

```bash
make migrate
```

## Tests

```bash
make test
```

## Update / Rollback

- `POST /update/check` mevcut kanal manifestini okur
- `POST /update/apply` imzalı (HMAC) paket uygular, önceki sürümü `.rollback/` altında saklar

## OpenAPI

- Kaynak sözleşme: `openapi/obscura-ucp-core.openapi.yaml`
- Runtime: `GET /openapi.json`
