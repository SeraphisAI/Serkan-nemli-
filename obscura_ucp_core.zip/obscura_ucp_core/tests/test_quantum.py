from fastapi.testclient import TestClient
from obscura.transport.http.app import app

client = TestClient(app)

def test_quantum_bell():
    payload = {
        "qubits": 2,
        "gates": [
            {"gate":"H","target":0},
            {"gate":"CNOT","target":1,"control":0}
        ],
        "returnStatevector": False
    }
    r = client.post("/quantum/compute", json=payload)
    assert r.status_code in (200,403)
    if r.status_code == 200:
        probs = r.json()["probs"]
        # Expect about 0.5 on 00 and 11
        assert "00" in probs and "11" in probs
