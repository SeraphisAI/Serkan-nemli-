from fastapi.testclient import TestClient
from obscura.transport.http.app import app

client = TestClient(app)

def test_guide_requires_api_key_when_provided():
    # If X-API-Key header is provided and wrong => 401
    r = client.post("/assistant/guide", headers={"X-API-Key":"wrong"}, json={"targetGoal":"high_fidelity","experienceLevel":"beginner"})
    assert r.status_code == 401

def test_guide_works_anonymous():
    r = client.post("/assistant/guide", json={"targetGoal":"high_fidelity","experienceLevel":"beginner"})
    assert r.status_code in (200,403)  # depends on policy; default uses anonymous role 'user'
    if r.status_code == 200:
        assert "steps" in r.json()
