from __future__ import annotations
import base64
import hmac
import hashlib
from dataclasses import dataclass
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

@dataclass
class EncryptOut:
    algorithm: str
    ciphertext_b64: str
    nonce_b64: str
    encapsulated_key_b64: str | None = None

@dataclass
class DecryptOut:
    algorithm: str
    plaintext: str

class CryptoProvider:
    def encrypt(self, plaintext: str, aad: str | None) -> EncryptOut:
        raise NotImplementedError

    def decrypt(self, ciphertext_b64: str, nonce_b64: str, aad: str | None, encapsulated_key_b64: str | None) -> DecryptOut:
        raise NotImplementedError

class AESGCMProvider(CryptoProvider):
    def __init__(self, master_key: bytes):
        if len(master_key) != 32:
            raise ValueError("master key must be 32 bytes")
        self.key = master_key
        self.aesgcm = AESGCM(self.key)

    def encrypt(self, plaintext: str, aad: str | None) -> EncryptOut:
        # cryptography doesn't have a nonce generator helper; use os.urandom
        import os
        nonce = os.urandom(12)
        ct = self.aesgcm.encrypt(nonce, plaintext.encode("utf-8"), (aad or "").encode("utf-8"))
        return EncryptOut(
            algorithm="AESGCM",
            ciphertext_b64=base64.b64encode(ct).decode("ascii"),
            nonce_b64=base64.b64encode(nonce).decode("ascii"),
        )

    def decrypt(self, ciphertext_b64: str, nonce_b64: str, aad: str | None, encapsulated_key_b64: str | None) -> DecryptOut:
        nonce = base64.b64decode(nonce_b64)
        ct = base64.b64decode(ciphertext_b64)
        pt = self.aesgcm.decrypt(nonce, ct, (aad or "").encode("utf-8"))
        return DecryptOut(algorithm="AESGCM", plaintext=pt.decode("utf-8"))

class PQCHybridStubProvider(CryptoProvider):
    # Placeholder: demonstrates API shape for a KEM + symmetric AEAD.
    # Plug in Kyber or another PQC KEM later.
    def __init__(self, master_key: bytes):
        self.inner = AESGCMProvider(master_key)

    def encrypt(self, plaintext: str, aad: str | None) -> EncryptOut:
        out = self.inner.encrypt(plaintext, aad)
        # "encapsulated key" stub = HMAC(master_key, nonce)
        import base64
        ek = hmac.new(self.inner.key, base64.b64decode(out.nonce_b64), hashlib.sha256).digest()
        out.algorithm = "PQC_HYBRID_STUB"
        out.encapsulated_key_b64 = base64.b64encode(ek).decode("ascii")
        return out

    def decrypt(self, ciphertext_b64: str, nonce_b64: str, aad: str | None, encapsulated_key_b64: str | None) -> DecryptOut:
        # We ignore encapsulated_key_b64 in stub; in real KEM we'd validate/derive session key.
        out = self.inner.decrypt(ciphertext_b64, nonce_b64, aad, encapsulated_key_b64)
        out.algorithm = "PQC_HYBRID_STUB"
        return out