from __future__ import annotations
from pydantic import BaseModel, Field
from typing import Any, Optional, Literal

class GuideRequest(BaseModel):
    targetGoal: str
    experienceLevel: Literal["beginner","intermediate","advanced"]
    context: dict[str, Any] = Field(default_factory=dict)

class GuideResponse(BaseModel):
    steps: list[str]
    warnings: list[str] = Field(default_factory=list)
    nextActions: list[str] = Field(default_factory=list)

class ChatRequest(BaseModel):
    message: str
    sessionId: str | None = None
    persona: str | None = None
    context: dict[str, Any] = Field(default_factory=dict)

class ChatResponse(BaseModel):
    responseId: str
    message: str
    transparency: dict[str, Any] = Field(default_factory=dict)

class GateInstruction(BaseModel):
    gate: Literal["H","X","Z","CNOT"]
    target: int
    control: int | None = None

class QuantumComputeRequest(BaseModel):
    qubits: int = Field(ge=1, le=8)
    gates: list[GateInstruction]
    returnStatevector: bool = False

class QuantumComputeResponse(BaseModel):
    probs: dict[str, float]
    statevector: list[str] | None = None
    metrics: dict[str, Any]

class EncryptRequest(BaseModel):
    plaintext: str
    aad: str | None = None
    algorithm: Literal["AESGCM","PQC_HYBRID_STUB"] = "AESGCM"

class EncryptResponse(BaseModel):
    algorithm: str
    ciphertext_b64: str
    nonce_b64: str
    encapsulated_key_b64: str | None = None

class DecryptRequest(BaseModel):
    ciphertext_b64: str
    nonce_b64: str
    encapsulated_key_b64: str | None = None
    aad: str | None = None
    algorithm: Literal["AESGCM","PQC_HYBRID_STUB"] = "AESGCM"

class DecryptResponse(BaseModel):
    algorithm: str
    plaintext: str

class UserCreate(BaseModel):
    username: str
    email: str

class OrderCreate(BaseModel):
    userId: int
    item: str
    amount: float

class PolicyEvalRequest(BaseModel):
    subject: dict[str, Any]
    action: str
    resource: dict[str, Any]

class PolicyEvalResponse(BaseModel):
    decision: Literal["allow","deny"]
    reasons: list[str]
    obligations: list[str]

class TelemetryEventIn(BaseModel):
    type: str
    ts: str
    data: dict[str, Any]
