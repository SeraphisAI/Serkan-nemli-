from __future__ import annotations
from dataclasses import dataclass
from typing import Any
import uuid

@dataclass
class TransparencyReport:
    model: str
    version: str
    confidence: float
    relevance: float
    notes: list[str]

class HyperTransparentAI:
    def __init__(self, model_name: str, version: str = "0.1.0", transparency_level: str = "high"):
        self.model_name = model_name
        self.version = version
        self.transparency_level = transparency_level

    def respond(self, message: str) -> tuple[str, TransparencyReport]:
        # Minimal local response generator (replace with LLM adapter)
        reply = self._generate(message)
        rep = self._transparency(message)
        return reply, rep

    def _generate(self, message: str) -> str:
        # deliberately non-dogmatic: ask clarifying + offer next steps
        if "kuantum" in message.lower():
            return "Kuantum tarafında hangi hedefe gidiyoruz: simülasyon mu, devre optimizasyonu mu, yoksa kripto mu?"
        return "Anladım. Hedefi (domain), öncelikleri ve kısıtları yazarsan bir sonraki adımı netleştirebilirim."

    def _transparency(self, message: str) -> TransparencyReport:
        # Heuristic scores for demo
        confidence = 0.85 if len(message) > 8 else 0.65
        relevance = 0.9
        notes = []
        if self.transparency_level == "high":
            notes += [
                "Yanıt yerel bir kural-temelli stub ile üretildi (LLM adaptörü tak-çıkar).",
                "Politika değerlendirmesi ve maskeleme katmanı istek/yanıt çevresinde çalışır.",
            ]
        return TransparencyReport(
            model=self.model_name,
            version=self.version,
            confidence=confidence,
            relevance=relevance,
            notes=notes,
        )

def new_response_id() -> str:
    return str(uuid.uuid4())
