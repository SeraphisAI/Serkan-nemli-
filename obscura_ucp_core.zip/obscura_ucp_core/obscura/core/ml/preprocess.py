from __future__ import annotations
import re
import string
from typing import Iterable

def clean_text(text: str, *, remove_numbers: bool = True) -> str:
    """Lightweight text cleaner (no NLTK dependency)."""
    text = text.lower()
    text = text.translate(str.maketrans("", "", string.punctuation))
    if remove_numbers:
        text = re.sub(r"\d+", "", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text
