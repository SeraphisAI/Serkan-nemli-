from __future__ import annotations
from typing import Any

def guide(target_goal: str, experience: str, context: dict[str, Any] | None = None) -> dict[str, Any]:
    context = context or {}
    steps: list[str] = []
    warnings: list[str] = []
    next_actions: list[str] = []

    # Minimal but useful logic (expand via plugin packs)
    if experience == "beginner":
        steps += [
            "Hedefi netleştir: doğruluk / derinlik / gürültü toleransı.",
            "Qubit sayısını küçük tut (1–4) ve temel kapılarla başla (H, X, CNOT).",
            "Devreyi simüle et, olasılık dağılımını gözle.",
            "Gürültü/güvenlik gereksinimi varsa şifreleme ve politika katmanını etkinleştir.",
        ]
        next_actions += ["Örnek devre oluştur: 2 qubit, H(0), CNOT(0->1).", "Simülasyonu çalıştır."]
    elif experience == "intermediate":
        steps += [
            "Metrikleri seç: depth, gate-count, fidelity proxy, latency.",
            "Devreyi optimize et: kapı birleştirme, gereksiz Z/X iptali, paralelleştirme.",
            "Policy pack ile erişim/masking/retention kurallarını sürümle.",
        ]
        next_actions += ["/quantum/compute ile karşılaştırmalı simülasyon", "telemetry örneklemesini %10 başlat"]
    else:
        steps += [
            "Hybrid backend seç: simülasyon + QPU sağlayıcı eklentisi (plugin).",
            "PQC-ready kripto arayüzünde gerçek KEM (örn. Kyber) entegrasyonu planla.",
            "Güncelleme kanalı + imza doğrulama + rollback ile güvenli evrim kur.",
        ]
        next_actions += ["update channel governance", "gRPC/WS adaptörlerini aç"]

    if target_goal in {"high_fidelity", "low_noise"}:
        warnings.append("Fidelity gerçek QPU'da kalibrasyon ve gürültü modeli gerektirir; simülasyon sadece yaklaşım verir.")
    if context.get("autonomy") == "high":
        warnings.append("Yüksek otonomi modunda insan-onayı ve rollback şartı önerilir.")

    return {"steps": steps, "warnings": warnings, "nextActions": next_actions}
