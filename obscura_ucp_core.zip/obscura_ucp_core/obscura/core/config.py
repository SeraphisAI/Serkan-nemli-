from __future__ import annotations
import os
import base64
from dataclasses import dataclass
from pathlib import Path

def _env(key: str, default: str | None = None) -> str | None:
    return os.environ.get(key, default)

@dataclass(frozen=True)
class Settings:
    app_env: str
    app_name: str
    app_version: str
    base_url: str
    data_dir: Path

    api_key: str
    jwt_secret: str
    jwt_issuer: str
    jwt_audience: str
    jwt_ttl_seconds: int

    crypto_master_key: bytes

    telemetry_enabled: bool
    telemetry_sample_rate: float
    telemetry_sink: str
    telemetry_file: Path

    updates_channel_file: Path
    updates_hmac_secret: bytes

def load_settings() -> Settings:
    data_dir = Path(_env("DATA_DIR", "./data") or "./data")
    data_dir.mkdir(parents=True, exist_ok=True)

    # Crypto key: if absent, generate and persist (dev-friendly, not production best practice)
    key_b64 = (_env("CRYPTO_MASTER_KEY_B64") or "").strip()
    keys_dir = data_dir / "keys"
    keys_dir.mkdir(parents=True, exist_ok=True)
    persisted = keys_dir / "master_key.b64"

    if not key_b64:
        if persisted.exists():
            key_b64 = persisted.read_text(encoding="utf-8").strip()
        else:
            raw = os.urandom(32)
            key_b64 = base64.b64encode(raw).decode("ascii")
            persisted.write_text(key_b64, encoding="utf-8")

    crypto_master_key = base64.b64decode(key_b64)

    updates_secret = (_env("UPDATES_HMAC_SECRET", "dev-updates-secret-change-me") or "").encode("utf-8")

    return Settings(
        app_env=_env("APP_ENV", "dev") or "dev",
        app_name=_env("APP_NAME", "Obscura UCP Core") or "Obscura UCP Core",
        app_version=_env("APP_VERSION", "0.1.0") or "0.1.0",
        base_url=_env("BASE_URL", "http://localhost:8000") or "http://localhost:8000",
        data_dir=data_dir,

        api_key=_env("API_KEY", "dev-change-me") or "dev-change-me",
        jwt_secret=_env("JWT_SECRET", "dev-jwt-secret-change-me") or "dev-jwt-secret-change-me",
        jwt_issuer=_env("JWT_ISSUER", "obscura-ucp") or "obscura-ucp",
        jwt_audience=_env("JWT_AUDIENCE", "obscura-ucp-clients") or "obscura-ucp-clients",
        jwt_ttl_seconds=int(_env("JWT_TTL_SECONDS", "3600") or "3600"),

        crypto_master_key=crypto_master_key,

        telemetry_enabled=(_env("TELEMETRY_ENABLED", "false") or "false").lower() == "true",
        telemetry_sample_rate=float(_env("TELEMETRY_SAMPLE_RATE", "0.1") or "0.1"),
        telemetry_sink=_env("TELEMETRY_SINK", "file") or "file",
        telemetry_file=Path(_env("TELEMETRY_FILE", str(data_dir / "telemetry/events.jsonl")) or str(data_dir / "telemetry/events.jsonl")),

        updates_channel_file=Path(_env("UPDATES_CHANNEL_FILE", "./updates/channel.json") or "./updates/channel.json"),
        updates_hmac_secret=updates_secret,
    )
