from __future__ import annotations
import json
from pathlib import Path
from collections import Counter, defaultdict

def recommend(telemetry_file: Path) -> dict:
    if not telemetry_file.exists():
        return {"recommendations": ["Telemetry yok: önce TELEMETRY_ENABLED=true yapıp örnekleme başlat."], "evidence": {}}

    counts = Counter()
    lat = defaultdict(list)
    with telemetry_file.open("r", encoding="utf-8") as f:
        for line in f:
            try:
                ev = json.loads(line)
            except Exception:
                continue
            if ev.get("type") != "request":
                continue
            path = ev["data"].get("path","")
            counts[path] += 1
            lat[path].append(ev["data"].get("latency_ms", 0))

    rec = []
    if counts:
        hottest = counts.most_common(3)
        rec.append(f"En yoğun endpoint(ler): {hottest}. Cache/rate-limit gözden geçir.")
        # latency
        for p, arr in lat.items():
            if arr and (sum(arr)/len(arr)) > 200:
                rec.append(f"{p} ortalama latency yüksek: {sum(arr)/len(arr):.1f}ms. Payload küçültme / async önerilir.")
    else:
        rec.append("Kayıt var ama request event yok. Middleware konfigürasyonunu kontrol et.")

    return {"recommendations": rec, "evidence": {"counts": dict(counts)}}
