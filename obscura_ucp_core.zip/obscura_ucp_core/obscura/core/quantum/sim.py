from __future__ import annotations
import numpy as np
from dataclasses import dataclass

# Small statevector simulator for <= 8 qubits (2^8 = 256 complex numbers)
# This is a hybrid-ready stub: replace the backend with a real QPU provider via plugin.

@dataclass
class Gate:
    gate: str
    target: int
    control: int | None = None

H = (1/np.sqrt(2)) * np.array([[1, 1],[1, -1]], dtype=np.complex128)
X = np.array([[0, 1],[1, 0]], dtype=np.complex128)
Z = np.array([[1, 0],[0, -1]], dtype=np.complex128)

def _apply_single(state: np.ndarray, n: int, target: int, U: np.ndarray) -> np.ndarray:
    # Tensor product apply via bit tricks
    out = state.copy()
    for i in range(2**n):
        if ((i >> target) & 1) == 0:
            j = i | (1 << target)
            a0 = state[i]
            a1 = state[j]
            out[i] = U[0,0]*a0 + U[0,1]*a1
            out[j] = U[1,0]*a0 + U[1,1]*a1
    return out

def _apply_cnot(state: np.ndarray, n: int, control: int, target: int) -> np.ndarray:
    out = state.copy()
    for i in range(2**n):
        if ((i >> control) & 1) == 1 and ((i >> target) & 1) == 0:
            j = i | (1 << target)
            out[i], out[j] = out[j], out[i]
    return out

def run(n_qubits: int, gates: list[Gate]) -> tuple[np.ndarray, dict[str, float], dict]:
    if n_qubits < 1 or n_qubits > 8:
        raise ValueError("qubits must be between 1 and 8")
    state = np.zeros((2**n_qubits,), dtype=np.complex128)
    state[0] = 1.0 + 0j

    depth = 0
    for g in gates:
        depth += 1
        if g.gate == "H":
            state = _apply_single(state, n_qubits, g.target, H)
        elif g.gate == "X":
            state = _apply_single(state, n_qubits, g.target, X)
        elif g.gate == "Z":
            state = _apply_single(state, n_qubits, g.target, Z)
        elif g.gate == "CNOT":
            if g.control is None:
                raise ValueError("CNOT requires control")
            state = _apply_cnot(state, n_qubits, g.control, g.target)
        else:
            raise ValueError(f"unsupported gate: {g.gate}")

    probs = {}
    for i, amp in enumerate(state):
        p = float((amp.real**2 + amp.imag**2))
        if p > 1e-12:
            probs[format(i, f"0{n_qubits}b")] = p
    metrics = {"depth": depth, "gateCount": len(gates)}
    return state, probs, metrics
