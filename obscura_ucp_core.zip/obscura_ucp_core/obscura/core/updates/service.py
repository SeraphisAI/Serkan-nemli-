from __future__ import annotations
import base64
import hashlib
import hmac
from pathlib import Path
from dataclasses import dataclass
import json

@dataclass
class AvailableUpdate:
    name: str
    version: str
    digest: str
    notes: str

def check(channel_file: Path) -> dict:
    data = json.loads(channel_file.read_text(encoding="utf-8"))
    return data

def apply(*, name: str, version: str, payload_b64: str, hmac_b64: str, secret: bytes, plugins_dir: Path) -> dict:
    # Verify HMAC over payload_b64 bytes (string)
    calc = hmac.new(secret, payload_b64.encode("utf-8"), hashlib.sha256).digest()
    if not hmac.compare_digest(calc, base64.b64decode(hmac_b64)):
        return {"applied": False, "rollbackRef": "", "message": "invalid_hmac"}

    plugins_dir.mkdir(parents=True, exist_ok=True)
    rollback_dir = plugins_dir / ".rollback"
    rollback_dir.mkdir(parents=True, exist_ok=True)

    target = plugins_dir / f"{name}.pack"
    rollback_ref = ""
    if target.exists():
        prior = target.read_bytes()
        rollback_ref = hashlib.sha256(prior).hexdigest()[:12]
        (rollback_dir / f"{name}.{rollback_ref}.pack").write_bytes(prior)

    payload = base64.b64decode(payload_b64)
    target.write_bytes(payload)
    return {"applied": True, "rollbackRef": rollback_ref or "none", "message": f"applied {name}@{version}"}
