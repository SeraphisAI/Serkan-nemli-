from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Any
from obscura.core.timeutil import now_iso

@dataclass
class TelemetryEvent:
    type: str
    ts: str
    data: dict[str, Any]

    @staticmethod
    def make(type: str, data: dict[str, Any]) -> "TelemetryEvent":
        return TelemetryEvent(type=type, ts=now_iso(), data=data)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)
