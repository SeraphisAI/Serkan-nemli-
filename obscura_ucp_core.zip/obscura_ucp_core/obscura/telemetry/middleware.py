from __future__ import annotations
import random
import time
from fastapi import Request
from starlette.middleware.base import BaseHTTPMiddleware
from obscura.telemetry.events import TelemetryEvent

class TelemetryMiddleware(BaseHTTPMiddleware):
    def __init__(self, app, *, enabled: bool, sample_rate: float, sink):
        super().__init__(app)
        self.enabled = enabled
        self.sample_rate = sample_rate
        self.sink = sink

    async def dispatch(self, request: Request, call_next):
        start = time.perf_counter()
        response = await call_next(request)
        dur_ms = (time.perf_counter() - start) * 1000

        if self.enabled and random.random() <= self.sample_rate:
            ev = TelemetryEvent.make("request", {
                "path": request.url.path,
                "method": request.method,
                "status": response.status_code,
                "latency_ms": round(dur_ms, 3),
            })
            self.sink.emit(ev)
        return response
