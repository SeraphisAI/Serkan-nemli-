from __future__ import annotations
import json
import os
from pathlib import Path
from obscura.telemetry.events import TelemetryEvent

class FileSink:
    def __init__(self, path: Path):
        self.path = path
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def emit(self, ev: TelemetryEvent) -> None:
        with self.path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(ev.to_dict(), ensure_ascii=False) + "\n")
