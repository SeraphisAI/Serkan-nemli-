from __future__ import annotations
from pathlib import Path
import yaml

def load_yaml(path: Path) -> dict:
    return yaml.safe_load(path.read_text(encoding="utf-8"))

def load_policies(policy_dir: Path) -> dict:
    access = load_yaml(policy_dir / "access.yaml")
    masking = load_yaml(policy_dir / "masking.yaml")
    retention = load_yaml(policy_dir / "retention.yaml")
    return {"access": access, "masking": masking, "retention": retention}
