from __future__ import annotations
from dataclasses import dataclass
from typing import Any

@dataclass
class Decision:
    decision: str  # allow|deny
    reasons: list[str]
    obligations: list[str]

def evaluate_access(policies: dict, subject_roles: list[str], action: str, resource: str) -> Decision:
    access = policies["access"]
    default = access.get("default", "deny")
    reasons: list[str] = []
    obligations: list[str] = []
    role_defs = access.get("roles", {})

    # Admin wildcard
    for role in subject_roles:
        role_def = role_defs.get(role, {})
        for rule in role_def.get("allow", []):
            if (rule.get("action") == "*" or rule.get("action") == action) and                (rule.get("resource") == "*" or rule.get("resource") == resource):
                obligations = list(access.get("obligations", {}).keys())
                return Decision("allow", ["matched_allow_rule"], obligations)

    reasons.append("no_matching_allow_rule")
    return Decision(default, reasons, obligations)
