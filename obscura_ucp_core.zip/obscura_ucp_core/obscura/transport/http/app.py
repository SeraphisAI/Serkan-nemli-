from __future__ import annotations
from fastapi import FastAPI, Depends, Request, Header, HTTPException
from fastapi.responses import JSONResponse
from pathlib import Path
import uuid

from obscura.core.config import load_settings
from obscura.core.timeutil import now_iso
from obscura.telemetry.sink import FileSink
from obscura.telemetry.middleware import TelemetryMiddleware
from obscura.policy.loader import load_policies
from obscura.policy.evaluator import evaluate_access
from obscura.privacy.masking import Masker
from obscura.security.auth import decode_bearer, require_api_key, issue_token
from obscura.security.rate_limit import InMemoryRateLimiter

from obscura.core import models
from obscura.core.guidance.service import guide
from obscura.core.chat.transparency import HyperTransparentAI, new_response_id
from obscura.core.quantum.sim import Gate, run as run_quantum
from obscura.core.crypto.provider import AESGCMProvider, PQCHybridStubProvider
from obscura.core.updates.service import check as check_updates, apply as apply_update
from obscura.core.self_improve.service import recommend as recommend_improve

from obscura.core.db import connect, query

settings = load_settings()
policy_dir = Path("policy/policies")
policies = load_policies(policy_dir)
masker = Masker(policies["masking"]["fields"])
rate_limiter = InMemoryRateLimiter(capacity=30, refill_per_sec=1.0)

app = FastAPI(title=settings.app_name, version=settings.app_version)

# Telemetry
sink = FileSink(settings.telemetry_file)
app.add_middleware(TelemetryMiddleware, enabled=settings.telemetry_enabled, sample_rate=settings.telemetry_sample_rate, sink=sink)

# AI core
ai = HyperTransparentAI(model_name=settings.app_name, version=settings.app_version, transparency_level="high")

def _subject(authorization: str | None = Header(default=None), x_api_key: str | None = Header(default=None, alias="X-API-Key")):
    # Rate limit by client ip via header (naive); in prod use request.client.host
    # Here we allow keying on api-key presence too.
    key = (x_api_key or "anon")
    rate_limiter.hit(key)

    # If api key provided, validate; if not, allow bearer/anonymous
    if x_api_key is not None:
        require_api_key(x_api_key, settings.api_key)

    subj = decode_bearer(authorization, secret=settings.jwt_secret, issuer=settings.jwt_issuer, audience=settings.jwt_audience)
    return subj

def _enforce(subj, action: str, resource: str):
    dec = evaluate_access(policies, subj.roles, action, resource)
    if dec.decision != "allow":
        raise HTTPException(status_code=403, detail={"error":"policy_denied","reasons": dec.reasons})
    return dec

@app.get("/health", tags=["Health"])
def health():
    return {"ok": True, "name": settings.app_name, "version": settings.app_version, "time": now_iso()}

@app.post("/auth/token", tags=["Security"])
def auth_token(username: str, roles: str = "user"):
    # Dev helper: issue a JWT. In production, plug real IdP/OAuth2.
    token = issue_token(
        sub=username,
        roles=[r.strip() for r in roles.split(",") if r.strip()],
        secret=settings.jwt_secret,
        issuer=settings.jwt_issuer,
        audience=settings.jwt_audience,
        ttl_seconds=settings.jwt_ttl_seconds,
    )
    return {"token": token}

@app.post("/assistant/guide", response_model=models.GuideResponse, tags=["Guidance"])
def assistant_guide(req: models.GuideRequest, subj=Depends(_subject)):
    _enforce(subj, "write", "/assistant/guide")
    out = guide(req.targetGoal, req.experienceLevel, req.context)
    return out

@app.post("/chat", response_model=models.ChatResponse, tags=["Chat"])
def chat(req: models.ChatRequest, subj=Depends(_subject)):
    _enforce(subj, "write", "/chat")
    rid = new_response_id()
    msg, rep = ai.respond(req.message)
    return {"responseId": rid, "message": msg, "transparency": rep.__dict__}

@app.post("/quantum/compute", response_model=models.QuantumComputeResponse, tags=["Quantum"])
def quantum_compute(req: models.QuantumComputeRequest, subj=Depends(_subject)):
    _enforce(subj, "write", "/quantum/compute")
    gates = [Gate(gate=g.gate, target=g.target, control=g.control) for g in req.gates]
    state, probs, metrics = run_quantum(req.qubits, gates)
    sv = None
    if req.returnStatevector:
        sv = [str(complex(x)) for x in state.tolist()]
    return {"probs": probs, "statevector": sv, "metrics": metrics}

@app.post("/quantum/security/encrypt", response_model=models.EncryptResponse, tags=["Security"])
def encrypt(req: models.EncryptRequest, subj=Depends(_subject)):
    _enforce(subj, "write", "/quantum/security/encrypt")
    provider = AESGCMProvider(settings.crypto_master_key) if req.algorithm == "AESGCM" else PQCHybridStubProvider(settings.crypto_master_key)
    out = provider.encrypt(req.plaintext, req.aad)
    return out.__dict__

@app.post("/quantum/security/decrypt", response_model=models.DecryptResponse, tags=["Security"])
def decrypt(req: models.DecryptRequest, subj=Depends(_subject)):
    _enforce(subj, "write", "/quantum/security/decrypt")
    provider = AESGCMProvider(settings.crypto_master_key) if req.algorithm == "AESGCM" else PQCHybridStubProvider(settings.crypto_master_key)
    out = provider.decrypt(req.ciphertext_b64, req.nonce_b64, req.aad, req.encapsulated_key_b64)
    return out.__dict__

@app.post("/update/check", tags=["Updates"])
def update_check(subj=Depends(_subject)):
    _enforce(subj, "write", "/update/check")
    data = check_updates(settings.updates_channel_file)
    return data

@app.post("/update/apply", tags=["Updates"])
def update_apply(req: dict, subj=Depends(_subject)):
    _enforce(subj, "write", "/update/apply")
    plugins_dir = settings.data_dir / "plugins"
    out = apply_update(
        name=req["name"],
        version=req["version"],
        payload_b64=req["payload_b64"],
        hmac_b64=req["hmac_b64"],
        secret=settings.updates_hmac_secret,
        plugins_dir=plugins_dir,
    )
    return out

@app.post("/self-improve", tags=["Updates"])
def self_improve(subj=Depends(_subject)):
    _enforce(subj, "write", "/self-improve")
    out = recommend_improve(settings.telemetry_file)
    return out

@app.post("/policy/evaluate", response_model=models.PolicyEvalResponse, tags=["Policy"])
def policy_evaluate(req: models.PolicyEvalRequest, subj=Depends(_subject)):
    # You can evaluate arbitrary resources for debugging
    roles = list(req.subject.get("roles") or subj.roles)
    action = req.action
    resource = req.resource.get("path") or ""
    dec = evaluate_access(policies, roles, action, resource)
    # audit to sqlite
    from obscura.migrations.runner import db_path
    conn = connect(db_path(settings.data_dir))
    conn.execute(
        "INSERT INTO audit_log (ts, subject, action, resource, decision, reasons) VALUES (?,?,?,?,?,?)",
        (now_iso(), str(req.subject), action, resource, dec.decision, ",".join(dec.reasons)),
    )
    conn.commit()
    return {"decision": dec.decision, "reasons": dec.reasons, "obligations": dec.obligations}

@app.post("/telemetry/event", tags=["Telemetry"], status_code=202)
def telemetry_ingest(ev: models.TelemetryEventIn, subj=Depends(_subject)):
    _enforce(subj, "write", "/telemetry/event")
    # Respect masking obligations
    data = masker.mask_obj(ev.data)
    from obscura.telemetry.events import TelemetryEvent
    sink.emit(TelemetryEvent(type=ev.type, ts=ev.ts, data=data))
    return {"accepted": True}

@app.get("/documentation/user-guides", tags=["Compliance"])
def user_guides():
    return {"guides": ["Quantum Computing Guide", "AGI/Agent Integration Guide", "Policy Pack Guide"]}

@app.post("/compliance/run-tests", tags=["Compliance"])
def compliance_run_tests():
    # Stub: return the idea of checks
    return {"status": "ok", "results": [{"name":"policy-pack","pass":True},{"name":"migrations","pass":True}]}

# --- DB demo endpoints (users/orders) ---
@app.get("/user", tags=["Security"])
def list_users(subj=Depends(_subject)):
    _enforce(subj, "read", "/user")
    from obscura.migrations.runner import db_path
    conn = connect(db_path(settings.data_dir))
    rows = query(conn, "SELECT id, username, email, created_at FROM users ORDER BY id DESC")
    return {"users": [dict(r) for r in rows]}

@app.post("/user", tags=["Security"], status_code=201)
def create_user(req: models.UserCreate, subj=Depends(_subject)):
    _enforce(subj, "write", "/user")
    from obscura.migrations.runner import db_path
    conn = connect(db_path(settings.data_dir))
    conn.execute("INSERT INTO users (username, email, created_at) VALUES (?,?,?)", (req.username, req.email, now_iso()))
    conn.commit()
    uid = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
    row = conn.execute("SELECT id, username, email, created_at FROM users WHERE id=?", (uid,)).fetchone()
    return dict(row)

@app.post("/order", tags=["Security"], status_code=201)
def create_order(req: models.OrderCreate, subj=Depends(_subject)):
    _enforce(subj, "write", "/order")
    from obscura.migrations.runner import db_path
    conn = connect(db_path(settings.data_dir))
    conn.execute("INSERT INTO orders (user_id, item, amount, created_at) VALUES (?,?,?,?)", (req.userId, req.item, req.amount, now_iso()))
    conn.commit()
    oid = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
    row = conn.execute("SELECT id, user_id as userId, item, amount, created_at as createdAt FROM orders WHERE id=?", (oid,)).fetchone()
    return dict(row)

# Generic stubs for the long tail of endpoints present in drafts:
@app.api_route("/{path:path}", methods=["GET","POST","PUT","PATCH","DELETE"])
def not_implemented(path: str):
    # Let known routes above handle; remaining fall here.
    return JSONResponse(status_code=501, content={"error": "not_implemented", "path": "/" + path})
