from __future__ import annotations
import time
from dataclasses import dataclass
from fastapi import HTTPException

@dataclass
class Bucket:
    capacity: float
    tokens: float
    refill_per_sec: float
    last: float

class InMemoryRateLimiter:
    def __init__(self, *, capacity: int = 30, refill_per_sec: float = 1.0):
        self.capacity = float(capacity)
        self.refill_per_sec = float(refill_per_sec)
        self.buckets: dict[str, Bucket] = {}

    def hit(self, key: str, cost: float = 1.0) -> None:
        now = time.time()
        b = self.buckets.get(key)
        if not b:
            b = Bucket(self.capacity, self.capacity, self.refill_per_sec, now)
            self.buckets[key] = b
        # refill
        elapsed = now - b.last
        b.tokens = min(b.capacity, b.tokens + elapsed * b.refill_per_sec)
        b.last = now
        if b.tokens < cost:
            raise HTTPException(status_code=429, detail="rate_limited")
        b.tokens -= cost
