from __future__ import annotations
import jwt
from dataclasses import dataclass
from fastapi import Header, HTTPException
from obscura.core.timeutil import now_iso
from datetime import datetime, timezone, timedelta

@dataclass
class Subject:
    user_id: str | None
    roles: list[str]

def require_api_key(x_api_key: str | None, expected: str) -> None:
    if x_api_key != expected:
        raise HTTPException(status_code=401, detail="invalid_api_key")

def decode_bearer(auth: str | None, *, secret: str, issuer: str, audience: str) -> Subject:
    if not auth:
        return Subject(user_id=None, roles=["user"])  # anonymous-as-user (policy still applies)
    if not auth.lower().startswith("bearer "):
        raise HTTPException(status_code=401, detail="invalid_auth_header")
    token = auth.split(" ", 1)[1].strip()
    try:
        payload = jwt.decode(token, secret, algorithms=["HS256"], issuer=issuer, audience=audience)
    except Exception:
        raise HTTPException(status_code=401, detail="invalid_token")
    roles = payload.get("roles") or ["user"]
    return Subject(user_id=payload.get("sub"), roles=list(roles))

def issue_token(*, sub: str, roles: list[str], secret: str, issuer: str, audience: str, ttl_seconds: int) -> str:
    now = datetime.now(timezone.utc)
    exp = now + timedelta(seconds=ttl_seconds)
    payload = {
        "iss": issuer,
        "aud": audience,
        "sub": sub,
        "roles": roles,
        "iat": int(now.timestamp()),
        "exp": int(exp.timestamp()),
    }
    return jwt.encode(payload, secret, algorithm="HS256")
