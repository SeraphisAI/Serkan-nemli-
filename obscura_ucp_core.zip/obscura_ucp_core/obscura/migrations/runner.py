from __future__ import annotations
from pathlib import Path
from obscura.core.db import connect, exec_script
from obscura.core.config import load_settings

def db_path(data_dir: Path) -> Path:
    return data_dir / "db/obscura.sqlite"

def main() -> None:
    settings = load_settings()
    conn = connect(db_path(settings.data_dir))
    sql = (Path("migrations") / "001_init.sql").read_text(encoding="utf-8")
    exec_script(conn, sql)
    print("migrations applied")

if __name__ == "__main__":
    main()
