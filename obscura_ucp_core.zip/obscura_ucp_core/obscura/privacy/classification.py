from __future__ import annotations
from enum import Enum

class DataClass(str, Enum):
    public = "public"
    internal = "internal"
    confidential = "confidential"
    restricted = "restricted"
