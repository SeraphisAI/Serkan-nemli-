from __future__ import annotations
import re
from typing import Any

class Masker:
    def __init__(self, rules: list[dict]):
        self._compiled = []
        for r in rules:
            self._compiled.append((re.compile(r["pattern"]), r.get("mask", "****")))

    def mask_obj(self, obj: Any) -> Any:
        if isinstance(obj, dict):
            out = {}
            for k, v in obj.items():
                out[k] = self._mask_key_value(k, v)
            return out
        if isinstance(obj, list):
            return [self.mask_obj(x) for x in obj]
        return obj

    def _mask_key_value(self, key: str, value: Any) -> Any:
        for rx, mask in self._compiled:
            if rx.search(key):
                return mask
        return self.mask_obj(value) if isinstance(value, (dict, list)) else value
