\
<# 20_run_api_local.ps1 - FastAPI'yi lokal başlatır #>
$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
Set-Location $root

. "$root\.venv\Scripts\Activate.ps1"

$env:KATOPU_REQUIRE_API_KEY = "0"
$env:KATOPU_API_PORT = $env:KATOPU_API_PORT -as [string]
if (-not $env:KATOPU_API_PORT) { $env:KATOPU_API_PORT = "8000" }

Write-Host "==> API başlatılıyor: http://localhost:$env:KATOPU_API_PORT/health"
python -m uvicorn api.app.main:app --host 0.0.0.0 --port $env:KATOPU_API_PORT
