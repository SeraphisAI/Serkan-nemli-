\
<# 40_doctor.ps1 - repo doktor + pytest #>
$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
Set-Location $root

Write-Host "==> Katopu doctor"
./katopu_doctor.ps1

if (Test-Path ".venv") {
  . "$root\.venv\Scripts\Activate.ps1"
  Write-Host "==> pytest"
  pytest -q
} else {
  Write-Host "==> .venv yok; pytest atlandı (Docker akışı kullanıyorsanız normal)." -ForegroundColor Yellow
}

Write-Host "==> Tamam."
