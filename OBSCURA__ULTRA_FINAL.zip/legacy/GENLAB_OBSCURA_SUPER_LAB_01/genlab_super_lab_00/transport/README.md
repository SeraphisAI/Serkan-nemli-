Transport adapters live here (future): gRPC, WebSocket, MQTT, etc.
HTTP is implemented in api/app/main.py.
