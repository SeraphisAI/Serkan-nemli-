docker ps --format "table {{.Names}}\t{{.Status}}\t{{.Ports}}"
