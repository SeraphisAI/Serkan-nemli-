from katopu_ui.seq import normalize_sequence, validate_iupac, format_chunked, parse_fasta, to_fasta

def test_normalize_sequence_removes_whitespace_and_upper():
    assert normalize_sequence("a t g \n c") == "ATGC"

def test_validate_iupac_reports_position():
    r = validate_iupac("ATGZC", kind="dna", strict=True)
    assert not r.ok
    assert r.invalid_positions[0][0] == 4
    assert r.invalid_positions[0][1] == "Z"

def test_chunk_format_has_positions():
    s = "A"*61
    out = format_chunked(s, width=60, with_pos=True)
    lines = out.splitlines()
    assert lines[0].startswith("      1")
    assert lines[1].startswith("     61")

def test_parse_fasta_and_roundtrip():
    text = """>geneA
ATGC
>geneB
TTAA
"""
    recs = parse_fasta(text)
    assert len(recs) == 2
    assert recs[0]["name"] == "geneA"
    fasta = to_fasta([(r["name"], r["sequence"]) for r in recs])
    assert ">geneA" in fasta and ">geneB" in fasta
