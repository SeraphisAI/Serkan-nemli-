from katopu_ui.ui_contract import GLOBAL_CSS, topbar_html, APP_VERSION

def test_css_contains_required_classes():
    for cls in ["k-topbar", "k-card", "kdiff-inline", "kdiff-sbs", "k-nowrap"]:
        assert cls in GLOBAL_CSS

def test_topbar_has_testids():
    html = topbar_html("Katopu", "local/dev", "Gene-1")
    assert "data-testid=\"katopu-topbar\"" in html
    assert f"v{APP_VERSION}" in html
