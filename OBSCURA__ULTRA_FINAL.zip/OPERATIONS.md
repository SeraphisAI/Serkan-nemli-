# OPERATIONS — Kurulumda Hata İstemiyoruz

Bu dosya "sıfır sürpriz" için hızlı kontrol listesidir.

## 1) Preflight
- Linux/macOS: `make preflight`
- Windows: `powershell -ExecutionPolicy Bypass -File .\katopu_doctor.ps1`

## 2) Çalıştırma
- `make dev`
- UI: http://localhost:8501
- API: http://localhost:8000/health

## 3) Test
- `make test`

## 4) Sorun Giderme
- Loglar: `make logs`
- Port çakışması varsa 8000/8501'i boşaltın veya compose portlarını değiştirin.
