<# 
KATOPU Doctor - Diagnostics (Windows PowerShell)
Reports: docker/compose presence, ports, containers, health, and recent logs if compose file is present.
#>
[CmdletBinding()]
param(
  [string]$InstallRoot = "C:\katopu_genlab_ultra_final",
  [int[]]$Ports = @(8501,8000)
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Continue"

function Write-Head($t){ Write-Host "`n=== $t ===" -ForegroundColor Cyan }
function Try($name, [scriptblock]$fn){
  try { & $fn } catch { Write-Host ("[ERR] $name: " + $_.Exception.Message) -ForegroundColor Yellow }
}

Write-Head "System"
Try "PSVersion" { $PSVersionTable | Format-List | Out-String | Write-Host }
Try "OS" { (Get-CimInstance Win32_OperatingSystem | Select Caption,Version,BuildNumber) | Format-Table | Out-String | Write-Host }

Write-Head "Docker"
Try "docker version" { docker version }
Try "docker compose version" { docker compose version }
Try "docker-compose version" { docker-compose version }

Write-Head "Ports"
foreach ($p in $Ports) {
  Write-Host ("-- Port $p --")
  Try "netstat" { netstat -ano | Select-String (":$p\s") | Select-Object -First 20 | ForEach-Object { $_.ToString() } }
}

Write-Head "Containers (katopu-ish)"
Try "docker ps" { docker ps --format "table {{.Names}}\t{{.Image}}\t{{.Status}}\t{{.Ports}}" | Select-String -Pattern "katopu|8501|8000" -CaseSensitive:$false }

Write-Head "Health checks"
Try "API /health" { Invoke-RestMethod -Uri "http://localhost:8000/health" -TimeoutSec 3 | ConvertTo-Json -Depth 6 | Write-Host }
Try "UI root" { (Invoke-WebRequest -Uri "http://localhost:8501" -TimeoutSec 3).StatusCode | Write-Host }

Write-Head "Compose logs (if available)"
$composeFile = $null
$candidates = @(
  (Join-Path $InstallRoot "infra\docker-compose.yml"),
  (Join-Path $InstallRoot "docker-compose.yml"),
  (Join-Path $InstallRoot "compose.yml")
)
foreach ($c in $candidates) { if (Test-Path $c) { $composeFile = $c; break } }
if ($composeFile) {
  Try "docker compose logs" { docker compose -f $composeFile logs --tail 200 }
} else {
  Write-Host "compose file bulunamadi: $InstallRoot (infra\docker-compose.yml beklenir)" -ForegroundColor Yellow
}

Write-Head "Done"
