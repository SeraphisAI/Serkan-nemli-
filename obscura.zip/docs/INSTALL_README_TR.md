# KATOPU Kurulum (Windows)

Bu paket, **sıfırdan kurulum / upgrade / eski çalışanı kaldırma** işlerini tek PowerShell script ile yapar.

## Gereksinimler
- Windows 10/11
- Docker Desktop (docker + docker compose)
- PowerShell 5.1+ (Windows PowerShell)

## Tek Komut Kurulum (önerilen)

```powershell
powershell -ExecutionPolicy Bypass -File .\katopu_install.ps1 -RemoveOld -FreshData -RequireApiKey
```

Script ZIP’i otomatik arar (Downloads/Desktop/C:\Temp/current).

ZIP yolu vermek istersen:

```powershell
powershell -ExecutionPolicy Bypass -File .\katopu_install.ps1 `
  -PackageZip "C:\Temp\FINAL_DELIVERY_v0.3.1.zip" `
  -InstallRoot "C:\katopu_genlab_ultra_final" `
  -RemoveOld -FreshData -RequireApiKey
```

## Tanı / Arıza Analizi
```powershell
powershell -ExecutionPolicy Bypass -File .\katopu_doctor.ps1 -InstallRoot "C:\katopu_genlab_ultra_final"
```

## URL'ler
- UI: http://localhost:8501
- API health: http://localhost:8000/health
