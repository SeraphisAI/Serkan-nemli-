# OBSCURA × Katopu GenLab — SUPER LAB (00)

Bu paket, aşağıdaki üç teslimatın **hatasız + deterministik** birleşimidir:

- FINAL_DELIVERY_PATCHED_v4.zip (omurga / baseline)
- FINAL_DELIVERY_OBSCURA_ULTRA_v2.zip
- OBSCURA_TOTAL_FINAL_v1.zip

## Çalıştırma Seçenekleri

### Seçenek A — Docker ile (önerilen, en az bağımlılık)
1. `infra/.env.example` dosyasını `infra/.env` olarak kopyalayın ve gerekirse portları ayarlayın.
2. PowerShell 7 ile repo kökünde:
   - `./lab/30_run_docker.ps1`

UI: http://localhost:8501  
API: http://localhost:8000/health

### Seçenek B — Lokal (venv + pip)
1. `./lab/00_prereqs_windows.ps1` (Python/Git yoksa kurar)
2. `./lab/10_venv_install.ps1` (venv + requirements)
3. API:
   - `./lab/20_run_api_local.ps1`
4. UI:
   - ayrı bir terminalde `./lab/21_run_ui_local.ps1`

## Hızlı Doğrulama
- `./lab/40_doctor.ps1`
- `pytest -q`
