import json
from pathlib import Path
from katopu_ui.store import GeneStore

def test_gene_store_roundtrip(tmp_path: Path):
    path = tmp_path / "genes.json"
    store = GeneStore(path)
    g = store.new_gene("G1", "ATGC")
    store.save([g])
    loaded = store.load()
    assert len(loaded) == 1
    assert loaded[0].name == "G1"
    assert loaded[0].sequence == "ATGC"
