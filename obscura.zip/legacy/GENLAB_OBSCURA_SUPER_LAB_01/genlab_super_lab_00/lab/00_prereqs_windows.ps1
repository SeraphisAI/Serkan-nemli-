\
<# 
00_prereqs_windows.ps1
- Python + Git yoksa winget ile kurar (kaynak/paket anlaşmalarını otomatik kabul eder)
- Not: Docker opsiyoneldir; Docker Desktop kurulu değilse Docker akışı çalışmaz.
#>
$ErrorActionPreference = "Stop"

function Has-Cmd($name) {
  return [bool](Get-Command $name -ErrorAction SilentlyContinue)
}

Write-Host "==> Prereqs kontrol ediliyor..."

if (-not (Has-Cmd "winget")) {
  Write-Host "winget bulunamadı. Windows App Installer gerekli." -ForegroundColor Yellow
  Write-Host "Microsoft Store -> 'App Installer' kurun, sonra tekrar deneyin."
  exit 1
}

$commonArgs = @("--accept-source-agreements","--accept-package-agreements","-e")

if (-not (Has-Cmd "python") -and -not (Has-Cmd "py")) {
  Write-Host "Python bulunamadı -> winget ile Python 3.10 kuruluyor..."
  winget install --id Python.Python.3.10 @commonArgs
} else {
  Write-Host "Python mevcut."
}

if (-not (Has-Cmd "git")) {
  Write-Host "Git bulunamadı -> winget ile Git kuruluyor..."
  winget install --id Git.Git @commonArgs
} else {
  Write-Host "Git mevcut."
}

Write-Host "==> Tamam."
