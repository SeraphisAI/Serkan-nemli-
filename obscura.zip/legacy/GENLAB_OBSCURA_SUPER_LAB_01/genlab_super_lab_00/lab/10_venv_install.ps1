\
<# 10_venv_install.ps1 - venv oluşturur ve bağımlılıkları yükler #>
$ErrorActionPreference = "Stop"

$root = Split-Path -Parent $PSScriptRoot
Set-Location $root

if (Test-Path ".venv") {
  Write-Host "==> .venv zaten var (reuse)."
} else {
  Write-Host "==> venv oluşturuluyor..."
  python -m venv .venv
}

Write-Host "==> venv aktive ediliyor..."
. "$root\.venv\Scripts\Activate.ps1"

Write-Host "==> pip güncelleniyor..."
python -m pip install --upgrade pip

Write-Host "==> requirements yükleniyor..."
python -m pip install -r api/requirements.txt
python -m pip install -r ui/requirements.txt
python -m pip install -r requirements-dev.txt

Write-Host "==> Proje editable kuruluyor (pip install -e .)..."
pip install -e .
Write-Host "==> Tamam."
