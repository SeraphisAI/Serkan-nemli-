from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Dict, Iterable, List, Optional, Tuple

# IUPAC sets
IUPAC_DNA = set("ACGTNRYKMSWBDHV")
IUPAC_RNA = set("ACGUNRYKMSWBDHV")  # U instead of T
STRICT_DNA = set("ACGT")
STRICT_RNA = set("ACGU")

_WS_RE = re.compile(r"\s+")

@dataclass(frozen=True)
class SeqValidationResult:
    ok: bool
    seq: str
    kind: str  # "dna" | "rna"
    length: int
    gc_percent: float
    invalid_positions: List[Tuple[int, str]]  # 1-based position, char
    warnings: List[str]

def detect_kind(seq: str) -> str:
    s = (seq or "").upper()
    if "U" in s and "T" not in s:
        return "rna"
    return "dna"

def normalize_sequence(raw: str) -> str:
    # Remove whitespace/newlines, uppercase.
    s = (raw or "")
    s = _WS_RE.sub("", s)
    return s.upper()

def gc_percent(seq: str) -> float:
    s = seq or ""
    if not s:
        return 0.0
    gc = sum(1 for ch in s if ch in ("G", "C"))
    return (gc * 100.0) / float(len(s))

def validate_iupac(
    raw: str,
    *,
    kind: Optional[str] = None,
    strict: bool = False,
) -> SeqValidationResult:
    seq = normalize_sequence(raw)
    k = (kind or detect_kind(seq)).lower().strip()
    allowed = (STRICT_DNA if strict else IUPAC_DNA) if k == "dna" else (STRICT_RNA if strict else IUPAC_RNA)

    invalid: List[Tuple[int, str]] = []
    for i, ch in enumerate(seq):
        if ch not in allowed:
            invalid.append((i + 1, ch))
            if len(invalid) >= 25:
                break

    warns: List[str] = []
    if seq and not invalid:
        if k == "dna" and "U" in seq:
            warns.append("DNA dizisinde 'U' bulundu (RNA mı?).")
        if k == "rna" and "T" in seq:
            warns.append("RNA dizisinde 'T' bulundu (DNA mı?).")
        if any(ch in ("N",) for ch in seq):
            warns.append("Dizide belirsiz bazlar (N) var.")
        if not strict and any(ch in set("RYSWKMBDHV") for ch in seq):
            warns.append("IUPAC genişletilmiş karakterler var (strict modda reddedilir).")

    return SeqValidationResult(
        ok=bool(seq) and len(invalid) == 0,
        seq=seq,
        kind=k,
        length=len(seq),
        gc_percent=gc_percent(seq),
        invalid_positions=invalid,
        warnings=warns,
    )

def format_chunked(seq: str, *, width: int = 60, with_pos: bool = True) -> str:
    s = seq or ""
    if not s:
        return ""
    lines = []
    for i in range(0, len(s), width):
        chunk = s[i : i + width]
        if with_pos:
            # 1-based position label, right-aligned to 7 chars.
            lines.append(f"{i+1:>7}  {chunk}")
        else:
            lines.append(chunk)
    return "\n".join(lines)

_FASTA_HDR_RE = re.compile(r"^>\s*(.*)$")

def parse_fasta(text: str) -> List[Dict[str, str]]:
    """
    Parse FASTA (very small, permissive).
    Returns list of {name, sequence}.
    If no headers exist, returns single record using 'Imported 1'.
    """
    raw = (text or "").strip()
    if not raw:
        return []
    lines = raw.splitlines()
    has_hdr = any(_FASTA_HDR_RE.match(ln.strip()) for ln in lines)
    if not has_hdr:
        seq = normalize_sequence(raw)
        return [{"name": "Imported 1", "sequence": seq}]

    records: List[Dict[str, str]] = []
    name = None
    buf: List[str] = []
    for ln in lines:
        ln = ln.strip()
        if not ln:
            continue
        m = _FASTA_HDR_RE.match(ln)
        if m:
            if name is not None:
                records.append({"name": name or f"Imported {len(records)+1}", "sequence": normalize_sequence("".join(buf))})
            name = (m.group(1) or "").strip() or f"Imported {len(records)+1}"
            buf = []
        else:
            buf.append(ln)
    if name is not None:
        records.append({"name": name or f"Imported {len(records)+1}", "sequence": normalize_sequence("".join(buf))})
    return records

def to_fasta(records: Iterable[Tuple[str, str]]) -> str:
    out = []
    for name, seq in records:
        name = (name or "Untitled").strip()
        out.append(f">{name}")
        s = normalize_sequence(seq)
        # wrap at 60
        for i in range(0, len(s), 60):
            out.append(s[i:i+60])
    return "\n".join(out) + ("\n" if out else "")
