# Katopu GenLab Ultra - Verify (smoke check)
$ErrorActionPreference = 'Stop'

function Section([string]$t) { Write-Host "`n=== $t ===" -ForegroundColor Cyan }
function Ok([string]$t) { Write-Host "OK  : $t" -ForegroundColor Green }
function Warn([string]$t) { Write-Host "WARN: $t" -ForegroundColor Yellow }

try { chcp 65001 | Out-Null } catch {}
try { $global:OutputEncoding = [Console]::OutputEncoding = [Text.UTF8Encoding]::new() } catch {}

$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$infra = Join-Path $root 'infra'

Section 'docker compose ps'
try {
  Push-Location $infra
  docker compose ps | Out-Host
  Pop-Location
} catch {
  Warn "docker compose ps başarısız: $($_.Exception.Message)"
}

Section 'health'
$r = Invoke-RestMethod -Uri 'http://localhost:8000/health' -TimeoutSec 5
if ($r.ok -ne $true) { throw 'Health başarısız.' }
Ok ('/health ok=true (uptime_s=' + $r.uptime_s + ')')

Section 'policy'
$p = Invoke-RestMethod -Uri 'http://localhost:8000/policy' -TimeoutSec 5
Ok ('policy active: ' + $p.active_path)

Section 'sample run'
$seq = 'ATGACCTTGGCTAACCTGTTACGATGGCCTTAA'
$body = @{ intent='ilk 5 baz sil'; mode='strict' } | ConvertTo-Json
$res = Invoke-RestMethod -Uri "http://localhost:8000/run?sequence=$seq" -Method Post -ContentType 'application/json' -Body $body
if (-not $res.after) { throw 'run response missing after' }
Ok ('after=' + $res.after)

Section 'DONE ✅'
Ok 'UI   : http://localhost:8501'
Ok 'API  : http://localhost:8000'
Ok 'DOCS : http://localhost:8000/docs'
