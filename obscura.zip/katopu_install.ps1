<# 
KATOPU Fresh Install / Upgrade Bootstrap (Windows PowerShell 5.1+)
- Stops existing stack (docker compose) if found
- Optionally wipes data volumes
- Extracts new package ZIP into InstallRoot
- Configures API key secrets (DPAPI-encrypted) and runtime env
- Starts stack and waits for health
Usage examples:
  powershell -ExecutionPolicy Bypass -File .\katopu_install.ps1 -PackageZip "C:\Temp\FINAL_DELIVERY_v0.3.1.zip" -InstallRoot "C:\katopu" -RemoveOld -FreshData -RequireApiKey
  powershell -ExecutionPolicy Bypass -File .\katopu_install.ps1  # auto-find latest ZIP in common folders
#>

[CmdletBinding()]
param(
  [string]$PackageZip = "",
  [string]$InstallRoot = "C:\katopu_genlab_ultra_final",
  [switch]$RemoveOld,
  [switch]$FreshData,
  [switch]$RequireApiKey,
  [string]$ApiKey = "",
  [switch]$WriteDotEnv
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

function Write-Info($msg){ Write-Host ("[INFO] " + $msg) -ForegroundColor Cyan }
function Write-Ok($msg){ Write-Host ("[ OK ] " + $msg) -ForegroundColor Green }
function Write-Warn($msg){ Write-Host ("[WARN] " + $msg) -ForegroundColor Yellow }
function Write-Fail($msg){ Write-Host ("[FAIL] " + $msg) -ForegroundColor Red }

function Test-Command($name){
  return [bool](Get-Command $name -ErrorAction SilentlyContinue)
}

function Get-ComposeCmd {
  if (Test-Command "docker") {
    try { docker compose version *> $null; return "docker compose" } catch {}
  }
  if (Test-Command "docker-compose") { return "docker-compose" }
  throw "Docker Compose bulunamadi. Docker Desktop kurulu olmali (docker + docker compose)."
}

function Find-LatestZip {
  param([string[]]$Roots)
  $patterns = @(
    "FINAL_DELIVERY*.zip",
    "katopu*FINAL*.zip",
    "katopu*.zip"
  )
  foreach ($r in $Roots) {
    if (-not (Test-Path $r)) { continue }
    foreach ($p in $patterns) {
      $cand = Get-ChildItem -Path $r -File -Filter $p -ErrorAction SilentlyContinue |
              Sort-Object LastWriteTime -Descending |
              Select-Object -First 1
      if ($cand) { return $cand.FullName }
    }
  }
  return $null
}

function Safe-Unblock($path){
  try { Unblock-File -Path $path -ErrorAction SilentlyContinue } catch {}
}

function Get-FreeTempDir {
  $tmpRoot = "C:\Temp"
  if (-not (Test-Path $tmpRoot)) { New-Item -ItemType Directory -Path $tmpRoot | Out-Null }
  $d = Join-Path $tmpRoot ("katopu_install_" + [guid]::NewGuid().ToString("N"))
  New-Item -ItemType Directory -Path $d | Out-Null
  return $d
}

function Resolve-ComposeFile {
  param([string]$Root)
  $candidates = @(
    (Join-Path $Root "infra\docker-compose.yml"),
    (Join-Path $Root "docker-compose.yml"),
    (Join-Path $Root "compose.yml")
  )
  foreach ($c in $candidates) { if (Test-Path $c) { return $c } }
  # Search
  $found = Get-ChildItem $Root -Recurse -File -Filter "docker-compose.yml" -ErrorAction SilentlyContinue | Select-Object -First 1
  if ($found) { return $found.FullName }
  return $null
}

function Stop-OldStack {
  param([string]$RootToCheck)
  $compose = Get-ComposeCmd
  $composeFile = Resolve-ComposeFile -Root $RootToCheck
  if (-not $composeFile) { Write-Warn "Eski compose dosyasi bulunamadi ($RootToCheck). Atliyorum."; return }

  Write-Info "Eski stack kapatiliyor: $composeFile"
  if ($FreshData) {
    & $compose.Split(" ")[0] $compose.Split(" ")[1] "-f" $composeFile "down" "--remove-orphans" "--volumes"
  } else {
    & $compose.Split(" ")[0] $compose.Split(" ")[1] "-f" $composeFile "down" "--remove-orphans"
  }
  Write-Ok "Eski stack kapatildi."
}

function Stop-PortProcesses {
  param([int[]]$Ports)
  foreach ($p in $Ports) {
    $conns = netstat -ano | Select-String -Pattern (":$p\s")
    if (-not $conns) { continue }
    $pids = @()
    foreach ($line in $conns) {
      $parts = ($line.ToString() -split "\s+") | Where-Object { $_ -ne "" }
      if ($parts.Length -ge 5) { $pids += [int]$parts[-1] }
    }
    $pids = $pids | Select-Object -Unique
    foreach ($pid in $pids) {
      try {
        $proc = Get-Process -Id $pid -ErrorAction Stop
        $name = $proc.ProcessName.ToLowerInvariant()
        if ($name -match "python|uvicorn|streamlit|node|docker|com.docker") {
          Write-Warn "Port $p kullanan surec kapatiliyor: PID=$pid Name=$($proc.ProcessName)"
          Stop-Process -Id $pid -Force
        } else {
          Write-Warn "Port $p baska bir surec tarafindan kullaniliyor (PID=$pid Name=$($proc.ProcessName)). Dokunmuyorum."
        }
      } catch {}
    }
  }
}

function Ensure-SecretStore {
  param([string]$ApiKeyValue)
  $dir = Join-Path $env:APPDATA "katopu_genlab"
  if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir | Out-Null }
  $file = Join-Path $dir "secrets.json"

  # DPAPI protect/unprotect helpers
  Add-Type -AssemblyName System.Security
  $bytes = [System.Text.Encoding]::UTF8.GetBytes($ApiKeyValue)
  $protected = [System.Security.Cryptography.ProtectedData]::Protect($bytes, $null, [System.Security.Cryptography.DataProtectionScope]::CurrentUser)
  $b64 = [Convert]::ToBase64String($protected)

  $obj = @{
    version = 1
    created_at = (Get-Date).ToString("o")
    secrets = @{
      KATOPU_API_KEY = $b64
    }
  } | ConvertTo-Json -Depth 6

  Set-Content -Path $file -Value $obj -Encoding UTF8

  # Lock down ACL (CurrentUser + SYSTEM)
  try {
    $acl = Get-Acl $file
    $acl.SetAccessRuleProtection($true, $false)
    $me = [System.Security.Principal.NTAccount]("$env:USERDOMAIN\$env:USERNAME")
    $ruleMe = New-Object System.Security.AccessControl.FileSystemAccessRule($me,"FullControl","Allow")
    $acl.SetAccessRule($ruleMe) | Out-Null
    $sys = New-Object System.Security.Principal.NTAccount("NT AUTHORITY\SYSTEM")
    $ruleSys = New-Object System.Security.AccessControl.FileSystemAccessRule($sys,"FullControl","Allow")
    $acl.AddAccessRule($ruleSys) | Out-Null
    Set-Acl -Path $file -AclObject $acl
  } catch {
    Write-Warn "ACL kilidi uygulanamadi: $($_.Exception.Message)"
  }

  Write-Ok "Secret store yazildi (DPAPI encrypted): $file"
  return $file
}

function Read-SecretStoreKey {
  $file = Join-Path (Join-Path $env:APPDATA "katopu_genlab") "secrets.json"
  if (-not (Test-Path $file)) { return $null }
  $json = Get-Content $file -Raw | ConvertFrom-Json
  $b64 = $json.secrets.KATOPU_API_KEY
  if (-not $b64) { return $null }
  Add-Type -AssemblyName System.Security
  $protected = [Convert]::FromBase64String($b64)
  $bytes = [System.Security.Cryptography.ProtectedData]::Unprotect($protected, $null, [System.Security.Cryptography.DataProtectionScope]::CurrentUser)
  return [System.Text.Encoding]::UTF8.GetString($bytes)
}

function Maybe-WriteDotEnvFile {
  param([string]$Root, [hashtable]$EnvMap)
  $envPath = Join-Path $Root ".env"
  $lines = @()
  foreach ($k in $EnvMap.Keys) { $lines += "$k=$($EnvMap[$k])" }
  Set-Content -Path $envPath -Value ($lines -join "`r`n") -Encoding ASCII
  Safe-Unblock $envPath
  try {
    $acl = Get-Acl $envPath
    $acl.SetAccessRuleProtection($true, $false)
    $me = [System.Security.Principal.NTAccount]("$env:USERDOMAIN\$env:USERNAME")
    $ruleMe = New-Object System.Security.AccessControl.FileSystemAccessRule($me,"FullControl","Allow")
    $acl.SetAccessRule($ruleMe) | Out-Null
    $sys = New-Object System.Security.Principal.NTAccount("NT AUTHORITY\SYSTEM")
    $ruleSys = New-Object System.Security.AccessControl.FileSystemAccessRule($sys,"FullControl","Allow")
    $acl.AddAccessRule($ruleSys) | Out-Null
    Set-Acl -Path $envPath -AclObject $acl
  } catch {}
  Write-Ok ".env yazildi ve kilitlendi: $envPath"
}

function Start-NewStack {
  param([string]$Root)
  $compose = Get-ComposeCmd
  $composeFile = Resolve-ComposeFile -Root $Root
  if (-not $composeFile) { throw "docker-compose.yml bulunamadi (InstallRoot=$Root). infra/docker-compose.yml olmasi beklenir." }

  Write-Info "Yeni stack baslatiliyor: $composeFile"
  & $compose.Split(" ")[0] $compose.Split(" ")[1] "-f" $composeFile "up" "-d" "--build"
  Write-Ok "Stack up tamam."

  # Wait health
  $healthUrl = "http://localhost:8000/health"
  $uiUrl = "http://localhost:8501"
  $deadline = (Get-Date).AddSeconds(90)
  while ((Get-Date) -lt $deadline) {
    try {
      $r = Invoke-RestMethod -Uri $healthUrl -TimeoutSec 3
      if ($r.ok -eq $true) {
        Write-Ok "API health OK: $healthUrl"
        Write-Ok "UI: $uiUrl"
        return
      }
    } catch {}
    Start-Sleep -Seconds 2
  }
  Write-Warn "Health bekleme suresi doldu. Docker loglarina bakmak icin: docker compose -f `"$composeFile`" logs --tail 200"
}

# --- MAIN ---
Write-Info "KATOPU install basladi"
Write-Info "InstallRoot: $InstallRoot"

# Determine ZIP
if ([string]::IsNullOrWhiteSpace($PackageZip)) {
  $roots = @($PWD.Path, (Join-Path $env:USERPROFILE "Downloads"), (Join-Path $env:USERPROFILE "Desktop"), "C:\Temp")
  $PackageZip = Find-LatestZip -Roots $roots
}
if (-not $PackageZip) { throw "Paket ZIP bulunamadi. -PackageZip ile tam yol ver." }
if (-not (Test-Path $PackageZip)) { throw "ZIP bulunamadi: $PackageZip" }
Safe-Unblock $PackageZip
Write-Ok "ZIP bulundu: $PackageZip"

# Stop old stack if InstallRoot exists
if (Test-Path $InstallRoot) {
  Stop-OldStack -RootToCheck $InstallRoot
  Stop-PortProcesses -Ports @(8501,8000)
  if ($RemoveOld) {
    $backup = $InstallRoot.TrimEnd("\") + "_backup_" + (Get-Date -Format "yyyyMMdd_HHmmss")
    Write-Info "Eski kurulum yedekleniyor: $backup"
    try { Move-Item -Force $InstallRoot $backup } catch { 
      Write-Warn "Move-Item basarisiz; RemoveOld icin silmeyi deneyecegim."
      Remove-Item -Recurse -Force $InstallRoot
    }
    Write-Ok "Eski kurulum kaldirildi/yedeklendi."
  }
}

# Ensure InstallRoot exists
if (-not (Test-Path $InstallRoot)) { New-Item -ItemType Directory -Path $InstallRoot | Out-Null }

# Extract new zip to temp then copy into InstallRoot (to avoid partial overwrite)
$tmp = Get-FreeTempDir
Write-Info "ZIP aciliyor: $tmp"
Expand-Archive -Force $PackageZip -DestinationPath $tmp

# Find top folder (if zip contains a single root dir)
$entries = Get-ChildItem $tmp
$srcRoot = $tmp
if ($entries.Count -eq 1 -and $entries[0].PSIsContainer) { $srcRoot = $entries[0].FullName }

Write-Info "Kurulum hedefe kopyalaniyor..."
# Clear InstallRoot content if not RemoveOld
Get-ChildItem $InstallRoot -Force -ErrorAction SilentlyContinue | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
Copy-Item -Path (Join-Path $srcRoot "*") -Destination $InstallRoot -Recurse -Force
Write-Ok "Dosyalar kuruldu: $InstallRoot"

# API key handling
$runtimeEnv = @{
  KATOPU_REQUIRE_API_KEY = ($RequireApiKey.IsPresent.ToString().ToLowerInvariant())
}
if ($RequireApiKey) {
  if ([string]::IsNullOrWhiteSpace($ApiKey)) {
    $existing = Read-SecretStoreKey
    if ($existing) { $ApiKey = $existing; Write-Info "Mevcut secret store'dan API key okundu." }
    else {
      # generate
      $chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
      $ApiKey = -join (1..48 | ForEach-Object { $chars[(Get-Random -Minimum 0 -Maximum $chars.Length)] })
      Write-Info "Yeni API key uretildi."
    }
  }
  Ensure-SecretStore -ApiKeyValue $ApiKey | Out-Null
  $runtimeEnv["KATOPU_API_KEY"] = $ApiKey
} else {
  $runtimeEnv["KATOPU_API_KEY"] = ""
}

# Optionally write .env
if ($WriteDotEnv) {
  Maybe-WriteDotEnvFile -Root $InstallRoot -EnvMap $runtimeEnv
}

# Export env for compose process
foreach ($k in $runtimeEnv.Keys) { Set-Item -Path ("Env:{0}" -f $k) -Value $runtimeEnv[$k] }

# Start
Start-NewStack -Root $InstallRoot

Write-Ok "KATOPU install tamamlandi."
