#!/usr/bin/env bash
set -euo pipefail
python3 scripts/doctor.py
