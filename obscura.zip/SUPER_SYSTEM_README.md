# OBSCURA SUPER SYSTEM - Single ZIP Bundle

This bundle consolidates the deliverables into a single ZIP.

## Primary system (run this)
The root directory is the extracted contents of `FINAL_DELIVERY_OBSCURA_ULTRA_v2.zip`.
Use its README / Makefile / docker-compose instructions to run.

## Legacy / references
- `legacy/GENLAB_OBSCURA_SUPER_LAB_01/` contains the extracted `GENLAB_OBSCURA_SUPER_LAB_01 (1).zip` (preserved).
- `legacy/original_zips/` contains the original zip files as provided.

## Manifest
See `SUPER_SYSTEM_MANIFEST.json` for inclusion details.
