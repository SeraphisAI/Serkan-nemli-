#!/usr/bin/env python3
"""
Generate Schemathesis presets & per-tag subspecs from an OpenAPI 3.0/3.1 YAML/JSON file.

Outputs:
- tests/contract/presets.json
- tests/contract/subspecs/<Tag>.yaml

Usage:
  python tests/contract/generate_presets.py openapi/openapi.yaml tests/contract/presets.json
"""
from __future__ import annotations

import json
import os
import sys
from copy import deepcopy
from datetime import datetime
from pathlib import Path

def load_spec(path: Path) -> dict:
    if path.suffix.lower() in (".json",):
        return json.loads(path.read_text(encoding="utf-8"))
    # YAML
    try:
        import yaml  # type: ignore
    except Exception as e:
        raise SystemExit("PyYAML missing. Install: pip install PyYAML") from e
    return yaml.safe_load(path.read_text(encoding="utf-8"))

def dump_yaml(path: Path, data: dict) -> None:
    try:
        import yaml  # type: ignore
    except Exception as e:
        raise SystemExit("PyYAML missing. Install: pip install PyYAML") from e
    # Keep output stable-ish; avoid anchors
    class NoAliasDumper(yaml.SafeDumper):  # type: ignore
        def ignore_aliases(self, _data):  # noqa: N802
            return True
    text = yaml.dump(data, Dumper=NoAliasDumper, sort_keys=False, allow_unicode=True)
    path.write_text(text, encoding="utf-8")

def iter_operations(spec: dict):
    paths = spec.get("paths") or {}
    for pth, item in paths.items():
        if not isinstance(item, dict):
            continue
        for method, op in item.items():
            m = str(method).lower()
            if m not in ("get","post","put","patch","delete","options","head","trace"):
                continue
            if not isinstance(op, dict):
                continue
            yield pth, m, op

def build_subspec(spec: dict, tag: str) -> dict:
    out = deepcopy(spec)
    out_paths = {}
    for pth, method, op in iter_operations(spec):
        tags = op.get("tags") or []
        if tag in tags:
            out_paths.setdefault(pth, {})
            out_paths[pth][method] = op
    out["paths"] = out_paths
    # Keep only the tag in tag list (optional)
    if isinstance(out.get("tags"), list):
        out["tags"] = [t for t in out["tags"] if isinstance(t, dict) and t.get("name") == tag] or [{"name": tag}]
    return out

def main():
    if len(sys.argv) != 3:
        print("usage: generate_presets.py <openapi.(yaml|json)> <out_presets.json>")
        raise SystemExit(2)

    spec_path = Path(sys.argv[1]).resolve()
    out_presets = Path(sys.argv[2]).resolve()

    spec = load_spec(spec_path)
    tag_names = []
    for t in (spec.get("tags") or []):
        if isinstance(t, dict) and isinstance(t.get("name"), str):
            tag_names.append(t["name"])
    # Fallback: infer tags from operations if tags section missing
    if not tag_names:
        seen = set()
        for _, _, op in iter_operations(spec):
            for tg in op.get("tags") or []:
                if isinstance(tg, str) and tg not in seen:
                    seen.add(tg)
        tag_names = sorted(seen)

    subspec_dir = out_presets.parent / "subspecs"
    subspec_dir.mkdir(parents=True, exist_ok=True)

    groups = {}
    for tag in tag_names:
        subspec = build_subspec(spec, tag)
        rel = Path("tests/contract/subspecs") / f"{tag}.yaml"
        abs_path = subspec_dir / f"{tag}.yaml"
        dump_yaml(abs_path, subspec)
        groups[tag] = {
            "schemaPath": str(rel).replace("\\", "/"),
            "maxExamplesEnv": "MAX_EXAMPLES",
            "baseUrlEnv": "BASE_URL",
            "requiredHeaders": ["X-API-Key", "X-Quantum-Token"]
        }

    presets = {
        "generatedAt": datetime.utcnow().isoformat() + "Z",
        "sourceSpec": str(Path("openapi/openapi.yaml")),
        "info": {
            "title": (spec.get("info") or {}).get("title"),
            "version": (spec.get("info") or {}).get("version"),
            "openapi": spec.get("openapi"),
        },
        "groups": groups
    }

    out_presets.parent.mkdir(parents=True, exist_ok=True)
    out_presets.write_text(json.dumps(presets, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print("wrote presets:", out_presets)

if __name__ == "__main__":
    main()
