"""
Schemathesis hooks: inject required auth headers (AND) from env variables.

Env:
- KATOPU_API_KEY
- KATOPU_QUANTUM_TOKEN
"""
from __future__ import annotations

import os
from typing import Any

def before_call(context: Any, case: Any) -> None:
    hdrs = case.headers or {}
    api_key = os.getenv("KATOPU_API_KEY")
    qt = os.getenv("KATOPU_QUANTUM_TOKEN")
    if api_key and "X-API-Key" not in hdrs:
        hdrs["X-API-Key"] = api_key
    if qt and "X-Quantum-Token" not in hdrs:
        hdrs["X-Quantum-Token"] = qt
    case.headers = hdrs
