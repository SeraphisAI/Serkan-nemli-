#!/usr/bin/env bash
set -euo pipefail

GROUP="${1:-}"
if [[ -z "$GROUP" ]]; then
  echo "usage: run_group.sh <GroupName>"
  exit 2
fi

python tests/contract/generate_presets.py openapi/openapi.yaml tests/contract/presets.json

SCHEMA="tests/contract/subspecs/${GROUP}.yaml"
if [[ ! -f "$SCHEMA" ]]; then
  echo "Subspec not found: $SCHEMA"
  echo "Available:"
  ls -1 tests/contract/subspecs || true
  exit 2
fi

BASE_URL="${BASE_URL:-http://127.0.0.1:4010}"
MAX_EXAMPLES="${MAX_EXAMPLES:-25}"

schemathesis run "$SCHEMA" \
  --base-url "$BASE_URL" \
  --checks all \
  --hypothesis-max-examples "$MAX_EXAMPLES" \
  --hooks tests/contract/hooks.py
