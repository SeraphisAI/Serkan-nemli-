# Katopu Hyper API v12.2.0 — MAX pack (CI + Contract + Spectral + GraphQL Adapter)

This bundle contains:
- OpenAPI: `openapi/openapi.yaml`
- CI:
  - Contract tests: Prism + Schemathesis (per-tag subspecs)
  - Breaking-change gate: oasdiff (ERR fails PR)
  - Spectral gate: OpenAPI lint rules
- GraphQL adapter: `servers/graphql/` (Yoga + REST proxy + snake/camel mapping)

## Local: Contract Tests (Mocked)
```bash
npm i -g @stoplight/prism-cli
bash scripts/run_contract_tests_local.sh
```

## CI Secrets
Set repository secrets:
- `KATOPU_API_KEY`
- `KATOPU_QUANTUM_TOKEN`

## Notes
- OpenAPI global `security` is an AND requirement: both headers required.
- Prism mock doesn't validate auth, but Schemathesis injects headers via hooks (when set).
