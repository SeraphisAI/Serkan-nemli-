# Katopu Hyper GraphQL Adapter (v12.2.0)

GraphQL façade that proxies to the REST OpenAPI service and automatically maps:
- `snake_case` REST payloads <-> `camelCase` GraphQL fields
- Exception mapping: `encrypted_data` <-> `encryptedData`

## Run
```bash
cd servers/graphql
npm i
npm run build
REST_BASE_URL="https://api.katopu-hyper.com/v12.2" PORT=7070 npm start
```

## Auth
Forward the REST auth headers to GraphQL:
- `X-API-Key`
- `X-Quantum-Token`

Example:
```bash
curl -sS http://localhost:7070/graphql \
  -H "content-type: application/json" \
  -H "X-API-Key: $KATOPU_API_KEY" \
  -H "X-Quantum-Token: $KATOPU_QUANTUM_TOKEN" \
  -d '{"query":"query{ listUsers { id username email } }"}'
```
