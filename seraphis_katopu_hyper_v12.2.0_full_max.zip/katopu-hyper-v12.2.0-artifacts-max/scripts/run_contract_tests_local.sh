#!/usr/bin/env bash
set -euo pipefail

command -v prism >/dev/null 2>&1 || { echo "Install Prism: npm i -g @stoplight/prism-cli"; exit 2; }

pip install -r tests/contract/requirements-contract.txt

prism mock openapi/openapi.yaml --port 4010 >/tmp/prism.log 2>&1 &
PRISM_PID=$!
trap "kill $PRISM_PID >/dev/null 2>&1 || true" EXIT
sleep 2

# Run all groups sequentially (Users/Orders/Quantum/Assistant)
for g in Users Orders Quantum Assistant; do
  echo "=== Running group: $g ==="
  BASE_URL="http://127.0.0.1:4010" bash tests/contract/run_group.sh "$g"
done
